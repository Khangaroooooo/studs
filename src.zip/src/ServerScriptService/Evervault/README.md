# EverVault - PC Brain System 🧠

This is your **local AI brain**, powered by Hermes Agent + LM Studio (local LLM) + Obsidian vault as knowledge base. The entire system runs locally on your device with no data leaving your computer.

---

## 🎯 Mission Statement

Build a persistent, growing knowledge graph that:
1. **Survives across sessions** using the memory tool for critical facts
2. **Learns from each interaction** through learning notes and core memory updates
3. **Links everything together** with dense wikilink connections
4. **Operates locally** with all processing on your Apple Silicon Mac

---

## 🧠 How It Works

### Core Mechanisms:

1. **Persistent Memory**
   - Facts stored in `brain/core/memory.md` survive across sessions via the `memory` tool
   - Personal info files in `brain/personal-info/` persist to memory when edited

2. **Personal Identity**
   - Your details live in organized identity files: name, occupation, location, tools, preferences
   - Use the memory tool to persist each file after editing (critical!)

3. **Learning Loop**
   - Every session: discover → document learning notes → add to core memory
   - New concepts get atomic fact files in `brain/core/facts/`

4. **Project & Task Management**
   - Store active work in `projects/` folder
   - Track action items in `tasks/` folder with clear status tracking

5. **Context Building**
   - Use `brain/context/` for temporary but relevant information
   - Clean up regularly to prevent bloat (review at session end!)

---

## 📁 Complete Folder Structure

```
EverVault/
├── brain/                    # Main knowledge base (persistent)
│   ├── core/                 # Session-independent memory (memory.md, facts/*.md)
│   │   ├── memory.md         ← READ THIS FIRST! Main persistent hub
│   │   ├── connection-guide.md  ← Architecture documentation
│   │   └── facts/            # Atomic knowledge units
│   │       ├── index.md      ← Facts index (browse all facts)
│   │       ├── hybrid-persistence-pattern.md
│   │       ├── session-end-routine.md
│   │       ├── context-folder-maintenance.md
│   │       ├── memory-tool-persistence.md
│   │       ├── atomic-notes-principle.md
│   │       └── wikilink-connectivity-rules.md
│   ├── personal-info/        # Your identity (must persist with memory tool!)
│   │   ├── name.md          ← Your full name(s) and aliases
│   │   ├── occupation.md    ← What you do professionally
│   │   ├── location.md      ← City, timezone, base location
│   │   ├── tools-and-env.md ← Tech stack and tools
│   │   ├── work-preferences.md  ← How you like to work
│   │   └── brain-rules.md   ← Guidelines for this brain system
│   ├── learning/             # New knowledge acquisition
│   │   ├── notes/           ← New discoveries (create here!)
│   │   └── note-template.md ← Template for learning notes
│   ├── memories/            # Events and experiences
│   │   └── (session log here)
│   └── context/             # Temporary but relevant info
│       └── (clean often!)
├── projects/                 # Work in progress, ideas, experiments
│   ├── evervault-brain-system.md  ← Main project tracker
│   └── template.md          ← Template for new projects
├── tasks/                    # TODOs, reminders, action items
│   └── template.md          ← Template for new tasks
├── system/                   # Config, templates, guides, metadata
│   ├── memory-tool-guide.md     ← How persistence works (CRITICAL!)
│   ├── metrics/
│   │   └── brain-health-report.md  ← Health dashboard
│   └── session-notes/
│       └── template.md         ← Session logging template
├── COMPLETE-IMPROVEMENTS-SUMMARY.md   ← Summary of this improvement work
├── QUICK-START.md             ← 3-minute setup guide (read first!)
└── SUMMARY.md                 ← Complete system documentation
```

---

## 🔄 Usage Pattern

### Start of Session:

1. **Read `brain/core/memory.md`** - Understand current knowledge state
2. **Check `tasks/`** - See pending action items
3. **Scan `projects/`** - Review ongoing work in progress

### During Session:

- **New facts discovered**: Add to `brain/personal-info/*.md` OR `brain/core/facts/*.md`, then use memory tool to persist!
- **New learning**: Create note in `learning/notes/` with template
- **New projects**: Create project file in `projects/`
- **New tasks**: Add item using task template
- **Important tools discovered**: Document in facts folder + persist

### End of Session:

1. **Update `brain/core/memory.md`** - Write session highlights
2. **Create session log** - In `system/session-notes/` using template
3. **Clean context folder** - Archive or delete temporary files
4. **Persist personal info** - Use memory tool for all identity files

---

## 🔗 Knowledge Graph Principles

### Every Brain Note Should:

1. **Link to `[[core/memory.md]]`** - Connects to persistent memory hub (REQUIRED!)
2. **Link to 1-2 related notes** - Creates knowledge graph density
3. **Be atomic** - One idea per note, not one giant file
4. **Have clear status** - new | refining | integrated | archived

### Linking Examples:

```markdown
# Example: hermes-first-discovery.md
---
title: Hermes First Session Discovery
topics: [[hermes-agent]], [[lm-studio]]
related-to: [[core/memory.md]], [[brain/.getting-started]]
status: new
---

## What I Discovered
[Content about first session...]

## See Also
- [[facts/memory-tool-persistence]] - How facts survive
- [[connection-guide]] - Architecture overview
```

---

## 💾 The Persistence System (Critical!)

### Hybrid Approach:

**Obsidian files** → Searchable, linkable knowledge graph  
**Memory tool** → Cross-session survival for critical facts  

### The Pattern:

```python
from hermes_tools import read_file, memory

# For personal info - ALWAYS use this pattern:
read_content = read_file(path="brain/personal-info/name.md").content
memory(action="add", target="user", content=read_content)

# For important facts:
write_file(path="brain/core/facts/new-fact.md", content=fact_content)
memory(action="add", target="user", content=read_file(path="brain/core/facts/new-fact.md").content)
```

### Files That MUST Be Persisted:

- ✅ `brain/personal-info/*.md` - ALL identity files
- ✅ `brain/core/facts/*.md` - Important fact files
- 🟡 `learning/notes/*.md` - Can reference without persistence
- 🔴 `brain/context/*.md` - Temporary, archive regularly

### Files That DON'T Need Persistence:

- `learning/notes/*.md` - New learning added as needed
- `memories/*.md` - Episodic (context-dependent)
- `context/*.md` - Temporary by design
- `system/session-notes/*.md` - Session-specific logs

---

## ⚡ Key Principles (Remember These!)

1. **Use `memory` tool** - Personal info and important facts MUST be persisted!
2. **Link everything** - Every brain note links to `[[core/memory.md]]` + 1-2 others
3. **Keep it atomic** - One idea per note, not one giant file
4. **Document growth** - Track what you learn in learning notes
5. **Archive wisely** - Move completed work from context/projects

---

## 📅 Your Brain Architecture (Three Layers)

### LAYER 1: PERSISTENT (survives sessions)

- `brain/core/memory.md` ← Main hub, read this first!
- `brain/personal-info/*.md` ← Your identity
- `brain/core/facts/*.md` ← Atomic knowledge units

### LAYER 2: WORK IN PROGRESS

- `projects/*.md` ← Active work items
- `tasks/*.md` ← Pending actions
- `memories/*.md` ← Events/experiences

### LAYER 3: LEARNING & CONTEXT

- `learning/notes/*.md` ← New discoveries
- `context/*.md` ← Temporary relevant info (clean often!)

---

## 🧠 See Also - Essential Reading Order

1. **First**: `[[QUICK-START]]` - 3-minute setup guide
2. **Second**: `[[brain/core/memory.md]]` - Main memory hub
3. **Third**: `[[system/memory-tool-guide]]` - How persistence works (CRITICAL!)
4. **Fourth**: `[[brain/.getting-started]]` - Complete getting started guide

---

## 🔍 Find Your Way Around

### For New Users:

- Start with `[[QUICK-START.md]]` for rapid onboarding
- Read `[[brain/core/memory.md]]` to understand current state
- Use `[[brain/.getting-started.md]]` for detailed guidance

### For Understanding the System:

- `[[system/metrics/brain-health-report]]` - Health dashboard
- `[[projects/evervault-brain-system]]` - Project overview
- `[[brain/core/facts/index]]` - All atomic facts index
- `[[USING-EVERVAULT-TO-FULLEST-POTENTIAL.md]]` ← **START HERE!** Complete usage guide

---

## 🎉 Your Brain is Ready!
- `[[facts/hybrid-persistence-pattern]]` - Persistence mechanism

---

## 🎉 Your Brain is Ready!

The structure is complete, templates are in place, and guidelines are written.

**Critical next step**: Fill in your personal info files using memory tool!

Your brain has been rebuilt from scratch and is ready to grow smarter with each session. 🧠✨

---

## ⚠️ Critical Warnings

### DO NOT forget:

- ❌ **Don't rely on Obsidian alone** for persistence - use memory tool!
- ❌ **Don't let context folder grow** beyond 5 files - review at session end
- ❌ **Don't create god files** - keep notes atomic (one idea per note)
- ❌ **Don't forget to link** - every brain note links to core/memory.md

### DO always:

- ✅ Use `memory` tool for personal info and critical facts
- ✅ Link new notes to at least 2 other notes + core memory
- ✅ Create session logs at end of each session
- ✅ Review and clean context folder regularly

---

*Last updated: Session 2026-06-01 complete rebuild  
Brain architecture version: 1.0 (multi-layer knowledge graph)*
