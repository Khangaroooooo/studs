# Session Log Template - Track Each Session

```markdown
---
session-date: YYYY-MM-DD
hermes-model-used: [model-name]
total-files-created: [count]
total-notes-linked: [count of wikilinks added]
topics-explored: 
  - [[topic-1]]
  - [[topic-2]]
key-events:
  - Event 1 description
  - Event 2 description  
outcome-summary: [2-3 sentences]
---

## Session Overview

[Brief summary of what happened during this session]

## Files Created This Session

### New Brain Notes:
- `[[path/to/new-note]]` - What it's about

### Personal Info Added:
- `personal-info/*.md` files updated/created

### Projects & Tasks:
- New projects started: [...]
- Tasks added: [...]

## Key Learnings

[ ] Learned concept X → Added to [[learning/notes/X]]
[ ] Discovered fact Y → Persisted to memory tool  
[ ] Overcame challenge Z → Documented in [[memories/*]]

## Files Linked to Memory

These should have been persisted using `memory` tool:
- Facts about tools used
- User preferences discovered
- Important discoveries made

## Session Decisions

[ ] Decision 1 was made and documented
[ ] Decision 2 noted for future sessions

## State After This Session

### Persistent Changes:
- [[core/memory.md]] updated with...
- New personal info added to [[personal-info/*]]

### Temporary Context (in `brain/context/`):
- Context files from this session that might need cleaning up: [...]

## Notes for Next Session

[ ] Review these linked notes first:
  - [[core/memory.md]]
  - Any blocked tasks in `tasks/`  
  - Ongoing projects in `projects/`

---

*End of session log*  
*See: [[brain/core/memory.md]] for main memory hub*
```
