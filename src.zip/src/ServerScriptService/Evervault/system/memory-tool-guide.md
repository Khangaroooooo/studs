# Memory Tool Usage Guide - Persistence Across Sessions

## 🎯 Critical: How to Use `memory` Tool

The `memory` tool is **essential** for your brain to persist across Hermes sessions!

### Basic Usage Pattern:

```python
from hermes_tools import memory, read_file

# 1. Read the fact from a file
content = read_file(path="personal-info/name.md").content

# 2. Persist it to memory (survives next session!)  
memory(action="add", target="user", content=content)
```

### When to Use Memory Tool:

#### ✅ DO use memory tool for:
- **Personal identity facts** (name, occupation, location)
- **User preferences** (tools you use, work habits)  
- **Important discoveries** from a session
- **Cross-references between notes**

#### ⏸️ DON'T use memory tool for:
- **Temporary context** that won't persist (use `brain/context/`)
- **Session-specific notes** (use `system/session-notes/`)
- **Single-session learning** (use `learning/notes/`, then archive)

---

## 📝 Memory Persistence Examples

### Example 1: Persist Personal Info

```python
from hermes_tools import memory, read_file

# Read and persist name
name_content = read_file(path="brain/personal-info/name.md").content
memory(action="add", target="user", content=name_content)

# Read and persist location  
location_content = read_file(path="brain/personal-info/location.md").content
memory(action="add", target="user", content=location_content)

# Read and persist preferences
prefs_content = read_file(path="brain/personal-info/preferences.md").content
memory(action="add", target="user", content=prefs_content)
```

### Example 2: Persist Key Discovery

During a session when you discover something important:
```python
from hermes_tools import memory, read_file

# Create fact file first (optional but good practice)
fact = """Title: Important discovery from session
Category: tool | concept | platform  
Related-to: [[core/memory.md]]
Status: new | refined | integrated
---
[Content of discovery...]

Key learning points:
- Point 1
- Point 2

See also: [[related-concept]]
"""

# Write to facts folder (for searchability)
from hermes_tools import write_file
write_file(path="brain/core/facts/[discovery-title].md", content=fact)

# Then persist to memory
memory(action="add", target="user", content=read_file(path="brain/core/facts/[discovery-title].md").content)
```

### Example 3: Batch Persist Multiple Files

```python
from hermes_tools import memory, read_file
import os

files_to_persist = [
    "brain/personal-info/name.md",
    "brain/personal-info/occupation.md",  
    "brain/personal-info/location.md"
]

for file_path in files_to_persist:
    if os.path.exists(file_path):
        content = read_file(path=file_path).content
        memory(action="add", target="user", content=content)
        print(f"Persisted {file_path}")
```

---

## 🔄 Memory Flow Diagram

```
Session Starts
     ↓
Read brain/core/memory.md  ← Check current state
     ↓
During work, create notes in:
  ├── learning/notes/   ← New knowledge (temporary)
  ├── personal-info/    ← Identity facts (persist!)
  ├── core/facts/       ← Atomic knowledge units (persist!)  
  └── memories/         ← Events (context-dependent persistence)
     ↓
Before ending session:
  1. Write session log to system/session-notes/
  2. Use memory tool to persist personal-info/*.md + core/facts/*.md
  3. Update brain/core/memory.md with session summary
  4. Archive from context/ folder
```

---

## 🧠 Memory File Structure

### Files that SHOULD be persisted (memory tool):
- `brain/personal-info/name.md`
- `brain/personal-info/occupation.md`  
- `brain/personal-info/location.md`
- `brain/personal-info/preferences.md`
- `brain/core/facts/*.md` (all fact files)

### Files that typically DON'T need persistence:
- `learning/notes/*.md` (can be referenced, new ones added as needed)
- `memories/*.md` (session-specific, may not need all persisted)
- `context/*.md` (temporary by design, archived regularly)
- `system/session-notes/*.md` (already in session log format)

---

## ⚠️ Common Mistakes to Avoid

### ❌ Don't rely on Obsidian alone for persistence
```python
# WRONG: Just writing to Obsidian file without memory tool
write_file(path="brain/personal-info/name.md", content="...")
# This gets lost when session ends!

# RIGHT: Use memory tool + write to Obsidian
write_file(path="brain/personal-info/name.md", content="...")
memory(action="add", target="user", content=read_file(path="brain/personal-info/name.md").content)
```

### ✅ Do both for critical facts
```python
# 1. Write to Obsidian (searchable, linkable knowledge graph)
write_file(path="brain/core/facts/new-discovery.md", content=fact_content)

# 2. Persist to memory (survives session restart)  
memory(action="add", target="user", content=read_file(path="brain/core/facts/new-discovery.md").content)
```

---

## 🧪 Verify Persistence

After persisting, test that memory works:

```python
from hermes_tools import memory

# Try to get persisted facts (check what's there)
memory(action="list")  # See all persisted facts
```

**Pro tip**: Create a fact index in `brain/core/facts/index.md` that lists all persisted facts.

---

## 📚 Related Resources

- `[[brain/core/memory.md]]` - Main memory hub
- `[[system/session-notes/template]]` - Session logging
- `learning/note-template.md` - For learning notes
