---
title: Troubleshooting
topics: [[core/memory]], [[system/continuation/guide]]
status: active
version: 1.0.0
last-updated: June 2026
---

# Session Continuation System - Troubleshooting Guide 🛠️

## Table of Contents

1. [Common Issues](#common-issues)
2. [Quick Fixes](#quick-fixes)
3. [Deep Dive Solutions](#deep-dive-solutions)
4. [Prevention Tips](#prevention-tips)
5. [Advanced Debugging](#advanced-debugging)

---

## Common Issues

### Issue 1: "Could not load core memory"

**Error Message:**
```
⚠️ Could not load core memory: [file not found or empty]
```

**Cause:** `brain/core/memory.md` doesn't exist or is inaccessible.

**Quick Fix:**
```bash
# Check if file exists
ls -la brain/core/memory.md

# If missing, create it
echo "---\ntitle: Core Memory Hub\nstatus: active\ncontinuation-ready: true" > brain/core/memory.md

# Initialize core memory properly
memory action=list limit=50 > brain/core/memory.md
```

**Deep Dive:**
1. Verify the file is accessible from the scripts directory
2. Check OBSIDIAN_VAULT_PATH environment variable
3. Ensure no read permissions are blocking access

---

### Issue 2: "Personal info not loaded"

**Error Message:**
```
⚠️ Personal info folder empty or files not found
```

**Cause:** Personal identity facts haven't been persisted via memory tool yet.

**Quick Fix:**
```bash
# Persist your personal info immediately
memory action=add target=user content="Name: KK Khangaroo\nRole: Local AI Developer\nOS: macOS Apple Silicon"

# Verify persistence
python scripts/session-continuator.py --check-persistence
```

**Deep Dive:**
1. Personal info must be explicitly persisted using memory tool
2. Files in `brain/personal-info/` should also be added to memory tool
3. Use this command to persist personal facts:
   ```bash
   memory action=add target=user content="FACT_HERE"
   ```

---

### Issue 3: "No session notes found"

**Error Message:**
```
📜 Session notes directory is empty or not configured
```

**Cause:** This is actually **normal**! Session notes are created when sessions end with cleanup automation.

**Quick Fix:**
```bash
# Create first session note
python scripts/session-end-routine.py --log-only

# Verify it was created
ls -la system/session-notes/
```

**Deep Dive:**
- Session notes track your work history across sessions
- First note appears after running session-end-routine or after a session completes naturally
- You can manually create notes if needed for quick reference

---

### Issue 4: "State summary not updating"

**Symptom:** State summary doesn't reflect recent work, looks stale.

**Quick Fix:**
```bash
# Force regenerate state summary
python scripts/state-summary-generator.py > brain/context/state-summary.md

# Or use minimal mode for quick check
python scripts/state-summary-generator.py --minimal
```

**Deep Dive:**
1. Check what files were scanned:
   ```bash
   ls projects/
   ls tasks/
   ls learning/notes/
   ```
2. Verify content exists in these directories
3. If using wikilinks, ensure they're resolving correctly

---

### Issue 5: "Continuation script hangs"

**Symptom:** `session-continuator.py` doesn't finish or seems stuck.

**Quick Fix:**
```bash
# Check for Python errors
python scripts/session-continuator.py --check-persistence

# Verify memory tool is working
memory action=list limit=5
```

**Deep Dive:**
1. The script waits for manual confirmation - this is intentional safety feature
2. Look for "Please continue with new session?" prompt
3. If you want automatic continuation, use `--skip-summary` flag to speed it up

---

### Issue 6: "Memory tool connection errors"

**Error Message:**
```
⚠️ Could not load from memory tool: connection refused / timeout
```

**Cause:** Memory tool isn't running or Hermes agent isn't available.

**Quick Fix:**
```bash
# Check if memory tool is accessible
memory action=list limit=10

# If it fails, continue without memory tool (use files only)
python scripts/session-continuator.py --skip-summary
```

**Deep Dive:**
- Memory tool relies on Hermes agent being active
- For standalone script runs, rely on file-based persistence in `brain/core/memory.md`
- Consider setting up cron job to keep memory tool running

---

### Issue 7: "State summary generation too slow"

**Symptom:** Takes several seconds/minutes to generate.

**Quick Fix:**
```bash
# Use minimal mode for quick reference
python scripts/state-summary-generator.py --minimal
```

**Deep Dive:**
- Full mode scans all projects, tasks, and learning notes
- Consider archiving older items (see `scripts/archival-bot.py`)
- Optimize core/memory.md content to avoid loading excessive data

---

### Issue 8: "Continuation triggers at wrong time"

**Symptom:** Auto-continuation happens when you wanted a break.

**Solution:**
```bash
# Use longer delays between sessions
python scripts/session-end-routine.py --continue-after 2h  # Instead of 20m

# Or skip auto-continuation and review state manually first
python scripts/state-summary-generator.py > brain/context/state-summary.md
```

---

## Quick Fixes Reference Card

| Issue | Command to Fix | When to Use |
|-------|----------------|-------------|
| Missing core memory | `echo "..." > brain/core/memory.md` | Fresh installation, file missing |
| No personal info | `memory action=add target=user content="..."` | First session, identity not persisted |
| Empty session notes | `python scripts/session-end-routine.py --log-only` | Normal, just need to create first |
| Stale state summary | `python scripts/state-summary-generator.py > brain/context/state-summary.md` | Need current work snapshot |
| Slow generation | Use `--minimal` flag | Quick standup or reference needed |
| Wrong timing | Use longer `--continue-after` delay | Want break before continuing |

---

## Deep Dive Solutions

### Solution 1: Setting Up First-Time Continuation System

**Scenario:** You're starting fresh and need to initialize the continuation system.

**Step-by-Step:**

```bash
# 1. Create core memory hub if missing
echo "---\ntitle: Core Memory Hub\nstatus: active\ncontinuation-ready: true" > brain/core/memory.md

# 2. Persist your personal identity facts
memory action=add target=user content="Name: KK Khangaroo\nRole: Local AI Developer on Apple Silicon macOS\nTech Stack: VSCode, zsh, Python/pandas, Arc browser, Hermes Agent, LM Studio (qwen3.5-9b)\nRules: atomic wikilinks, session hygiene (core/memory start, system/session-notes/ end), persist all personal info & facts via memory tool"

# 3. Create first session note
python scripts/session-end-routine.py --log-only

# 4. Test continuation works
python scripts/session-continuator.py --check-persistence

# 5. Review generated state summary
cat brain/context/state-summary.md
```

### Solution 2: Recovering from Failed Session End

**Scenario:** Session ended abruptly and some persistence didn't happen.

**Recovery Steps:**

```bash
# Step 1: Check what we can recover
python scripts/session-continuator.py --check-persistence

# Step 2: Manually persist critical facts to memory tool
memory action=add target=user content="CRITICAL_FACT_FROM_SESSION"

# Step 3: Create fresh session note documenting the recovery
echo "---\ntitle: Session Recovery - [DATE]\nstatus: recovery\n---" > system/session-notes/[[recovery-[DATE]]].md

# Step 4: Document what was lost in core memory
memory action=add target=memory content="RECOVERY_NOTE: Session ended unexpectedly. Re-persisted facts X, Y, Z on [DATE]"

# Step 5: Trigger continuation for next session
python scripts/session-continuator.py
```

### Solution 3: Optimizing Continuation Performance

**Scenario:** Continuation is slow or memory tool is timing out.

**Optimization Steps:**

```bash
# 1. Check what's in core memory (might be bloated)
memory action=list limit=100

# 2. Archive old notes to reduce load
python scripts/archival-bot.py --age-days 90

# 3. Use state summary instead of full context sometimes
python scripts/state-summary-generator.py --minimal

# 4. Set up proper memory batching
python scripts/memory-batcher.py

# 5. Consider reducing memory tool query limits in scripts
# Edit: scripts/session-continuator.py
# Find: memory(action="list", limit=100)
# Change to: memory(action="list", limit=50)  # Adjust based on your needs
```

---

## Prevention Tips

### Tip 1: Always Use Session End Routine

**Why:** Prevents accidental data loss and ensures consistency.

**Best Practice:**
```bash
# ALWAYS run at session end
python scripts/session-end-routine.py --continue-after 30m
```

### Tip 2: Persist Personal Info Immediately After Each Session

**Why:** Prevents identity facts from being lost across sessions.

**Best Practice:**
```bash
# After ANY session ends, check personal info
python scripts/session-continuator.py --check-persistence
```

### Tip 3: Review Core Memory Hub Regularly

**Why:** Ensures you're aware of what's persisted and what needs attention.

**Best Practice:**
```bash
# Daily standup - review core memory
memory action=list limit=20 | less

# Weekly review - archive old items
python scripts/archival-bot.py --age-days 30 --archive-folder system/archive/
```

### Tip 4: Use State Summary for Quick Reference

**Why:** Reduces time needed to understand session context.

**Best Practice:**
```bash
# Before starting new session, review state summary
cat brain/context/state-summary.md
```

### Tip 5: Set Up Appropriate Delay Between Sessions

**Why:** Prevents accidental immediate continuation when you wanted a break.

**Best Practice:**
```bash
# For long projects: 20-30 minute delays
python scripts/session-end-routine.py --continue-after 30m

# For deep work days: Longer delays or manual review first
python scripts/state-summary-generator.py > brain/context/state-summary.md
```

---

## Advanced Debugging

### Debug Mode: Full State Inspection

**Use this when:** Something isn't working and you need to see exactly what's persisted.

```bash
# Full persistence state inspection
echo "=== Core Memory (first 50 lines) ===" 
memory action=list limit=50 | head -50

echo ""
echo "=== Personal Info Files ==="
ls -la brain/personal-info/

echo ""
echo "=== Facts Catalog ==="
ls -la brain/core/facts/ | head -20

echo ""
echo "=== Session Notes (recent) ==="
ls -lt system/session-notes/ | head -10

echo ""
echo "=== State Summary ==="
cat brain/context/state-summary.md
```

### Debug Mode: Trace Script Execution

**Use this when:** Continuation script seems to hang or fail unexpectedly.

```bash
# Run with verbose output (add print statements if needed)
python -u scripts/session-continuator.py

# Or add debug mode flag to scripts
echo "import traceback" >> scripts/session-continuator.py
echo "" >> scripts/session-continuator.py
echo "except Exception as e:" >> scripts/session-continuator.py
echo "    print(traceback.format_exc())" >> scripts/session-continuator.py
```

### Debug Mode: Verify Memory Tool Health

**Use this when:** Memory tool is failing to respond.

```bash
# Test basic memory tool connection
memory action=list limit=1

# Check for errors in Hermes console
# (Look at your Hermes terminal or web interface)

# If available, check memory tool logs
# tail -f ~/.hermes/logs/memory-tool.log  # Example path
```

---

## When to Escalate

**Contact support or review design docs when:**

1. **All persistence layers are empty** - Core system not initialized properly
2. **Memory tool consistently fails** - Hermes agent configuration issue
3. **Session notes can't be created** - File system permissions problem
4. **Continuation generates wrong state** - Bug in state-summary-generator.py

**Check these resources first:**

- [[system/core/sessions]] - Session lifecycle documentation
- [[brain/core/memory]] - Core memory hub structure
- `[[projects/auto-session-continuation]]` - Original design document
- `system/continuation/guide.md` - Complete continuation guide

---

## Version-Specific Notes

### v1.0.0 (Current - Phase 1)

**Known Limitations:**
- Manual trigger only (auto-detection coming in Phase 2)
- No smart decision logic (coming in Phase 3)
- State summary is basic (AI-driven insights coming in Phase 4)

**Recommended Workarounds:**
- Use `--check-persistence` to verify state before continuing
- Review session notes manually for additional context
- Keep core/memory.md concise for faster loading

---

## Feedback & Improvement

Found a new issue or have an enhancement idea?

1. **Document it here** in the troubleshooting guide
2. **Add to design doc:** `[[projects/auto-session-continuation]]`
3. **Create a recovery pattern** in `system/patterns/` if applicable
4. **Share with team** via `system/core/contributions.md`

---

*Last updated: June 2026 - Phase 1 Manual Trigger Ready*
