# 🔗 EverVault Association Note

## What This Is

This is a special navigation/disambiguation note in Evervault that ensures the term "EverVault" consistently refers to your main knowledge base: **~/Documents/EverVault**

---

## 🎯 Disambiguation Rule

> **EVERY conversation and session for the lifetime of this hardware project:**
> Whenever you say "**EverVault**", it assumes you mean the Obsidian vault at `~/Documents/EverVault`, NOT some cloud service, different location, or separate system.

This is a permanent association that applies to:
- Hardware projects (like the handheld WiFi router)
- Network projects  
- Any other projects stored in Evervault

---

## 📍 Quick Links

| Location | Path | Notes |
|----------|------|-------|
| **EverVault** | `~/Documents/EverVault` | Main knowledge base & project hub |
| Hardware Projects | `projects/hardware-projects/` | See [[Handheld-WiFi-Router]] |
| Network Projects | `projects/networking/` | Bypass tools, etc. |
| Brain System | `brain/` | Core knowledge graph |

---

## 🚀 Quick Reference for Project Access

### From Terminal (Hermes)
```bash
# Navigate to EverVault hardware projects
cd ~/Documents/EverVault/projects/hardware-projects

# View the handheld WiFi router project
cat Handheld-WiFi-Router.md

# Search within EverVault
grep -r "handheld" ~/Documents/EverVault/
```

### Using Obsidian Skill (Hermes)
```bash
hermes obsidian open Handheld-WiFi-Router
```

---

**Created:** 2026-06-07  
**Note Type:** Navigation/Association  
**Priority:** HIGH - Always redirects "EverVault" to ~/Documents/EverVault
