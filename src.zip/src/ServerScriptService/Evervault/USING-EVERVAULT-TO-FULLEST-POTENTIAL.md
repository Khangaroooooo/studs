# 🧠 Using EverVault to Its Fullest Potential - Quick Start Guide

Welcome to your EverVault PC Brain System! This guide will help you extract maximum value from your local AI knowledge base.

---

## 🎯 First Steps (Do These NOW!)

### 1. Read the Core Documentation (5 minutes)
Open and read these files **in this order**:

1. **`[[QUICK-START.md]]`** - 3-minute setup guide
2. **`brain/core/memory.md`** - Your persistent memory hub (READ THIS BEFORE EACH SESSION!)
3. **`[[projects/evervault-brain-system]]`** - Main project tracker

### 2. Understand the Three Layers
```
┌─────────────────────────────────────────┐
│ LAYER 1: PERSISTENT (Survives sessions) │
│ • brain/core/memory.md ← Read this first!│
│ • brain/personal-info/*.md             │
│ • brain/core/facts/*.md                │
└─────────────────────────────────────────┘
         ↓ Links to
┌─────────────────────────────────────────┐
│ LAYER 2: WORK IN PROGRESS               │
│ • projects/*.md                         │
│ • tasks/*.md                           │
│ • memories/*.md                        │
└─────────────────────────────────────────┘
         ↓ Feeds into
┌─────────────────────────────────────────┐
│ LAYER 3: LEARNING & CONTEXT             │
│ • learning/notes/*.md (new discoveries) │
│ • context/*.md (temporary info)        │
└─────────────────────────────────────────┘
```

### 3. Complete Your Personal Info
Your personal identity files are templates waiting to be filled:
- `brain/personal-info/name.md` - Your name and aliases
- `brain/personal-info/occupation.md` - What you do professionally
- `brain/personal-info/location.md` - Your base location
- `brain/personal-info/tools-and-env.md` - Tech stack
- `brain/personal-info/brain-rules.md` - How this brain works

**CRITICAL:** After editing ANY of these files, use the memory tool to persist:
```python
from hermes_tools import read_file, memory

content = read_file(path="brain/personal-info/name.md").content
memory(action="add", target="user", content=content)
```

---

## 📚 Session Routine (Every Time You Work with EverVault)

### Start of Session:
1. **Read `[[brain/core/memory.md]]`** - Understand current knowledge state
2. **Check `tasks/` folder** - See pending action items
3. **Scan `projects/` folder** - Review ongoing work

### During Session:
- **New facts discovered?** → Add to `learning/notes/` or `brain/core/facts/`
- **Personal info updated?** → Use memory tool to persist immediately!
- **Important discovery?** → Create atomic fact file in `brain/core/facts/`
- **Learning something new?** → Use note template in `learning/`

### End of Session (NON-NEGOTIABLE!):
1. **Update `[[brain/core/memory.md]]`** - Add session highlights/new learnings
2. **Create session log** - In `system/session-notes/` using template
3. **Clean context folder** - Archive or delete temporary files (keep <5!)
4. **Persist ALL personal info files** - Use memory tool!

---

## 🔑 The #1 Rule: Hybrid Persistence

Your brain has TWO persistence mechanisms that work together:

### Obsidian Files = Searchable Knowledge Graph
- All your notes, facts, and memories are searchable and linkable
- Good for exploration, retrieval, and deep dives
- Lives in your filesystem under `~/Documents/Evervault/`

### Memory Tool = Cross-Session Survival
- Critical facts that MUST survive beyond this Hermes session
- Automatically persisted when you use the memory tool correctly
- Lives in persistent storage behind the scenes

**The Hybrid Pattern:**
```python
# For personal info files (ALWAYS persist):
read_content = read_file(path="brain/personal-info/name.md").content
memory(action="add", target="user", content=read_content)

# For important facts:
write_file(path="brain/core/facts/new-fact.md", content=fact_content)
memory(action="add", target="user", content=read_file(path="brain/core/facts/new-fact.md").content)

# For learning notes (optional):
write_file(path="learning/notes/my-discovery.md", content=note_content)
# No persistence needed initially - add later if critical
```

**Files that MUST be persisted:**
- ✅ `brain/personal-info/*.md` - ALL identity files
- ✅ `brain/core/facts/*.md` - Important fact files

**Files that DON'T need persistence:**
- 🟡 `learning/notes/*.md` - Can add as needed
- 🔴 `context/*.md` - Temporary by design, clean often!

---

## 🎓 Learning Path (Get Better Over Time)

### Phase 1: Foundation (Weeks 1-2)
**Goal:** Comfort with the system basics

#### Week 1: Understand Structure
- Read all README-style docs in order
- Map every folder's purpose
- Practice navigating without commands

#### Week 2: Master Operations
- Add learning notes using template
- Create atomic facts for important concepts
- Update personal info and persist consistently

### Phase 2: Workflow (Weeks 3-4)
**Goal:** Speed and efficiency

- Create notes in under 5 minutes
- Quickly decide: fact vs. learning note vs. context
- Batch operations when possible
- Master the "context vs. persistence" decision tree

### Phase 3: Optimization (Month 2+)
**Goal:** Deep mastery and automation

- Automate repetitive tasks with scripts
- Optimize graph density and connectivity
- Recognize patterns across notes
- Build mental model of entire graph

---

## 📖 Essential Reading Order

### Do These First (Every Session):
1. `[[brain/core/memory.md]]` ← Current knowledge state
2. `[[QUICK-START.md]]` - Quick operations reference
3. `[[system/session-notes/template.md]]` - Logging template

### Deep Understanding (Read When Needed):
4. `[[projects/evervault-brain-system]]` - Full system overview
5. `[[brain/core/connection-guide]]` - Architecture details
6. `[[system/memory-tool-guide.md]]` - Persistence explained

### Mastery Documentation (Reference as you advance):
7. `[[brain/core/facts/index.md]]` - All facts catalog
8. `[[facts/hybrid-persistence-pattern]]` - How persistence works
9. `[[facts/session-end-routine]]` - Cleanup steps
10. `[[projects/evervault-mastery]]` ← **NEW!** Follow this mastery path

---

## 🚀 Advanced Tips for Maximum Value

### Tip 1: Atomic Notes Rule
**One idea per note.** Don't create "god files" with hundreds of topics!

**Good:** 
- `brain/core/facts/hermes-memory-tool-patterns.md` - Just memory tool facts
- `brain/core/facts/session-end-routine.md` - Just session cleanup rules
- `learning/notes/memory-tool-lessons-2026-05-31.md` - Just this session's memory tool discoveries

**Bad:**
- `brain/all-things.md` - Too broad, no focus!
- `projects/evervault-guide.md` - Mixes system docs with other content

### Tip 2: Dense Linking Strategy
Every brain note should link to:
1. `[[core/memory.md]]` ← Required! Connects to hub
2. 1-2 related notes (from any folder)
3. Status field: `new | refining | integrated`

**Example:**
```markdown
---
title: What I Learned About Memory Tool
topics: [[hermes-agent]], [[persistence-patterns]]
related-to: [[core/memory.md]], [[facts/hybrid-persistence-pattern]]
status: new
---

## My Discovery
[Content about memory tool...]

## See Also
- [[connection-guide]] - How links work in my brain
```

### Tip 3: Smart Context Management
Your `brain/context/` folder is for temporary but relevant info. **Don't let it grow!**

**Pattern at session end:**
```python
# Check if context folder is bloat
context_files = len(files_in_context_folder)
if context_files > 5:
    print("🚨 Review and archive/delete files!")
else:
    pass  # Still good, but review for relevance anyway
```

**Decision guide:**
- Temporary notes? → Archive to `learning/notes/` or delete
- Important patterns? → Move to `brain/core/facts/`
- Session-specific info? → Delete (will recreate if needed)
- Personal info updates? → Persist with memory tool!

### Tip 4: Use Search Before Creating
Avoid duplicate notes by searching first:
```python
# Check if similar note exists before creating new one
search_files(pattern="React.*hook", target="content", file_glob="*.md")
search_files(query="LM Studio optimization", limit=5)
```

---

## 🛠️ Key Patterns You Should Master

### Pattern 1: The Persistence Pattern
**Most important pattern in your brain!**

```python
# Essential structure for anything that must persist:
from hermes_tools import read_file, memory

content = read_file(path="brain/personal-info/name.md").content
memory(action="add", target="user", content=content)
```

### Pattern 2: Learning Note Template
Use this template for every new learning note:

```markdown
---
title: What I Learned About [Topic]
topics: [[related-topic-1]], [[related-topic-2]]
date: {{session-date}}
source: [where did this come from?]
key-insights: 
  - insight one
  - insight two
related-projects: 
  - [[evervault-brain-system]]
status: new | refining | integrated
---

## The Big Idea
[Briefly describe what you learned]

## Details & Context
[Expand on the concept. What surprised you?]

## My Take / Interpretation
[Add your own understanding. How does this connect?]

## Connections
### Links to Existing Knowledge
- [[existing-note-1]] - connects because...
- [[existing-note-2]] - relates through...

## Action Items
[ ] Research more about X
[ ] Try experiment Y
```

### Pattern 3: Atomic Fact Creation
Use this template for facts in `brain/core/facts/`:

```markdown
---
title: [specific concise title]
category: tools | patterns | preferences | environment
related-to: [[core/memory.md]]
status: new | verified | integrated
---

## What This Fact Is
[One focused piece of knowledge about ONE concept]

## Details
[Expand on the details. Keep it focused!]

## Why It Matters
[Explain why this is important to know]

## Connections
### Links to Other Facts
- [[related-fact-1]] - connects because...

### Links to Core Memory
- [[core/memory.md]] - main hub (always link!)

### Related Personal Info
- [[personal-info/name]] - if this is about you
- [[personal-info/tools-and-env]] - if it's a tool detail
```

---

## 🎯 Common Scenarios and Solutions

### Scenario 1: "I just learned something important!"
**What to do:**
1. Decide if it needs persistence (critical facts/personal info) → Use memory tool!
2. Create note in `learning/notes/` using template
3. Add wikilinks to connect to existing knowledge
4. If pattern-based, create atomic fact in `brain/core/facts/`

### Scenario 2: "I need to update my personal info"
**What to do:**
1. Find/edit the relevant file in `brain/personal-info/`
2. **CRITICAL:** Use memory tool to persist immediately!
3. Update related notes with wikilinks

### Scenario 3: "I want to remember this for later (temporary)"
**What to do:**
1. Create note in `context/` folder
2. Mark it as temporary/relevant-for-current-session
3. **Remember to clean at session end!**

### Scenario 4: "I keep forgetting to use memory tool"
**Solution:**
- Use the automation script `scripts/session-end-routine.py`
- Make it a habit to check persistence before ending session
- Remember: personal info and facts MUST be persisted!

---

## 📊 Health Indicators (What Good Looks Like)

### ✅ Healthy Brain Signs:
- Core memory (`[[brain/core/memory.md]]`) updated within last 1-2 sessions
- Personal info files filled with actual user data + persisted
- Learning notes added consistently (3-5 per week)
- Average of 4+ wikilinks per note
- Context folder stays under 5 files
- Facts organized atomically by topic

### ❌ Warning Signs:
- Core memory hasn't been updated in 3+ sessions
- Personal info still has empty template text
- Learning notes folder is empty after a month
- Some notes have no incoming links (orphaned)
- Context folder grows beyond 5 files
- "God files" with multiple unrelated topics

---

## 🔗 Quick Links to Start Your Journey

### For New Users:
1. `[[QUICK-START.md]]` - Get started in 3 minutes
2. `[[brain/core/memory.md]]` - Understand current knowledge state
3. `[[brain/.getting-started]]` - Comprehensive getting started guide

### For Understanding the System:
4. `[[projects/evervault-brain-system]]` - Architecture overview
5. `[[system/memory-tool-guide.md]]` - How persistence works
6. `[[brain/core/connection-guide]]` - Linking conventions

### For Mastery Progression:
7. `[[projects/evervault-mastery]]` ← **START HERE!**
8. `[[brain/core/facts/index.md]]` - Browse all atomic facts
9. `[[system/metrics/brain-health-report]]` - Health dashboard

---

## 🎓 Recommended Reading Path for Full Potential

### Day 1: Core Foundation
1. Read `[[QUICK-START.md]]`
2. Read `[[brain/core/memory.md]]` (multiple times if needed)
3. Read `[[projects/evervault-mastery]]` ← **This guide!**

### Day 2: Deep Understanding
4. Read `[[system/memory-tool-guide.md]]` - Critical!
5. Read `[[brain/.getting-started]]` 
6. Browse `[[brain/core/facts/index.md]]` and read a few facts

### Week 1-2: Mastery Path (Follow [[projects/evervault-mastery]])
7. Complete Phase 1 tasks
8. Add first learning notes using template
9. Create personal info files + persist with memory tool

### Month 1+: Optimization
10. Review health metrics in `[[system/metrics/brain-health-report]]`
11. Follow mastery path phases (Fluency → Workflow → Optimization)
12. Customize brain system to your workflow

---

## 🚀 Your Brain is Ready!

Your EverVault PC Brain System is fully built and ready for you to grow it with each session. Remember:

- **Read `[[brain/core/memory.md]]` before each session** - It's your persistent knowledge hub
- **Use the memory tool for personal info and critical facts** - Persistence is non-negotiable!
- **Clean context folder every session end** - Don't let it bloat!
- **Link everything** - Every new note connects to `[[core/memory.md]]` + other notes

For detailed mastery progression, see: `[[projects/evervault-mastery]]`

*Last updated: Session 2026-06-01 initial setup  
Brain architecture version: Multi-layer knowledge graph  
Ready to grow smarter with each session! 🧠✨*

---

## ⚡ Quick Command Cheat Sheet

### Common Operations:

```python
# Read a note
read_file(path="brain/core/memory.md", offset=1, limit=50)

# Search for related content
search_files(pattern="React.*hook", target="content", file_glob="*.md")
search_files(query="LM Studio context", limit=3)

# Persist personal info (CRITICAL!)
content = read_file(path="brain/personal-info/name.md").content
memory(action="add", target="user", content=content)

# Create new learning note
write_file(path="learning/notes/my-discovery.md", content=note_content)

# List all files in a folder
terminal(command=f'ls -la brain/core/facts/')

# Check context folder size
terminal(command=f'find brain/context -type f | wc -l')
```

### Session End Checklist (Automated):
```python
from hermes_tools import read_file, memory

# 1. Persist personal info
for info_file in ["name", "occupation", "location", "tools-and-env"]:
    path = f"brain/personal-info/{info_file}.md"
    content = read_file(path=path).content
    memory(action="add", target="user", content=content)

# 2. Create session log
write_file(path="system/session-notes/session-log-{{date}}.md", ...)

# 3. Clean context folder
terminal(command=f'find brain/context -type f | grep -v archived', limit=5)
```

---

*Happy note-taking! Your brain will grow smarter with every session.* 🧠✨
