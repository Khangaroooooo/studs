#!/usr/bin/env python3
"""
Barricade RL Visual Training - Real-time animation
Shows the 3x3 PvP arena with agents moving and fighting in real-time
Run indefinitely until interrupted (Ctrl+C)
"""

import argparse
import json
import logging
import sys
import time
import random
from datetime import datetime
from enum import Enum
from collections import deque
from pathlib import Path

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)


class Agent(Enum):
    PLAYER1 = 0   # Red team (🔴)
    PLAYER2 = 1   # Blue team (🔵)


class GameState:
    """Simple 3x3 PvP game state"""
    
    def __init__(self, size=3):
        self.size = size
        self.p1_pos = (0, 0)           # P1 starts top-left
        self.p2_pos = (size-1, size-1) # P2 starts bottom-right
        self.p1_health = 100
        self.p2_health = 100
        self.winner = None
    
    def to_dict(self):
        return {
            'p1_pos': list(self.p1_pos),
            'p2_pos': list(self.p2_pos),
            'p1_health': self.p1_health,
            'p2_health': self.p2_health,
            'winner': str(self.winner) if self.winner else None
        }


class BarricadeVisualizer:
    """Real-time visual renderer with continuous animation"""
    
    def __init__(self):
        self.size = 3
        self.state = GameState(size=3)
        self.step_count = 0
    
    @property
    def is_running(self):
        """Game ends when someone wins, but we keep running in demo mode"""
        return True
    
    @property
    def reward(self):
        """Current reward calculation"""
        if self.state.winner:
            return -1.0
        
        dist = abs(self.state.p1_pos[0] - self.state.p2_pos[0]) + \
               abs(self.state.p1_pos[1] - self.state.p2_pos[1])
        base_reward = 4.0 / (dist + 1)
        
        if self.state.p1_health > 50:
            base_reward += 2.5
        else:
            base_reward -= (self.state.p1_health - 50) * 0.1
        
        if self.state.p2_health > 50:
            base_reward += 2.5
        else:
            base_reward -= (self.state.p2_health - 50) * 0.1
        
        return round(base_reward, 1)
    
    def render(self):
        """Render the game grid"""
        
        # Create ASCII grid representation
        rows = []
        for y in range(self.size):
            row = ""
            for x in range(self.size):
                if (x, y) == self.state.p1_pos:
                    hp_pct = int(self.state.p1_health / 100 * 12 + 3)
                    row += f"🔴[{hp_pct}%]"
                elif (x, y) == self.state.p2_pos:
                    hp_pct = int(self.state.p2_health / 100 * 12 + 3)
                    row += f"🔵[{hp_pct}%]"
                else:
                    row += "   "
            rows.append(row)
        
        grid = "\n".join(rows)
        
        p1 = f"P1 🔴 {self.state.p1_pos} ({self.state.p1_health}% HP)"
        p2 = f"P2 🔵 {self.state.p2_pos} ({self.state.p2_health}% HP)"
        
        if self.state.winner:
            winner_str = "🏆 WINNER!" if self.state.p1_health > 0 else "💀 ELIMINATED!"
            return grid + f"\n\n{winner_str}\nP1: {p1}\nP2: {p2}\nReward: {self.reward:.1f}"
        else:
            return grid + f"\n\nP1: {p1}\nP2: {p2}\nReward: {self.reward:.1f}"
    
    def update(self, action_p1=None, action_p2=None):
        """Execute one training step with simple AI"""
        
        # If game already over, reset or skip
        if self.state.winner:
            return
        
        p1 = self.state.p1_pos
        p2 = self.state.p2_pos
        
        # Simple movement AI: always move toward opponent (unless same spot)
        if p1 != p2:
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            
            if abs(dx) >= abs(dy) and dx > 0:
                self.state.p1_pos = (min(self.size-1, p1[0] + 1), p1[1])
            elif abs(dx) >= abs(dy) and dx < 0:
                self.state.p1_pos = (max(0, p1[0] - 1), p1[1])
            elif dy > 0:
                self.state.p1_pos = (p1[0], min(self.size-1, p1[1] + 1))
            elif dy < 0:
                self.state.p1_pos = (p1[0], max(0, p1[1] - 1))
            
            # P2 moves toward P1
            dx = p1[0] - p2[0]
            dy = p1[1] - p2[1]
            
            if abs(dx) >= abs(dy) and dx > 0:
                self.state.p2_pos = (min(self.size-1, p2[0] + 1), p2[1])
            elif abs(dx) >= abs(dy) and dx < 0:
                self.state.p2_pos = (max(0, p2[0] - 1), p2[1])
            elif dy > 0:
                self.state.p2_pos = (p2[0], min(self.size-1, p2[1] + 1))
            elif dy < 0:
                self.state.p2_pos = (p2[0], max(0, p2[1] - 1))
        
        # Check collision damage
        if self.state.p1_pos == self.state.p2_pos and \
           self.state.p1_health > 0 and self.state.p2_health > 0:
            damage = 30
            self.state.p1_health -= damage
            self.state.p2_health -= damage
            
            logger.info(f"    ⚔️  COLLISION! P1: {self.state.p1_health}% HP, "
                       f"P2: {self.state.p2_health}% HP")
        
        # Check win condition
        if self.state.p1_health <= 0 and self.state.p2_health <= 0:
            self.state.winner = None  # Both eliminated - draw scenario
        elif self.state.p1_health <= 0:
            self.state.winner = Agent.PLAYER2
        elif self.state.p2_health <= 0:
            self.state.winner = Agent.PLAYER1
        
        # If someone died, reset health but keep positions
        if self.state.p1_health <= 0:
            self.state.p1_health = 100
        
        if self.state.p2_health <= 0:
            self.state.p2_health = 100
        
        # Save state for persistence
        self.step_count += 1


class EverVaultContext:
    """EverVault context manager"""
    
    def __init__(self):
        self.vault_path = Path.home() / "Documents" / "Evervault" / "context"
        self.state_file = self.vault_path / "barricade_rl_state.json"
        
        self.vault_path.mkdir(parents=True, exist_ok=True)
        
        if self.state_file.exists():
            with open(self.state_file, 'r') as f:
                self.state = json.load(f)
                logger.info(f"Loaded EverVault context")
        else:
            self.state = {
                "epoch": 0,
                "steps": 0,
                "last_state_dict": None,
                "best_reward": -float('inf'),
                "session_start": datetime.now().isoformat(),
                "env_id": None,
                "config": {}
            }
            logger.info("Initialized new EverVault session")
    
    def save_state(self):
        """Save state to EverVault"""
        serializable = {k: v for k, v in self.state.items() 
                       if isinstance(v, (int, float, str, bool))}
        
        with open(self.state_file, 'w') as f:
            json.dump(serializable, f, indent=2)
        logger.info("State saved to EverVault")
    
    def log_to_vault(self, message):
        """Log events to EverVault"""
        timestamp = datetime.now().isoformat()
        with open(self.vault_path / "training_events.log", 'a') as f:
            f.write(f"[{timestamp}] {message}\n")


# Global context (loaded at start)
evervault = EverVaultContext()

def main():
    parser = argparse.ArgumentParser(description='Barricade RL Visual Training')
    parser.add_argument('--demo', action='store_true', help='Run demo mode')
    parser.add_argument('--env', type=str, default=None, help='Environment name')
    parser.add_argument('--speed', type=float, default=0.2, help='Speed in seconds per step')
    
    args = parser.parse_args()
    
    env_id = "simple-pvp-3x3" if args.demo else (args.env or "simple-pvp-3x3")
    speed = min(args.speed, 0.25) if args.speed else 0.18
    
    evervault.log_to_vault(f"=== Visual Training Session ===\n"
                          f"Environment: {env_id}\nSpeed: {speed}s/step\nMode: {'Demo' if args.demo else 'Full'}")
    
    logger.info("🚀 Starting Barricade RL Visual Training with EverVault Context")
    logger.info(f"   Environment: {env_id}")
    logger.info(f"   Speed: {speed}s per step")
    logger.info(f"   Save Directory: /Users/kkhangaroo/models/barricade_rl")
    
    print("\n" + "="*60)
    print("🎮 BARRICADE RL TRAINING - VISUAL MODE 🎮")
    print("="*60)
    print("Press Ctrl+C to stop anytime\n")
    
    visualizer = BarricadeVisualizer()
    evervault.state["session_start"] = datetime.now().isoformat()
    evervault.state["env_id"] = env_id
    evervault.save_state()
    
    step_count = 0
    
    try:
        print("📺 Starting live visualization...\n")
        logger.info("Interactive visualization started...")
        
        while visualizer.is_running:
            # Show current state
            print("\n" + "="*45)
            print(visualizer.render())
            print("="*45 + "\n")
            
            # Update game state (auto-play)
            visualizer.update()
            
            step_count += 1
            
            # Save progress periodically
            if step_count % 50 == 0:
                evervault.state["steps"] = step_count
                evervault.state["best_reward"] = max(
                    evervault.state.get("best_reward", -float('inf')), 
                    abs(visualizer.reward)
                )
                evervault.save_state()
            
            time.sleep(speed)
        
        # Training ended normally
        
    except KeyboardInterrupt:
        print("\n\n" + "="*60)
        print("👋 Training interrupted by user")
        print("="*60)
        print(f"Steps completed: {step_count}")
        print(f"Best reward seen: {evervault.state['best_reward']:.2f}")
        
        # Final save
        evervault.state["steps"] = step_count
        evervault.state["best_reward"] = max(
            evervault.state.get("best_reward", -float('inf')), 
            abs(visualizer.reward) if not visualizer.state.winner else 0
        )
        evervault.save_state()
        
        evervault.log_to_vault(f"Visual session interrupted. Steps: {step_count}, Best reward: {evervault.state['best_reward']:.2f}")


if __name__ == "__main__":
    sys.exit(main())
