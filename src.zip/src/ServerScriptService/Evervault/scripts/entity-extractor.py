#!/usr/bin/env python3
"""
Entity Extractor - Automatic Knowledge Graph Expander (UPDATED 2026-06-08)

Extracts entities, concepts, and relationships from tool outputs and new content,
then creates graph nodes and suggests links to existing knowledge.

USAGE:
    python scripts/entity-extractor.py --analyze        # Show extracted entities without writing
    python scripts/entity-extractor.py --create-links   # Create wikilinks from extractions
"""
import os
import re
from datetime import datetime
from hermes_tools import read_file, write_file, memory

# Configuration
VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "~/Documents/EverVault")
VAULT_PATH = os.path.expanduser(VAULT_PATH)
CONTEXT_DIR = os.path.join(VAULT_PATH, "brain/context")
TEMP_DIR = os.path.join(CONTEXT_DIR, "temp")
GRAPH_DIR = os.path.join(CONTEXT_DIR, "graph")
CORE_MEMORY_FILE = os.path.join(VAULT_PATH, "brain/core/memory.md")


def extract_entities(content):
    """Extract named entities and concepts from content."""
    
    entities = {
        "people": set(),
        "projects": set(),
        "technical_terms": set(),
        "tools": set()
    }
    
    # Extract wikilinks (already structured concepts)
    links = re.findall(r'\[\[([^\]]+)\]\]', content)
    for link in links:
        entities["projects"].add(link)
    
    # Extract headings as concepts
    headings = re.findall(r'#\s*([A-Za-z][A-Za-z0-9_]+(?:\s+[A-Za-z]+)?)', content)
    for heading in headings:
        cleaned = ' '.join(heading.split())  # Normalize whitespace
        if cleaned and len(cleaned) > 3:
            entities["projects"].add(cleaned.replace(' ', '_'))
    
    # Extract tool names (specific pattern for tools/frameworks)
    tool_patterns = ['hermes', 'lm studio', 'obsidian', 'python', 'pandas', 
                     'requests', 'vscode', 'cursor', 'arc browser', 'github']
    for word in re.findall(r'\b([a-zA-Z][a-zA-Z0-9_.\-]*)\b', content):
        if any(tool in word.lower() for tool in tool_patterns) and len(word) > 3:
            # Avoid duplicates from wikilinks
            if word not in entities["projects"]:
                entities["tools"].add(word)
    
    return entities


def extract_relationships(content):
    """Extract relationships between entities."""
    
    relationship_patterns = [
        (r'\b([A-Za-z0-9_. ]+) \bcaused\b \b([A-Za-z0-9_. ]+)\b', ('caused by',)),
        (r'\b([A-Za-z0-9_. ]+) \benhanced\b \b([A-Za-z0-9_. ]+)\b', ('enhanced',)),
        (r'\b([A-Za-z0-9_. ]+) \bbecame\b \b([A-Za-z0-9_. ]+)\b', ('became',)),
    ]
    
    relationships = []
    
    for pattern, _ in relationship_patterns:
        matches = re.findall(pattern, content)
        for match in matches:
            if len(match) == 2 and all(match[0] and match[1]):
                relationships.append((match[0].strip(), match[1].strip()))
    
    return relationships


def persist_to_memory(concept_name, context, importance):
    """Create atomic fact in memory tool for new concept."""
    
    # Check if this is a significant enough concept to persist
    if len(concept_name) < 5:
        return
    
    # Create memory entry with proper format
    content = f"**Atomic fact** - {concept_name} concept.\n\n{context}\n\n*Source: Entity extraction, {datetime.now().strftime('%Y-%m-%d %H:%M')}* \n\n## Related Concepts\n\n- [[core/memory]]\n"
    
    # Get filename from concept name for memory target
    filename = concept_name.replace(' ', '_').replace('.', '').replace('-', '')
    
    # Try to add to user memory (personal facts)
    try:
        memory(action='add', target='user', content=f"{concept_name}: {context}")
        print(f"  ✅ Persisted to memory: {concept_name}")
    except Exception as e:
        print(f"  ⚠️ Memory persistence skipped for {concept_name}: {e}")


def analyze_tool_outputs():
    """Analyze all tool outputs for entities."""
    
    if not os.path.exists(TEMP_DIR):
        return []
    
    outputs = []
    for filename in os.listdir(TEMP_DIR):
        if filename.endswith('.output') and not filename.startswith('.'):
            filepath = os.path.join(TEMP_DIR, filename)
            try:
                content = read_file(path=filepath).content
                outputs.append({
                    "filename": filename,
                    "filepath": filepath,
                    "word_count": len(content.split()),
                    "content": content
                })
            except Exception as e:
                print(f"  ⚠️ Error reading {filename}: {e}")
    
    return outputs


def get_existing_graph_nodes():
    """Get all existing graph nodes for link suggestion."""
    
    if not os.path.exists(GRAPH_DIR):
        return []
    
    nodes = []
    for filename in os.listdir(GRAPH_DIR):
        if filename.endswith('.md') and not filename.startswith('.') and 'concept-' in filename:
            filepath = os.path.join(GRAPH_DIR, filename)
            try:
                content = read_file(path=filepath).content
                nodes.append({
                    "filename": filename,
                    "filepath": filepath,
                    "word_count": len(content.split()),
                    "created_at": datetime.fromtimestamp(os.path.getmtime(filepath))
                })
            except Exception as e:
                print(f"  ⚠️ Error reading {filename}: {e}")
    
    return nodes


def get_existing_facts():
    """Get all atomic facts for link suggestions."""
    
    facts_dir = os.path.join(VAULT_PATH, "brain/core/facts")
    
    if not os.path.exists(facts_dir):
        return []
    
    facts = []
    for filename in os.listdir(facts_dir):
        if filename.endswith('.md') and not filename.startswith('.'):
            filepath = os.path.join(facts_dir, filename)
            try:
                content = read_file(path=filepath).content
                facts.append({
                    "filename": filename,
                    "filepath": filepath,
                    "word_count": len(content.split()),
                    "content": content
                })
            except Exception as e:
                print(f"  ⚠️ Error reading {filename}: {e}")
    
    return facts


def find_similar_existing_entities(concept_name, all_facts):
    """Find existing notes that mention this concept."""
    
    matches = []
    lower_name = concept_name.lower()
    
    for fact in all_facts:
        if lower_name in fact["content"].lower():
            matches.append({
                "concept": concept_name,
                "existing_file": fact["filename"],
                "match_type": "technical_terms"
            })
            
    return matches


def main():
    """Main execution."""
    print("=" * 60)
    print("ENTITY EXTRACTOR - Graph Expansion Engine (UPDATED 2026-06-08)")
    print("=" * 60)
    
    import sys
    
    # Parse arguments
    analyze_only = "--analyze" in sys.argv
    create_links = "--create-links" in sys.argv
    
    outputs = analyze_tool_outputs()
    
    if not outputs:
        print("\nNo tool outputs found to process.")
        return
    
    print(f"\nAnalyzing {len(outputs)} tool output(s)...")
    
    all_entities = {
        "projects": set(),
        "technical_terms": set(),
        "people": set(),
        "tools": set()
    }
    all_relationships = []
    
    # Extract from each output
    for i, output in enumerate(outputs, 1):
        print(f"\n  [{i}/{len(outputs)}] Processing {output['filename']}...")
        
        entities = extract_entities(output["content"])
        
        for entity_type in ["projects", "technical_terms"]:
            getattr(all_entities, entity_type).update(getattr(entities, entity_type, set()))
        
        # Collect relationships
        relationships = extract_relationships(output["content"])
        all_relationships.extend(relationships)
        
        # Process each new concept as atomic fact
        for concept in list(entities["projects"])[:2]:  # Limit to top concepts
            persist_to_memory(concept, output["content"], "medium")
        
        # Extract interesting tools mentioned
        for tool in list(entities["tools"])[:2]:
            if len(tool) > 5:  # Only significant terms
                persist_to_memory(tool, f"Extracted from tool output: {output['filename']}", "low")
    
    print(f"\nExtracted:")
    print(f"   - {len(all_entities['projects'])} unique projects/concepts")
    print(f"   - {len(all_entities['technical_terms'])} unique technical terms")
    print(f"   - {len(all_entities['tools'])} unique tools")
    
    if analyze_only:
        print("\nAnalysis complete. Use --create-links to create wikilinks.")
        return
    
    # Get existing facts for link suggestions
    all_facts = get_existing_facts()
    print(f"\nFound {len(all_facts)} existing atomic facts for link suggestions")
    
    # Create or update graph nodes with real entities
    new_entities_added = 0
    
    for concept in list(all_entities["projects"])[:5]:  # Limit to avoid creating too many files
        clean_concept = concept.replace(' ', '_').replace('.', '').replace('-', '')
        filepath = os.path.join(GRAPH_DIR, f"concept-{clean_concept}.md")
        
        try:
            # Create new graph node with proper structure
            if not os.path.exists(filepath):
                content = f"""# Graph Node: {concept}

This node tracks concept across multiple tool outputs.

## Extracted From
- Tool outputs: Recent session analysis

## Related Concepts
- [[core/memory]]
- [[tools/{clean_concept.lower() if clean_concept.lower().endswith('.md') else clean_concept}]
"""
                write_file(path=filepath, content=content)
                new_entities_added += 1
                print(f"  ✅ Created graph node: concept-{clean_concept}")
                
            # Check for similar existing facts and suggest links
            similar = find_similar_existing_entities(concept, all_facts)
            if similar:
                print(f"    Found {len(similar)} related facts for linking")
                
        except Exception as e:
            print(f"  ⚠️ Error creating node for {concept}: {e}")
    
    if new_entities_added > 0:
        # Update core memory with session summary
        try:
            core_content = read_file(path=CORE_MEMORY_FILE).content
            
            # Add session note
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
            session_note = f"""
## Session {timestamp} - Entity Extraction

- **Source**: Tool outputs from active context window
- **New concepts identified**: {len(all_entities["projects"])} projects/concepts
- **New technical terms**: {len(all_entities["technical_terms"])}
- **New tools mentioned**: {len(all_entities["tools"])}
- **Graph nodes created**: {new_entities_added}

*See `[[graph/index]]` for updated graph topology*
"""
            write_file(path=CORE_MEMORY_FILE, content=core_content + session_note)
            print(f"\n  ✅ Updated core memory with entity extraction summary")
            
        except Exception as e:
            print(f"  ⚠️ Error updating core memory: {e}")
    
    print("\n" + "=" * 60)
    print(f"🎉 ENTITY EXTRACTION COMPLETE!")
    print(f"Created {new_entities_added} new graph nodes")
    print("=" * 60)


if __name__ == "__main__":
    main()
