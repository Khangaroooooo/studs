#!/usr/bin/env python3
"""
State Capture Utility for Barricade.gg RL Agent
Standalone state capture tool for testing and development."""

import argparse
import os
from pathlib import Path
from datetime import datetime


def capture_state(mode='test'):
    """
    Capture game state from Barricade.gg.
    
    Uses Hermes browser tools to:
    - Take screenshot (for vision model)
    - Parse DOM elements for game state
    - Extract turn counter, positions if exposed in HTML
    
    Args:
        mode: 'test' or 'training' - determines what information to capture
    
    Returns:
        Dictionary containing captured state information
    """
    
    print("="*60)
    print("📷 BARRICADE STATE CAPTURE UTILITY")
    print("="*60)
    print(f"\nMode: {mode}")
    
    try:
        # Navigate to Barricade.gg
        from hermes_tools import browser_navigate, browser_snapshot, browser_console, browser_get_images
        
        print("\n🌐 Navigating to Barricade.gg...")
        base_url = "https://barricade.gg"
        
        if mode == 'training':
            url = base_url + "/play"  # Play mode for training
        else:
            url = base_url
        
        browser_navigate(url)
        print("✅ Page loaded successfully")
        
        # Take screenshot via browser_get_images()
        print("\n📸 Capturing screenshots...")
        images = browser_get_images()
        print(f"   Found {len(images)} images on page")
        
        if len(images) > 0:
            first_image = images[0]
            print(f"   First image URL: {first_image['url'][:100]}...")
            
            # For demo purposes, use the first available image
            screenshot_url = first_image['url']
        else:
            screenshot_url = None
            
        # Parse DOM for state info
        print("\n📄 Parsing DOM elements...")
        
        # Get visible text content from page
        dom_state = browser_console(expression='document.body.innerText')
        
        if isinstance(dom_state, str) and len(dom_state) > 0:
            print(f"   DOM text length: {len(dom_state)} characters")
            
            # Extract key elements from DOM (simplified - real implementation parses for game-specific elements)
            import re
            
            # Look for position indicators in DOM
            position_patterns = [
                r'position\s*[:=]\s*(\d+)',  # Position: number
                r'tile\s*[:=]\s*(\d+)',     # Tile: number
                r'my-position|player1-pos\s*[:=]\s*(\d+)',  # Player position
            ]
            
            positions = {}
            for pattern in position_patterns:
                matches = re.findall(pattern, dom_state)
                if matches:
                    positions[pattern] = [int(m) for m in matches[:3]]  # Take first 3 matches
            
            print(f"   Position patterns found: {list(positions.keys())}")
            
        else:
            positions = {}
            print("   No position data extracted from DOM")
        
        # Capture browser console state
        console_output = browser_console(clear=True)
        
        if len(console_output) > 0:
            print(f"\n📋 Console output captured: {len(console_output)} lines")
            
            # Show first few console lines (simplified - real implementation would filter for game state)
            for line in console_output[:3]:
                print(f"   - {line[:100]}...")
        else:
            print("   No console output captured")
        
        # Combine visual and DOM information into state representation
        state = {
            'timestamp': datetime.now().isoformat(),
            'mode': mode,
            'url': url,
            'screenshot_url': screenshot_url,
            'dom_state_length': len(dom_state) if isinstance(dom_state, str) else 0,
            'console_lines_captured': len(console_output),
            'positions': positions,
            'game_phase': 'unknown',  # Would be determined from visual analysis
            'risk_score': 0.5,  # Placeholder - needs visual model or rule-based calculation
            'turn': None,  # Will be extracted from DOM or game UI
        }
        
        print("\n" + "="*60)
        print("✅ STATE CAPTURE COMPLETE")
        print("="*60)
        
        print("\nCaptured state summary:")
        for key, value in state.items():
            if isinstance(value, str):
                display_value = value[:50] + "..." if len(value) > 50 else value
                print(f"  {key}: {display_value}")
            else:
                print(f"  {key}: {value}")
        
        return state
        
    except Exception as e:
        print(f"\n❌ State capture failed with error: {e}")
        import traceback
        traceback.print_exc()
        raise


def test_capture():
    """Run state capture in test mode (quick check)."""
    print("="*60)
    print("🧪 STATE CAPTURE TEST MODE")
    print("="*60)
    
    return capture_state(mode='test')


def training_capture():
    """Run state capture in training mode (full details)."""
    print("\n" + "="*60)
    print("🎮 STATE CAPTURE TRAINING MODE")
    print("="*60)
    
    return capture_state(mode='training')


def main():
    parser = argparse.ArgumentParser(
        description='State Capture Utility for Barricade.gg RL Agent',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Test capture (quick check)
  python scripts/capture_barricade_state.py --mode=test
  
  # Training mode capture (full details)
  python scripts/capture_barricade_state.py --mode=training

Environment variables:
  BARRICADE_MODE=TRAINING|TEST
"""
    )
    
    parser.add_argument(
        '--mode',
        choices=['test', 'training'],
        default=os.environ.get('BARRICADE_MODE', 'test').lower(),
        help='Capture mode (default: test)'
    )
    
    args = parser.parse_args()
    
    try:
        if args.mode == 'test':
            state = test_capture()
        else:
            state = training_capture()
            
        # Save captured state to file
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = Path(__file__).parent / f"state_capture_{timestamp}.json"
        
        with open(output_file, 'w') as f:
            import json
            json.dump(state, f, indent=2)
        
        print(f"\n📁 State data saved to: {output_file}")
        
    except Exception as e:
        print(f"\n❌ Capture failed: {e}")
        raise


if __name__ == '__main__':
    main()
