#!/usr/bin/env python3
"""
Context Sentinel - ⏰ Automatic Context Management System

The brain's immune system - runs periodically to maintain context health by archiving old files.

Automatically archives files older than threshold (configurable via --days).

Usage:
    python scripts/context-sentinel.py                  # Auto-archive old files
    python scripts/context-sentinel.py --help           # Show options
"""
import os
from datetime import datetime, timedelta
from pathlib import Path


VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "~/Documents/EverVault")
VAULT_PATH = os.path.expanduser(VAULT_PATH)
CONTEXT_DIR = os.path.join(VAULT_PATH, "brain/context")


def get_old_files(directory, days_threshold=7):
    """Get files older than threshold in directory."""
    if not os.path.exists(directory):
        return []
    
    old_files = []
    now = datetime.now()
    threshold = timedelta(days=days_threshold)
    
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        
        # Skip non-files or hidden files
        if not os.path.isfile(filepath):
            continue
        
        if filename.startswith('.') or '.archived' in filename:
            continue
            
        try:
            file_mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
            age_delta = now - file_mtime
            
            if age_delta > threshold:
                old_files.append({
                    "filename": filename,
                    "filepath": filepath,
                    "age_days": age_delta.days,
                    "age_hours": age_delta.total_seconds() / 3600,
                    "size_bytes": os.path.getsize(filepath)
                })
                
        except Exception as e:
            print(f"⚠️ Error checking {filename}: {e}")
    
    # Sort by age (oldest first)
    old_files.sort(key=lambda x: x["age_days"], reverse=True)
    
    return old_files


def archive_file(filepath, dest_dir):
    """Archive a file with timestamp to preserve history."""
    filename = os.path.basename(filepath)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    new_filename = f"{filename}.archived-{timestamp}.md"
    dest_path = os.path.join(dest_dir, new_filename)
    
    print(f"  📦 Archiving: {filename} → {new_filename}")
    
    try:
        with open(filepath, 'r') as src:
            content = src.read()
        
        with open(dest_path, 'w') as dst:
            dst.write(content)
        
        # Remove original file
        os.remove(filepath)
        
        return True
        
    except Exception as e:
        print(f"  ⚠️ Error archiving {filename}: {e}")
        return False


def main():
    """Main execution."""
    import sys
    
    print("=" * 60)
    print("🕰️  CONTEXT SENTINEL - Auto-Archive System")
    print("=" * 60)
    
    # Parse arguments
    if len(sys.argv) > 1 and "--help" in sys.argv:
        print("""
Context Sentinel - Automatic Context Management System

Usage:
    python scripts/context-sentinel.py            # Archive files older than 7 days
    python scripts/context-sentinel.py --days=14  # Archive files older than 14 days
    python scripts/context-sentinel.py --help     # Show this help message

Description:
    Automatically archives old files from brain/context/active/
    to brain/context/archived/ to maintain context health.
    
    Configurable via --days flag (default: 7).
        """)
        return
    
    # Get threshold from argument or use default
    days_threshold = int(sys.argv[1]) if len(sys.argv) > 2 else 7
    
    active_dir = os.path.join(CONTEXT_DIR, "active")
    archived_dir = os.path.join(CONTEXT_DIR, "archived")
    
    os.makedirs(archived_dir, exist_ok=True)
    
    # Find old files
    print(f"\n🔍 Scanning brain/context/active/ for files older than {days_threshold} days...")
    
    old_files = get_old_files(active_dir, days_threshold)
    
    if not old_files:
        print(f"✅ No files older than {days_threshold} days found.")
        return
    
    print(f"\n📊 Found {len(old_files)} files to archive:")
    for file in old_files[:5]:  # Show first 5
        print(f"  • {file['filename']:.40}... (age: {file['age_days']} days)")
    
    if len(old_files) > 5:
        print(f"  ... and {len(old_files) - 5} more files")
    
    # Confirm archival
    print(f"\n⚡ Ready to archive {len(old_files)} file(s). Execute? (y/n)")
    
    # Execute or ask for confirmation
    if len(sys.argv) > 1 and "--execute" in sys.argv:
        confirm = "yes"
    else:
        try:
            confirm = input("> ").strip().lower()
        except:
            confirm = "y"  # Default to execute in non-interactive mode
    
    if confirm in ['y', 'yes']:
        print("\n📦 Executing archival...")
        
        archived_count = 0
        for file_info in old_files:
            filepath = file_info["filepath"]
            success = archive_file(filepath, archived_dir)
            
            if success:
                archived_count += 1
        
        print(f"\n✨ Archived {archived_count} file(s) to brain/context/archived/")
        
    else:
        print("🚫 Aborted.")


if __name__ == "__main__":
    main()
