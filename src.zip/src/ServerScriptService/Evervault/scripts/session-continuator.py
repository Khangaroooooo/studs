#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Session Continuator - Auto-Session Continuation Orchestrator ⭐

This script orchestrates auto-session continuation by loading all persisted state
and providing clear next steps for continuing work.

Usage:
    python scripts/session-continuator.py                    # Full continuation
    python scripts/session-continuator.py --skip-summary      # Skip state summary generation
    python scripts/session-continuator.py --check-persistence # Verify persisted state only

See Also:
    - [[brain/core/memory]] - Persistent memory hub
    - [[system/session-notes/]] - Session history and context
    - [[scripts/session-end-routine]] - Current session cleanup automation
"""

import os
import sys
from datetime import datetime
from hermes_tools import read_file, memory

# Configuration
VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "~/Documents/EverVault")
VAULT_PATH = os.path.expanduser(VAULT_PATH)

CONTINUATION_CONFIG = {
    "core_memory": "brain/core/memory.md",
    "personal_info_dir": "brain/personal-info",
    "facts_dir": "brain/core/facts",
    "session_notes_dir": "system/session-notes",
    "state_summary_file": "brain/context/state-summary.md",
}


def load_persistent_state():
    """Load all Layer 1 persistence for session continuation."""
    print("\n" + "=" * 70)
    print("🔄 SESSION CONTINUATION - Loading Persisted State")
    print("=" * 70)

    state = {
        "core_memory": None,
        "personal_info": {},
        "facts": [],
        "persistence_check": True,
        "recent_sessions": []
    }

    # Load core memory hub
    if os.path.exists(VAULT_PATH):
        core_mem_path = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["core_memory"])
        if os.path.exists(core_mem_path):
            try:
                state["core_memory"] = read_file(path=core_mem_path).content
                print(f"\n✅ Loaded core memory hub from {CONTINUATION_CONFIG['core_memory']}")
            except Exception as e:
                print(f"\n⚠️ Could not load core memory: {e}")

    else:
        # Load from memory tool if available
        try:
            state["core_memory"] = memory(action="list", limit=100)
            print("\n✅ Loaded persisted facts from memory tool")
        except Exception as e:
            print(f"\n⚠️ Could not load from memory tool: {e}")

    # Load personal info files (identity facts - CRITICAL!)
    personal_info_dir = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["personal_info_dir"])
    if os.path.exists(personal_info_dir):
        for filename in sorted(os.listdir(personal_info_dir)):
            if filename.endswith(".md"):
                file_path = os.path.join(personal_info_dir, filename)
                try:
                    content = read_file(path=file_path).content
                    state["personal_info"][filename] = content
                    print(f"✅ Loaded personal info: {filename}")
                except Exception as e:
                    print(f"⚠️ Could not load {filename}: {e}")

    # Load atomic facts list
    facts_dir = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["facts_dir"])
    if os.path.exists(facts_dir):
        for filename in sorted(os.listdir(facts_dir)):
            if filename.endswith(".md"):
                state["facts"].append(filename)
        
        print(f"\n📊 Fact catalog loaded: {len(state['facts'])} atomic facts available")

    # Load session history (recent context from last 5 sessions)
    session_notes_dir = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["session_notes_dir"])
    if os.path.exists(session_notes_dir):
        note_files = sorted(os.listdir(session_notes_dir), reverse=True)[:5]
        for filename in note_files:
            file_path = os.path.join(session_notes_dir, filename)
            try:
                content = read_file(path=file_path).content
                state["recent_sessions"].append({
                    "file": filename,
                    "content": content[:2000]  # First 2000 chars for context
                })
            except Exception as e:
                print(f"⚠️ Could not load session note {filename}: {e}")

        if state["recent_sessions"]:
            print(f"\n📜 Session history loaded: {len(state['recent_sessions'])} recent sessions")

    else:
        print("\n⚠️ No session notes directory found (this is okay for new sessions)")

    # Persistence check
    if os.path.exists(VAULT_PATH):
        personal_info_files = [f for f in os.listdir(personal_info_dir) if f.endswith(".md")]
        state["persistence_check"] = len(state["personal_info"]) > 0
        print(f"\n🔍 Persistence Check:")
        print(f"   - Core memory hub: {'Loaded' if state['core_memory'] else 'Not loaded'}")
        print(f"   - Personal info files: {len(state['personal_info'])} loaded")
        print(f"   - Fact catalog: {len(state['facts'])} facts available")

    return state


def generate_state_summary():
    """Generate session state summary for continuity context."""
    print("\n" + "=" * 70)
    print("📊 Generating Session State Summary")
    print("=" * 70)

    # Build summary content
    lines = [
        "---",
        "title: state-summary",
        "topics: [[core/memory]], [[system/session-notes/]]",
        f"date: {datetime.now().strftime('%Y-%m-%d')}",
        "status: active",
        "last-reviewed: " + datetime.now().strftime("%Y-%m-%d %H:%M"),
        "created-by: session-continuator.py",
        "---",
        "",
        "# Session State Summary - Continuity Context",
        "",
        "*Generated automatically by session-continuator.py for seamless session continuation.*",
        "",
        "---",
        "",
        "## Current Memory Highlights",
        "",
    ]

    # Add core memory content (first 500 chars)
    if state["core_memory"]:
        lines.append(state["core_memory"][:1000].replace("\n\n", "\n"))

    lines.extend([
        "",
        "### Personal Identity (Persistent Across Sessions)",
        ""
    ])

    # Add personal info highlights
    if state["personal_info"]:
        for filename, content in sorted(state["personal_info"].items()):
            title = os.path.basename(filename).replace(".md", "")
            summary = content.split('\n')[0]
            lines.append(f"- [[{title}]]: {summary[:100]}...")
    else:
        lines.append("*Personal info loaded but not shown in summary for brevity.*")

    lines.extend([
        "",
        "### Atomic Fact Catalog",
        "**Total facts**: " + str(len(state["facts"])) + " atomic knowledge units available",
        "",
        "- Facts cover: tools, environment, architecture, preferences, patterns, projects",
        "- See `[[core/facts/index.md]]` for complete fact index",
        "- New facts should be created as atomic units (one idea per note)",
        ""
    ])

    # Add recent session highlights
    if state["recent_sessions"]:
        lines.extend([
            "### Recent Session History",
            "",
            "**Recent sessions for continuity context**:",
            ""
        ])
        for i, session in enumerate(state["recent_sessions"], 1):
            filename = os.path.basename(session["file"])
            summary = session["content"][:200]
            lines.append(f"**{i}. {filename}**")
            lines.append(summary)
            lines.append("---")
    else:
        lines.extend([
            "",
            "*No previous sessions found - this is your first session!*",
            ""
        ])

    # Add continuation instructions
    lines.extend([
        "## Next Steps for Continuation",
        "",
        "Based on current persisted state:",
        "",
        "1. **Review core memory** - Read `[[core/memory.md]]` to understand current knowledge state",
        "",
        "2. **Check pending work** - Review projects/ and tasks/ folders for active work items",
        "",
        "3. **Start fresh session** - You're ready to continue where you left off!",
        ""
    ])

    # Write state summary
    from hermes_tools import write_file
    
    try:
        summary_path = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["state_summary_file"])
        lines_content = "\n".join(lines)
        write_file(path=summary_path, content=lines_content + "\n")
        print(f"\n✅ State summary written to: {CONTINUATION_CONFIG['state_summary_file']}")
        return lines_content
    except Exception as e:
        print(f"\n⚠️ Could not write state summary: {e}")
        return "\n".join(lines)


def check_persistence():
    """Check what persisted from previous session."""
    print("\n" + "=" * 70)
    print("🔍 PERSISTENCE VERIFICATION CHECK")
    print("=" * 70)

    checks = []

    # Check 1: Core memory hub exists and has content
    core_mem_path = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["core_memory"])
    if os.path.exists(core_mem_path):
        content = read_file(path=core_mem_path).content
        line_count = len(content.split('\n'))
        checks.append({
            "name": "Core memory hub",
            "status": "✅ Exists",
            "details": f"{line_count} lines, persistent knowledge hub"
        })
    else:
        checks.append({
            "name": "Core memory hub", 
            "status": "⚠️ Not found",
            "details": "Will be created on first use"
        })

    # Check 2: Personal info files
    personal_info_dir = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["personal_info_dir"])
    if os.path.exists(personal_info_dir):
        personal_files = [f for f in os.listdir(personal_info_dir) if f.endswith(".md")]
        checks.append({
            "name": "Personal info files",
            "status": str(len(personal_files)) + " loaded ✅",
            "details": "Identity facts persisted across sessions"
        })
    else:
        checks.append({
            "name": "Personal info files",
            "status": "⚠️ Not found",
            "details": "Will be created when needed"
        })

    # Check 3: Fact catalog
    facts_dir = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["facts_dir"])
    if os.path.exists(facts_dir):
        fact_files = [f for f in os.listdir(facts_dir) if f.endswith(".md")]
        checks.append({
            "name": "Fact catalog",
            "status": str(len(fact_files)) + " atomic facts ✅",
            "details": "Granular knowledge units for linking"
        })
    else:
        checks.append({
            "name": "Fact catalog", 
            "status": "⚠️ Not found",
            "details": "Will be built as facts are discovered"
        })

    # Check 4: Session notes
    session_notes_dir = os.path.join(VAULT_PATH, CONTINUATION_CONFIG["session_notes_dir"])
    if os.path.exists(session_notes_dir):
        note_files = [f for f in os.listdir(session_notes_dir) if f.endswith(".md")]
        checks.append({
            "name": "Session notes",
            "status": str(len(note_files)) + " sessions logged ✅",
            "details": "Continuity context from previous work"
        })
    else:
        checks.append({
            "name": "Session notes",
            "status": "⚠️ Empty directory",
            "details": "New session - will log after first use"
        })

    # Check 5: Memory tool
    try:
        memory_list = memory(action="list")
        checks.append({
            "name": "Memory tool persistence", 
            "status": str(len(memory_list)) + " facts persisted ✅",
            "details": "Critical facts survive across sessions"
        })
    except Exception as e:
        checks.append({
            "name": "Memory tool", 
            "status": "⚠️ " + str(e)[:50], 
            "details": "Verify memory tool is configured"
        })

    # Print results
    for check in checks:
        print(f"\n{check['status']}")
        print(f"   - {check['name']}: {check['details']}")

    return checks


def main():
    """Main continuation orchestrator."""
    
    # Parse arguments
    skip_summary = "--skip-summary" in sys.argv
    check_persistence_only = "--check-persistence" in sys.argv

    if check_persistence_only:
        check_persistence()
        return

    print("\n" + "🚀 AUTO-SESSION CONTINUATION ORCHESTRATOR")
    print("=" * 70)
    print("Loading persisted state from previous session...")

    # Load persisted state
    state = load_persistent_state()

    # Generate continuation summary (unless skipped)
    if not skip_summary:
        generate_state_summary()

    # Print continuation summary
    print("\n" + "=" * 70)
    print("✅ CONTINUATION COMPLETE - Ready for New Session!")
    print("=" * 70)

    fact_count = len(state["facts"]) if state else 0
    
    print("""

📋 WHAT WAS LOADED FOR CONTINUATION:

✅ Core memory hub (brain/core/memory.md)
   - Persistent knowledge base from all previous sessions
   
✅ Personal identity facts (brain/personal-info/*.md)
   - Your name, occupation, location, tools, preferences, brain-rules
   
✅ Atomic fact catalog (brain/core/facts/*.md)
   - {fact_count} granular knowledge units for linking and search

✅ Session history (system/session-notes/)
   - Recent session summaries and highlights
   - Key learnings and discoveries from each session

✅ State summary (brain/context/state-summary.md)
   - Continuity context: what you were working on, recent projects, pending tasks
   
🧠 Your knowledge is fully preserved! Start your new session where you left off.

---

📚 NEXT STEPS:

1. Open a NEW Hermes session
2. Load persisted state (core/memory.md + memory tool facts)
3. Review brain/context/state-summary.md for continuity context  
4. Continue working on active projects/tasks
5. Update core/memory.md with new discoveries from this session

🎉 Continuation successful! No progress lost!

""")


if __name__ == "__main__":
    main()
