"""
Context folder cleanup script - Review and archive old/temporary files

Run at session end to prevent context folder bloat.
Checklist says this is NON-NEGOTIABLE!
"""
import os

def list_context_files():
    """List all files in context folder with recommendations"""
    
    if not os.path.exists("brain/context/"):
        print("✅ Context folder doesn't exist - good! (it's temporary)")
        return
    
    files = [f for f in os.listdir("brain/context/") if not f.startswith('.')]
    
    if len(files) == 0:
        print("✅ Context folder is empty - no cleanup needed")
        return
    
    print(f"\n📁 Found {len(files)} files in brain/context/:")
    print("-" * 60)
    
    for filename in sorted(files):
        filepath = os.path.join("brain/context/", filename)
        
        # Get file size
        try:
            stat = os.stat(filepath)
            size_mb = stat.st_size / (1024 * 1024)
        except:
            size_mb = 0
        
        print(f"\n{filename} ({size_mb:.2f} MB)")
        
        # Check file age (simple name-based check since we don't have metadata yet)
        if 'temp' in filename.lower() or 'scratch' in filename.lower():
            action = "🗑️ DELETE - temporary file"
        elif '.gitkeep' in filename:
            action = "📝 TEMPLATE - ignore (placeholder)"
        else:
            action = "🤔 REVIEW - move to learning/notes/ or archive?"
        
        print(f"  → Recommendation: {action}")

if __name__ == "__main__":
    list_context_files()