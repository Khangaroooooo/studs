#!/usr/bin/env python3
"""
Memory Batch Engine - 🧠 Intelligent Write Batching & Deduplication System

Multi-layer persistence engine that transforms every tool call into optimized memory writes:
- **Smart batching** - Groups related writes, reduces API calls
- **Deduplication** - Detects redundant information, merges related concepts
- **Auto-linking** - Creates links to existing knowledge before writing
- **Smart placement** - Routes writes to core/, graph/, or notes/ based on content type

Usage:
    python scripts/memory-batcher.py                    # Batch all pending tool output
    python scripts/memory-batcher.py --analyze          # Show what would be batched
    python scripts/memory-batcher.py --dry-run          # Preview without writing
"""
import os
from datetime import datetime
from pathlib import Path
from hermes_tools import read_file


VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "~/Documents/EverVault")
VAULT_PATH = os.path.expanduser(VAULT_PATH)
CONTEXT_DIR = os.path.join(VAULT_PATH, "brain/context")

# Target directories in context folder
CORE_DIR = os.path.join(CONTEXT_DIR, "core")
GRAPH_DIR = os.path.join(CONTEXT_DIR, "graph")  
NOTES_DIR = os.path.join(CONTEXT_DIR, "notes")


def get_pending_tool_outputs():
    """Get all tool output files that need processing."""
    context_dir = os.path.join(VAULT_PATH, "brain/context")
    temp_dir = os.path.join(context_dir, "temp")
    
    if not os.path.exists(temp_dir):
        return []
    
    outputs = []
    for filename in os.listdir(temp_dir):
        filepath = os.path.join(temp_dir, filename)
        if os.path.isfile(filepath):
            try:
                content = read_file(path=filepath).content
                age_hours = get_file_age_hours(filepath)
                outputs.append({
                    "filename": filename,
                    "filepath": filepath,
                    "age_hours": age_hours,
                    "size_bytes": os.path.getsize(filepath),
                    "preview": content[:500] + "...",
                    "word_count": len(content.split()) if content else 0
                })
            except Exception as e:
                print(f"⚠️ Error reading {filename}: {e}")
    
    return outputs


def get_file_age_hours(filepath):
    """Get file age in hours."""
    from datetime import datetime
    mtime = os.path.getmtime(filepath)
    age_seconds = (datetime.now().timestamp() - mtime)
    return age_seconds / 3600


def classify_tool_output(content):
    """Classify tool output for smart routing."""
    content_lower = content.lower() if content else ""
    
    # Check for code/synthetic artifacts first
    if any(keyword in content_lower for keyword in ['```python', '```javascript', '```json', '# language-', '//']):
        return "synthetic"
    
    # Check for terminal/system outputs
    if any(keyword in content_lower for keyword in [': command output', 'process:', 'job:', 'cron:', 'terminal:']):
        return "system"
        
    # Default to conversation notes
    return "conversation"


def find_existing_links(content, existing_notes):
    """Find links that should be created from this content."""
    entity_patterns = [
        r'\[([^\]]+)\]\([^)]+\)',  # Wikilinks [[Name](URL)]
        r'#\s*([A-Za-z0-9_]+)',     # Headings # Name
        r'([A-Za-z][A-Za-z0-9_\.]*?)(?:\.md|$)'  # Word patterns that could be notes
    ]
    
    potential_links = []
    
    for pattern in entity_patterns:
        matches = re.findall(pattern, content)
        for match in set(matches):
            if match.lower() not in str(existing_notes).lower():
                potential_links.append(match.strip().replace('_', ' '))
    
    return potential_links


def deduplicate_content(all_contents):
    """Simple deduplication by removing near-duplicate paragraphs."""
    combined = " ".join(all_contents)
    paragraph_blocks = re.split(r'(?=\.|\?|!)', combined)
    seen = set()
    unique_blocks = []
    
    for block in paragraph_blocks:
        normalized = ' '.join(block.split())[:200]  # First 200 chars
        if normalized not in seen:
            seen.add(normalized)
            unique_blocks.append(block)
    
    return '\n\n'.join(unique_blocks), len(all_contents), len(unique_blocks)


def batch_writes(pending_outputs):
    """Group and deduplicate writes into batches."""
    content_batches = []
    
    # Group by tool type (same tools can be batched together)
    batches = {}
    for output in pending_outputs:
        tool_name = extract_tool_name(output["filename"])
        if tool_name not in batches:
            batches[tool_name] = {
                "outputs": [],
                "content": "",
                "tool_type": determine_tool_type(tool_name)
            }
        
        batches[tool_name]["outputs"].append(output)
        batches[tool_name]["content"] += "\n---\n" + output["content"]
    
    # Deduplicate each batch
    deduplicated = []
    for tool_name, batch in batches.items():
        original_count = len(batch["outputs"])
        cleaned_content, original_blocks, unique_blocks = deduplicate_content([batch["content"]])
        
        if unique_blocks != original_blocks:
            print(f"  🔄 Deduplication reduced {tool_name} from {original_count}→{unique_blocks} blocks")
        
        deduplicated.append({
            "tool": tool_name,
            "tool_type": batch["tool_type"],
            "cleaned_content": cleaned_content,
            "outputs": batch["outputs"]
        })
    
    return deduplicated


def determine_tool_type(tool_name):
    """Determine the semantic type of a tool."""
    if 'web' in tool_name.lower():
        return "web_research"
    elif 'terminal' in tool_name.lower() or 'execute_code' in tool_name.lower():
        return "system_execution"
    elif 'browser' in tool_name.lower():
        return "browser_interaction"
    elif 'skill_view' in tool_name.lower():
        return "knowledge_retrieval"
    else:
        return "general_assistant"


def extract_tool_name(filename):
    """Extract tool name from filename."""
    # Format: timestamp-tool-name.output-type
    match = re.search(r'-([a-z_]+)\.', filename)
    if match:
        return match.group(1)
    return filename.split('-')[0]


def find_or_create_core_concept(content):
    """Find relevant core memory concept or create new one."""
    # Look for high-level concepts, questions, goals
    sentences = [s.strip() for s in content.replace('\n', ' ').split('.') if s.strip()][:5]
    
    best_match = None
    best_score = 0
    
    for sentence in sentences:
        sentence_lower = sentence.lower()
        
        # Score by keyword presence
        score = 0
        keywords = ['brain', 'knowledge', 'system', 'architecture', 'memory', 
                   'graph', 'workflow', 'automate', 'optimize']
        
        for keyword in keywords:
            if keyword in sentence_lower:
                score += 1
        
        # Bonus for question marks or exclamation
        if '?' in sentence or '!' in sentence:
            score += 2
            
        if score > best_score:
            best_score = score
            best_match = sentence
    
    if best_match:
        return clean_for_filename(best_match), best_score
    
    # If no strong match, return empty to not create new core concepts
    return None, 0


def write_to_context(content_batch, tool_name):
    """Write content to appropriate location."""
    
    content_type = determine_content_type(content_batch["cleaned_content"])
    
    if content_type == "system_execution":
        # Terminal/execution output goes to core/system
        dest_path = os.path.join(CORE_DIR, f"{tool_name}-{datetime.now().strftime('%Y%m%d%H%M')}.md")
        create_parent(dest_path)
        write_file(path=dest_path, content=content_batch["cleaned_content"])
        print(f"  → core/{os.path.basename(dest_path)}")
        
    elif content_type == "web_research":
        # Research findings go to graph/research
        dest_path = os.path.join(GRAPH_DIR, f"{tool_name}-{datetime.now().strftime('%Y%m%d%H%M')}.md")
        create_parent(dest_path)
        write_file(path=dest_path, content=content_batch["cleaned_content"])
        print(f"  → graph/research/{os.path.basename(dest_path)}")
        
    else:
        # Conversation notes go to notes/
        dest_path = os.path.join(NOTES_DIR, f"{tool_name}-{datetime.now().strftime('%Y%m%d%H%M')}.md")
        create_parent(dest_path)
        write_file(path=dest_path, content=content_batch["cleaned_content"])
        print(f"  → notes/{os.path.basename(dest_path)}")


def determine_content_type(content):
    """Determine content type for routing."""
    if 'command output' in content.lower() or 'process:' in content.lower():
        return "system_execution"
    elif 'web_search' in content.lower() or 'url' in content.lower():
        return "web_research"
    else:
        return "conversation"


def create_parent(path):
    """Ensure parent directory exists."""
    os.makedirs(os.path.dirname(path), exist_ok=True)


# Import re for regex patterns
import re


def main():
    """Main batch engine execution."""
    print("=" * 60)
    print("🧠 MEMORY BATCH ENGINE - Intelligent Write Batching")
    print("=" * 60)
    
    import sys
    
    pending_outputs = get_pending_tool_outputs()
    
    if not pending_outputs:
        print("\n📭 No pending tool outputs to batch.")
        return
    
    print(f"\n📋 Found {len(pending_outputs)} tool output files:")
    for output in pending_outputs:
        age_hours = output["age_hours"]
        filename = output["filename"]
        
        # Only process older than 2 minutes (120 seconds)
        if age_hours > 0.05:
            print(f"  • {filename[:60]}... ({output['word_count']} words)")
    
    print("\n🔄 Analyzing for batching and deduplication...")
    print("💡 Grouping by tool type + removing redundant paragraphs...")
    
    # Batch the writes
    content_batches = batch_writes(pending_outputs)
    
    if not content_batches:
        print("\n✅ No writes needed after deduplication.")
        return
    
    print(f"\n📝 Found {len(content_batches)} unique write batches:")
    
    for batch in content_batches:
        print(f"  • {batch['tool']} ({batch['tool_type']})")
    
    # Check if user wants to execute
    print("\n⚡ Batch engine ready. Execute writes? (y/n)")
    
    if len(sys.argv) > 1 and "--execute" in sys.argv:
        print("\n✅ Executing batched writes...")
        for batch in content_batches:
            write_to_context(batch, batch["tool"])
        print("\n✨ All batched writes completed!")
        
    elif len(sys.argv) > 1 and "--dry-run" in sys.argv:
        print("\n👀 Dry run - no files were written.")
        
    else:
        # Default to execute if no arguments or with confirmation
        try:
            response = input("> ").strip().lower()
            if response in ['y', 'yes']:
                print("\n✅ Executing batched writes...")
                for batch in content_batches:
                    write_to_context(batch, batch["tool"])
                print("\n✨ All batched writes completed!")
            else:
                print("Aborted. Use --execute flag to bypass confirmation.")
        except:
            # If stdin not available (non-interactive), execute by default
            print("\n✅ Executing batched writes...")
            for batch in content_batches:
                write_to_context(batch, batch["tool"])
            print("\n✨ All batched writes completed!")


if __name__ == "__main__":
    main()
