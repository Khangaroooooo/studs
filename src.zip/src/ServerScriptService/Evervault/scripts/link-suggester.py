#!/usr/bin/env python3
"""
Link Suggester - Smart Link Generation System (UPDATED 2026-06-08)

Suggests wikilinks to create between existing knowledge nodes based on:
- Entity proximity in text
- Missing bidirectional links
- Related concepts in core memory

USAGE:
    python scripts/link-suggester.py                     # Suggest new links
    python scripts/link-suggester.py --create            # Create suggested links
    python scripts/link-suggester.py --missing           # Find missing bidirectional links
"""
import os
import re
from hermes_tools import read_file, write_file, memory

# Configuration
VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "~/Documents/EverVault")
VAULT_PATH = os.path.expanduser(VAULT_PATH)

CONTEXT_DIR = os.path.join(VAULT_PATH, "brain/context")
GRAPH_DIR = os.path.join(CONTEXT_DIR, "graph")
CORE_MEMORY_FILE = os.path.join(VAULT_PATH, "brain/core/memory.md")
FACTS_DIR = os.path.join(VAULT_PATH, "brain/core/facts")


def get_graph_nodes():
    """Get all graph nodes as a dictionary."""
    graph_dir = GRAPH_DIR
    
    if not os.path.exists(graph_dir):
        return {}
    
    nodes = {}
    for filename in os.listdir(graph_dir):
        if filename.endswith('.md') and not filename.startswith('.') and 'concept-' in filename:
            filepath = os.path.join(graph_dir, filename)
            try:
                content = read_file(path=filepath).content
                
                # Extract entities from headings and lists
                entities = set()
                
                # Headings as entities
                headings = re.findall(r'#\s*([A-Za-z][A-Za-z0-9_]+(?:\s+[A-Za-z]+)?)', content)
                for heading in headings:
                    clean = ' '.join(heading.split())
                    if len(clean) > 2:
                        entities.add(clean.replace(' ', '_'))
                
                # List items as entities
                list_items = re.findall(r'-\s*\[([^\]]+)\]', content)
                for item in list_items:
                    clean = ' '.join(item.split())
                    if len(clean) > 2:
                        entities.add(clean.replace(' ', '_'))
                
                # Plain text mentions
                mentions = set(re.findall(r'\[\[([^\]]+)\]\]', content))
                
                nodes[filename] = {
                    "filepath": filepath,
                    "content": content,
                    "entities": list(entities),
                    "mention_count": len(mentions)
                }
                
            except Exception as e:
                print(f"Error reading {filename}: {e}")
    
    return nodes


def get_core_memory_concepts():
    """Extract concepts mentioned in core memory for link suggestions."""
    
    try:
        if os.path.exists(CORE_MEMORY_FILE):
            content = read_file(path=CORE_MEMORY_FILE).content
            
            # Extract all wikilink targets from core memory
            links = re.findall(r'\[\[([^\]]+)\]\]', content)
            
            # Also extract concept mentions (plain text that could be concepts)
            concepts = set()
            for line in content.split('\n'):
                if len(line.strip()) > 3 and not line.startswith(' '):
                    # Extract heading-style concepts
                    matches = re.findall(r'\b([A-Za-z][A-Za-z0-9_]+\s+[A-Za-z0-9_.]+)\b', line)
                    for match in matches[:2]:  # Limit to top 2 concepts per line
                        clean = ' '.join(match.split())
                        if len(clean) > 3:
                            concepts.add(clean.replace(' ', '_'))
            
            return list(links) + list(concepts)
    except Exception as e:
        print(f"Error reading core memory: {e}")
    
    return []


def get_existing_facts():
    """Get all atomic facts for link suggestions."""
    
    if not os.path.exists(FACTS_DIR):
        return []
    
    facts = {}
    for filename in os.listdir(FACTS_DIR):
        if filename.endswith('.md') and not filename.startswith('.'):
            filepath = os.path.join(FACTS_DIR, filename)
            try:
                content = read_file(path=filepath).content
                
                # Extract entities from facts
                entities = set()
                
                # Headings as entities
                headings = re.findall(r'#\s*([A-Za-z][A-Za-z0-9_]+(?:\s+[A-Za-z]+)?)', content)
                for heading in headings:
                    clean = ' '.join(heading.split())
                    if len(clean) > 2:
                        entities.add(clean.replace(' ', '_'))
                
                # List items as entities
                list_items = re.findall(r'-\s*\[([^\]]+)\]', content)
                for item in list_items:
                    clean = ' '.join(item.split())
                    if len(clean) > 2:
                        entities.add(clean.replace(' ', '_'))
                
                facts[filename] = {
                    "filepath": filepath,
                    "content": content,
                    "entities": list(entities),
                    "word_count": len(content.split())
                }
                
            except Exception as e:
                print(f"Error reading fact {filename}: {e}")
    
    return facts


def find_missing_bidirectional_links():
    """Find entities that mention other concepts but aren't linked."""
    
    print("=" * 60)
    print("LINK SUGGESTER - Smart Link Generation (UPDATED 2026-06-08)")
    print("=" * 60)
    
    graph_nodes = get_graph_nodes()
    core_memory_concepts = get_core_memory_concepts()
    existing_facts = get_existing_facts()
    
    print(f"\nFound {len(graph_nodes)} graph nodes")
    if core_memory_concepts:
        print(f"Found {len(core_memory_concepts)} concepts in core memory")
    print(f"Found {len(existing_facts)} atomic facts for link suggestions\n")
    
    suggestions = []
    
    # Strategy 1: Find entities mentioned in graph nodes that aren't linked
    for filename, node in graph_nodes.items():
        content = node["content"]
        
        # Look for plain text headings that could be entities
        potential_entities = re.findall(r'\b([A-Za-z][A-Za-z0-9_]+\s+[A-Za-z0-9_]+)\b', content)
        
        for entity in potential_entities[:5]:  # Check first 5 potential entities
            clean_entity = ' '.join(entity.split())
            
            # Skip if already linked
            if f"[[{clean_entity}]]" in content:
                continue
            
            # Strategy A: Check if any fact mentions this entity
            for fact_file, fact_data in existing_facts.items():
                if clean_entity.lower() in fact_data["content"].lower():
                    suggestions.append({
                        "from": filename,
                        "to": f"[[{clean_entity.replace(' ', '_')}]]",
                        "mentioned_in": fact_file,
                        "source_type": "fact",
                        "confidence": 0.8
                    })
            
            # Strategy B: Check if any graph node mentions this entity
            for other_file, other_node in graph_nodes.items():
                if other_file == filename:
                    continue
                
                if clean_entity.lower() in other_node["content"].lower():
                    suggestions.append({
                        "from": filename,
                        "to": f"[[{clean_entity.replace(' ', '_')}]]",
                        "mentioned_in": other_file,
                        "source_type": "graph",
                        "confidence": 0.7
                    })
    
    # Strategy C: Suggest links from core memory concepts to relevant graph nodes
    for concept in core_memory_concepts[:10]:  # Top 10 concepts
        clean_concept = concept.replace(' ', '_').replace('.', '').replace('-', '')
        
        for filename, node in graph_nodes.items():
            content_lower = node["content"].lower()
            concept_lower = concept.lower()
            
            # Check if concept is relevant to this graph node
            if any(term in content_lower for term in [concept_lower, clean_concept.lower()]):
                if f"[[{clean_concept}]]" not in content:
                    suggestions.append({
                        "from": filename,
                        "to": f"[[{clean_concept}]]",
                        "mentioned_in": f"(core memory concept)",
                        "source_type": "core_memory",
                        "confidence": 0.6
                    })
    
    # Remove duplicates
    seen = set()
    unique_suggestions = []
    for sug in suggestions:
        key = (sug["from"], sug["to"])
        if key not in seen:
            seen.add(key)
            unique_suggestions.append(sug)
    
    print(f"\nFound {len(unique_suggestions)} potential links")
    
    # Sort by confidence and limit display
    unique_suggestions.sort(key=lambda x: x.get("confidence", 0), reverse=True)
    
    for i, sug in enumerate(unique_suggestions[:20], 1):
        to_display = sug['to'].replace(']]', ']]')
        print(f"  {i}. {sug['from']} --> {to_display}")
        print(f"     (source: {sug.get('source_type', '?')}, confidence: {sug.get('confidence', 0):.0%})")
    
    if len(unique_suggestions) > 20:
        print(f"\n... and {len(unique_suggestions) - 20} more suggestions")
    
    return unique_suggestions


def create_links(suggestions):
    """Create the suggested wikilinks."""
    
    if not suggestions:
        print("\nNo links to create.")
        return
    
    print("\nCreating links...")
    
    created = 0
    skipped = 0
    
    for sug in suggestions:
        from_file = sug["from"]
        
        # Skip overly verbose suggestions
        if len(sug["to"].replace('[[', '').replace(']]', '')) > 50:
            continue
        
        filepath = os.path.join(GRAPH_DIR, from_file)
        
        try:
            content = read_file(path=filepath).content
            
            # Check if already linked (simple check)
            entity_name = sug['to']
            
            # Skip if exact match exists
            if entity_name in content:
                skipped += 1
                continue
            
            # Add link to appropriate location
            insert_marker = "\n\n## See Also\n\n"
            
            if insert_marker in content:
                new_content = content.replace(insert_marker, sug['to'] + insert_marker)
            else:
                # Find last section header or add at end
                last_header = content.rfind("\n# ")
                if last_header != -1:
                    new_content = content[:last_header] + "## See Also\n" + sug['to'] + "\n" + content[last_header:]
                else:
                    clean_entity = entity_name.replace(']]', '').replace('[[' , '').replace('_', ' ')
                    new_content = content + f"\n\n[[{clean_entity}]]\n"
            
            write_file(path=filepath, content=new_content)
            created += 1
            print(f"  Added: {sug['from']} --> {sug['to']}")
            
        except Exception as e:
            print(f"  Error creating link in {from_file}: {e}")
    
    print(f"\nCreated {created} links, skipped {skipped} already-linked")


def create_missing_personal_links():
    """Create links from core memory concepts to personal info files."""
    
    print("\n🔗 Creating missing personal info links...")
    
    # Personal info files that should be linked
    personal_info_files = [
        ("brain/personal-info/name.md", "name"),
        ("brain/personal-info/location.md", "location"),
        ("brain/personal-info/occupation.md", "occupation"),
        ("brain/personal-info/tools-and-env.md", "tools-and-env")
    ]
    
    for filepath, concept in personal_info_files:
        try:
            if not os.path.exists(filepath):
                continue
            
            content = read_file(path=filepath).content
            
            # Check which graph nodes or facts reference this concept
            suggested_entities = set()
            
            # Scan all graph nodes and facts for mentions
            graph_dir = os.path.join(VAULT_PATH, "brain/context/graph")
            if os.path.exists(graph_dir):
                for filename in os.listdir(graph_dir):
                    if filename.endswith('.md') and not filename.startswith('.'):
                        try:
                            node_content = read_file(path=os.path.join(graph_dir, filename)).content
                            
                            # Check if concept is mentioned but not linked
                            if concept.lower() in node_content.lower():
                                link_text = f"[[{concept.replace('-', '_').replace('.', '')}]]"
                                if link_text not in node_content:
                                    suggested_entities.add((filename, link_text))
                        except Exception:
                            continue
            
            facts_dir = os.path.join(VAULT_PATH, "brain/core/facts")
            if os.path.exists(facts_dir):
                for filename in os.listdir(facts_dir):
                    if filename.endswith('.md') and not filename.startswith('.'):
                        try:
                            fact_content = read_file(path=os.path.join(facts_dir, filename)).content
                            
                            # Check if concept is mentioned but not linked
                            if concept.lower() in fact_content.lower():
                                link_text = f"[[{concept.replace('-', '_').replace('.', '')}]]"
                                if link_text not in fact_content:
                                    suggested_entities.add((filename, link_text))
                        except Exception:
                            continue
            
            # Create links in top matches
            for filename, link_text in list(suggested_entities)[:5]:
                filepath = os.path.join(graph_dir if 'graph' in filename else facts_dir, filename)
                
                try:
                    content = read_file(path=filepath).content
                    
                    insert_marker = "\n\n## See Also\n\n"
                    
                    if insert_marker in content:
                        new_content = content.replace(insert_marker, link_text + insert_marker)
                    else:
                        last_header = content.rfind("\n# ")
                        if last_header != -1:
                            new_content = content[:last_header] + "## See Also\n" + link_text + "\n" + content[last_header:]
                        else:
                            clean_concept = concept.replace('-', '_').replace('.', '')
                            new_content = content + f"\n\n[[{clean_concept}]]\n"
                    
                    write_file(path=filepath, content=new_content)
                    print(f"  Added personal info link to {filename}")
                    
                except Exception as e:
                    print(f"  Error adding link to {filename}: {e}")
            
        except Exception as e:
            print(f"  Error processing {concept}: {e}")
    
    print("\nPersonal info link creation complete!")


def main():
    """Main execution."""
    import sys
    
    # Parse arguments
    create_flag = "--create" in sys.argv
    missing_flag = "--missing" in sys.argv
    
    suggestions = find_missing_bidirectional_links()
    
    if create_flag:
        create_links(suggestions)
    
    # Always run personal info linking
    if missing_flag or not any([create_flag, missing_flag]):
        create_missing_personal_links()


if __name__ == "__main__":
    main()
