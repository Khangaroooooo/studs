#!/usr/bin/env python3
"""
Offline Training Script for Barricade.gg RL Agent
Uses rule-based simulator to pretrain before online learning."""

import argparse
import os
import json
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent.parent  # ~/Documents/Evervault
TRAINING_DIR = PROJECT_ROOT / "brain" / "training" / "barricade-gg"
CHECKPOINT_DIR = TRAINING_DIR / "models"


class SimpleBarricadeSimulator:
    """
    Simplified rule-based Barricade.gg simulator for offline training.
    
    This simulates the game mechanics without needing live browser automation.
    Generates synthetic training data with varied game states.
    """
    
    def __init__(self):
        self.state = {
            'my_position': 0,
            'opponent_positions': [5],  # Opponent starts ahead
            'distance_to_goal': 10,
            'game_phase': 'early',
            'risk_score': 0.3
        }
        
    def reset(self):
        """Reset simulator to initial state."""
        self.state = {
            'my_position': 0,
            'opponent_positions': [5],
            'distance_to_goal': 10,
            'game_phase': 'early',
            'risk_score': 0.3,
            'barricades': [],
            'turn': 0
        }
        
    def get_observation(self):
        """Get observation state for RL agent."""
        # Simplified observation representation
        obs = {
            'my_position': self.state['my_position'],
            'distance_to_goal': self.state['distance_to_goal'],
            'opponent_position': self.state['opponent_positions'][0] if isinstance(self.state['opponent_positions'], list) else self.state['opponent_positions'],
            'game_phase': self.state['game_phase'],
            'risk_score': self.state['risk_score']
        }
        return obs
    
    def step(self, action):
        """
        Execute action and return (observation, reward, done).
        
        Actions:
          - MOVE_FORWARD: Move 1 tile toward goal
          - PLACE_BARRICADE: Place barricade to block opponent
          - WAIT: Pass turn
        
        Returns tuple of (new_observation, reward, done)
        """
        import random
        
        action = action if isinstance(action, str) else action.name
        
        # Update risk score based on current state
        occupancy_ratio = sum(1 for p in [self.state['my_position'], *self.state['opponent_positions']] 
                            if 0 <= p < self.state['distance_to_goal']) / self.state['distance_to_goal']
        self.state['risk_score'] = min(0.9, occupancy_ratio + 0.2)
        
        new_state = self.state.copy()
        reward = 0.0
        done = False
        
        if action == 'MOVE_FORWARD':
            new_state['my_position'] += 1
            new_state['distance_to_goal'] -= 1
            new_state['turn'] = (self.state.get('turn', 0) + 1) % 10
            reward = 0.1  # Small reward for progress
            
        elif action == 'PLACE_BARRICADE':
            # Simplified barricade placement - blocks opponent's path if nearby
            if abs(new_state['my_position'] - new_state['opponent_positions'][0]) <= 2:
                new_state['risk_score'] = max(0.7, new_state['risk_score'])
                reward = 0.3  # Bonus for defensive play
            else:
                reward = -0.1  # Penalty for unnecessary barricade
            
        elif action == 'WAIT':
            reward = -0.05  # Small penalty for wasting turn
        
        # Check win/loss conditions
        if new_state['my_position'] >= self.state['distance_to_goal']:
            done = True
            reward = 100.0  # Win!
            
        elif new_state['risk_score'] > 0.85 and abs(new_state['my_position'] - new_state['opponent_positions'][0]) <= 2:
            # Self-trap or dangerous proximity (simplified risk check)
            done = True
            reward = -100.0  # Loss
            
        elif new_state['opponent_positions'][0] >= new_state['distance_to_goal']:
            # Opponent wins
            done = True
            reward = -100.0  # Opponent win
        
        new_state['turn'] = (new_state.get('turn', 0) + 1) % 10
        
        return self.get_observation(), reward, done
    
    def render(self):
        """Print current game state."""
        print(f"\n{'='*40}")
        print(f"SIMULATOR STATE:")
        print(f"{'='*40}")
        print(f"My Position:      {self.state['my_position']}/{self.state['distance_to_goal']}")
        print(f"Opponent Position: {self.state['opponent_positions'][0] if isinstance(self.state['opponent_positions'], list) else self.state['opponent_positions']}")
        print(f"Distance to Goal:  {self.state['distance_to_goal']} tiles")
        print(f"Game Phase:        {self.state['game_phase']}")
        print(f"Risk Score:        {self.state['risk_score']:.2f}")
        print(f"{'='*40}\n")


class ReplayBuffer:
    """Experience replay buffer for off-policy learning."""
    
    def __init__(self, capacity=1000):
        self.capacity = capacity
        self.buffer = []
        
    def add(self, obs, action, reward, next_obs, done):
        """Add transition to buffer."""
        transition = {
            'obs': obs,
            'action': action,
            'reward': reward,
            'next_obs': next_obs,
            'done': done
        }
        self.buffer.append(transition)
        
        if len(self.buffer) > self.capacity:
            self.buffer.pop(0)
            
    def sample_batch(self, batch_size=64):
        """Sample random batch of transitions."""
        import random
        batch = random.sample(self.buffer, min(batch_size, len(self.buffer)))
        return batch
    
    def __len__(self):
        return len(self.buffer)


def compute_reward(state, action, outcome=None):
    """
    Compute reward for given state, action, and outcome.
    
    Reward components:
    - Primary reward: Progress toward goal
    - Risk aversion penalty for self-trap risk
    - Defensive play bonus
    - Time pressure adjustment
    - Terminal win/loss rewards
    """
    import random
    
    # Base progress reward (inversely proportional to distance)
    progress_reward = 0.3 * (-1) / max(1, state['distance_to_goal'])
    
    # Risk aversion: Heavy penalty for high-risk barricade placement
    if action == 'PLACE_BARRICADE' and state.get('risk_score', 0) > 0.7:
        progress_reward = -2.0
        
    # Defensive play bonus
    elif action == 'PLACE_BARRICADE':
        reward_bonus = 0.5 * (1 / max(1, state['opponent_position'] - state['my_position']))
        progress_reward += reward_bonus
        
    # Time pressure: Increase progress weighting in late game
    if state.get('turn', 0) > 8:  # Simplified turn counting
        progress_reward *= 1.2
        
    # Terminal rewards (win/loss already handled separately)
    if outcome == 'WIN':
        return 100.0
    elif outcome == 'LOSS':
        return -100.0
    
    return progress_reward


def train_offline(episodes=50, simulator='rule-based'):
    """
    Train RL agent using offline simulation.
    
    Phase: Offline Pretraining
    - Uses rule-based simulator (no live game)
    - Generates synthetic training data
    - 10,000–50,000 timesteps
    
    After completion, model can be loaded for online fine-tuning.
    """
    import random
    
    print("="*60)
    print("🎮 BARRICADE.RL AGENT - OFFLINE TRAINING MODE")
    print("="*60)
    print(f"\nSimulator: {simulator}")
    print(f"Episodes: {episodes}")
    
    # Setup directories
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    
    # Initialize simulator and replay buffer
    sim = SimpleBarricadeSimulator()
    replay_buffer = ReplayBuffer(capacity=500)
    
    # Initialize random policy (placeholder for actual PPO model)
    import numpy as np
    
    actions = ['MOVE_FORWARD', 'PLACE_BARRICADE', 'WAIT']
    action_probs = np.ones(len(actions)) / len(actions)  # Uniform exploration
    
    episode_rewards = []
    cumulative_rewards = []
    
    print("\nStarting offline training...")
    print("-" * 60)
    
    for ep in range(episodes):
        sim.reset()
        obs = sim.get_observation()
        total_reward = 0.0
        
        # Simulate episode with random policy (for initialization)
        done = False
        step = 0
        while not done and step < 20:  # Max steps per episode
            action_idx = int(np.random.choice(len(actions), p=action_probs))
            action = actions[action_idx]
            
            next_obs, reward, done = sim.step(action)
            replay_buffer.add(obs, action, reward, next_obs, done)
            
            total_reward += reward
            
            # Sample and update (placeholder - actual PPO would use batch updates)
            if len(replay_buffer) > 32:
                batch = replay_buffer.sample_batch(batch_size=16)
                
        episode_rewards.append(total_reward)
        cumulative_rewards.append(sum(episode_rewards))
        
        step += 1
        
        # Print progress every 10 episodes
        if (ep + 1) % 10 == 0:
            print(f"Episode {ep+1}/{episodes} | Avg Reward: {np.mean(episode_rewards[-10:]):.2f}")
        
        # Save checkpoint every 10 episodes
        if (ep + 1) % 10 == 0:
            timestamp = int(time.time())
            checkpoint_data = {
                'episode': ep + 1,
                'total_reward': total_reward,
                'avg_episode_rewards': episode_rewards[-10:],
                'cumulative_rewards': cumulative_rewards[-10:],
                'timestamp': timestamp
            }
            
            # Save checkpoint
            checkpoint_file = CHECKPOINT_DIR / f"checkpoint_ep{ep+1:03d}.ppo"
            with open(checkpoint_file, 'w') as f:
                json.dump(checkpoint_data, f, indent=2)
            
            print(f"\n✅ Saved checkpoint: {checkpoint_file.name}")
    
    # Save final metrics
    metrics_file = TRAINING_DIR / "offline_training_metrics.json"
    with open(metrics_file, 'w') as f:
        json.dump({
            'episodes': episodes,
            'simulator': simulator,
            'final_avg_reward': np.mean(episode_rewards[-10:]),
            'final_cumulative_reward': cumulative_rewards[-1],
            'timestamps': [t for _, t in []]  # Placeholder - would include actual timestamps
        }, f, indent=2)
    
    print("\n" + "="*60)
    print("✅ OFFLINE TRAINING COMPLETED")
    print("="*60)
    
    print(f"\nTraining Summary:")
    print(f"  Episodes completed: {episodes}")
    print(f"  Final avg reward (last 10 eps): {np.mean(episode_rewards[-10:]):.2f}")
    print(f"  Final cumulative reward: {cumulative_rewards[-1]:.2f}")
    print(f"  Checkpoint location: {CHECKPOINT_DIR}/")
    
    print("\nNext Steps:")
    print("  1. Load this checkpoint for online training:")
    print("     python train_barricade_rl.py --deploy")
    print("  2. Or use checkpoint in PPO model initialization")
    
    return {
        'episodes': episodes,
        'avg_reward': np.mean(episode_rewards[-10:]),
        'checkpoint': max(CHECKPOINT_DIR.glob('checkpoint_*.ppo'), default=None)
    }


def main():
    parser = argparse.ArgumentParser(
        description='Offline Training Script for Barricade.gg RL Agent',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Train with rule-based simulator (default)
  python train_offline.py --episodes 50
  
  # Train with more episodes
  python train_offline.py --episodes 100

Environment variables:
  BARRICADE_EPISODES=50
"""
    )
    
    parser.add_argument(
        '--episodes', '-e',
        type=int,
        default=int(os.environ.get('BARRICADE_EPISODES', 50)),
        help='Number of training episodes (default: 50)'
    )
    parser.add_argument(
        '--simulator',
        choices=['rule-based'],
        default='rule-based',
        help='Simulator type (default: rule-based)'
    )
    
    args = parser.parse_args()
    
    try:
        result = train_offline(episodes=args.episodes, simulator=args.simulator)
        
        if result['checkpoint']:
            print(f"\n🎉 Offline training complete!")
            print(f"   Final checkpoint: {result['checkpoint'].name}")
            
    except Exception as e:
        print(f"\n❌ Training failed with error: {e}")
        import traceback
        traceback.print_exc()
        raise


if __name__ == '__main__':
    main()
