#!/usr/bin/env python3
"""
Archival Bot - Smart Retention & Rotation System (UPDATED 2026-06-08)

Advanced context folder management with link-based analysis and intelligent rotation.

USAGE:
    python scripts/archival-bot.py                        # Smart review with suggestions
    python scripts/archival-bot.py --archive              # Execute archival actions
    python scripts/archival-bot.py --promote              # Promote files from archived/
    python scripts/archival-bot.py --optimize             # Full optimization cycle
"""
import os
from datetime import datetime
import re
from hermes_tools import read_file, write_file, memory

# Configuration
VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "~/Documents/EverVault")
VAULT_PATH = os.path.expanduser(VAULT_PATH)
CONTEXT_DIR = os.path.join(VAULT_PATH, "brain/context")
CORE_MEMORY_FILE = os.path.join(VAULT_PATH, "brain/core/memory.md")


def get_file_age_days(filepath):
    """Get file age in days."""
    if not os.path.exists(filepath):
        return 0
    mtime = os.path.getmtime(filepath)
    age_seconds = datetime.now().timestamp() - mtime
    return int(age_seconds / 86400)


def analyze_link_topology(filepath):
    """Analyze how this file connects to the rest of the knowledge graph."""
    filename = os.path.basename(filepath)
    
    inbound = 0
    outbound = 0
    
    try:
        content = read_file(path=filepath).content
        
        # Count wikilink mentions (outbound links)
        outbound_mentions = content.count("[[")
        
        if outbound_mentions > 0:
            outbound = outbound_mentions // 2
            
    except Exception as e:
        print(f"  ⚠️ Error analyzing {filename}: {e}")
    
    return {"filename": filename, "inbound": inbound, "outbound": outbound}


def analyze_core_memory_recency(filepath):
    """Check if file is referenced in core memory (boosts retention)."""
    try:
        if os.path.exists(CORE_MEMORY_FILE):
            core_content = read_file(path=CORE_MEMORY_FILE).content
            
            filename_without_ext = filename.replace('.md', '')
            
            content_lower = core_content.lower()
            filename_lower = filename_without_ext.lower()
            
            # Check if file topic is mentioned anywhere in core memory
            is_referenced = (
                filename_lower in content_lower or
                any(word.lower() in content_lower for word in filename.split('.')[:-1] if word)
            )
            
            return 2 if is_referenced else 0
            
    except Exception as e:
        pass
    
    return 0


def calculate_recency_score(filepath):
    """Calculate how fresh this content is relative to its age."""
    age_days = get_file_age_days(filepath)
    
    freshness_boost = analyze_core_memory_recency(filepath)
    
    # Calculate score (higher is fresher)
    base_score = max(0, 10 - age_days * 0.5)
    return {"score": base_score + freshness_boost, "age_days": age_days}


def get_file_statistics(filepath):
    """Get comprehensive statistics for a file."""
    filename = os.path.basename(filepath)
    
    stats = {
        "filename": filename,
        "age_days": get_file_age_days(filepath),
        "size_kb": os.path.getsize(filepath) / 1024 if os.path.exists(filepath) else 0,
        "link_analysis": analyze_link_topology(filepath),
        "freshness": calculate_recency_score(filepath),
    }
    
    try:
        content = read_file(path=filepath).content
        stats["word_count"] = len(content.split())
        
        # Look for session markers
        if "session" in content.lower() or "date:" in content.lower():
            stats["has_session_marker"] = True
            
    except Exception as e:
        stats["word_count"] = 0
    
    return stats


def get_files_in_directory(directory):
    """Get all non-hidden files in a directory."""
    if not os.path.exists(directory):
        return []
    return [f for f in os.listdir(directory) if not f.startswith('.') and '.archived' not in f]


def analyze_active_folder():
    """Analyze all files in active/ folder."""
    print("\n🔍 Analyzing brain/context/active/")
    active_dir = os.path.join(CONTEXT_DIR, "active")
    
    if not os.path.exists(active_dir):
        return [], {}
    
    analyzed_files = []
    total_files = len(get_files_in_directory(active_dir))
    
    for filename in get_files_in_directory(active_dir):
        filepath = os.path.join(active_dir, filename)
        
        try:
            stats = get_file_statistics(filepath)
            
            # Smart archival decision based on multiple factors
            score = decide_should_archive(stats)
            stats["should_archive"] = score > 30
            stats["archive_score"] = score
            
        except Exception as e:
            print(f"  ⚠️ Error analyzing {filename}: {e}")
            continue
        
        analyzed_files.append(stats)
    
    return analyzed_files, total_files


def decide_should_archive(stats):
    """Decide if a file should be archived based on multiple factors."""
    filename = stats["filename"]
    age_days = stats["age_days"]
    link_inbound = stats["link_analysis"]["inbound"] or 0
    link_outbound = stats["link_analysis"]["outbound"] or 0
    freshness = stats["freshness"]["score"]
    
    score = 0
    
    # Age penalty (older files should be archived) - weight: 40
    age_penalty = min(age_days * 2, 40)
    score += age_penalty
    
    # Low link count - files rarely referenced should be archived - weight: 35
    if (link_inbound + link_outbound) < 2:
        score += 35
    elif (link_inbound + link_outbound) == 0:
        score += 50  # Zero links = strong archival signal
    
    # Small files (< 1KB) - likely notes or drafts, archive if old - weight: 25
    size_kb = stats["size_kb"] or 0
    if size_kb < 1 and age_days > 7:
        score += 25
    
    # Low freshness (not referenced in core memory recently) - weight: 15
    if freshness < 3:
        score += 15
    
    # Penalize files with session markers (actively used this session)
    if stats.get("has_session_marker", False):
        score = max(0, score - 20)
    
    return score, score


def execute_archive(analyzed_files):
    """Execute archival for files marked for archiving."""
    archived_dir = os.path.join(CONTEXT_DIR, "archived")
    os.makedirs(archived_dir, exist_ok=True)
    
    archived_count = 0
    
    print("\n📦 Executing archival...")
    for file_stats in analyzed_files:
        should_archive, score = file_stats["should_archive"], file_stats.get("archive_score", 0)
        
        if should_archive:
            filename = file_stats["filename"]
            source_path = os.path.join(active_dir, filename)
            
            # Create timestamped archive name
            dest_filename = f"{filename}.rotated-{datetime.now().strftime('%Y%m%d')}.md"
            dest_path = os.path.join(archived_dir, dest_filename)
            
            print(f"  📦 Archive: {filename} (score: {score})")
            
            try:
                with open(source_path, 'r') as src:
                    content = src.read()
                with open(dest_path, 'w') as dst:
                    dst.write(content)
                
                archived_count += 1
                
                # Update core memory to track archive
                try:
                    archived_topic = filename.replace('.md', '')
                    core_content = read_file(path=CORE_MEMORY_FILE).content
                    
                    session_note = f"\n## Archived Content - {filename}\n\n- Archive date: {datetime.now().strftime('%Y-%m-%d')}\n- Reason: Low links (score: {score})\n"
                    
                    write_file(path=CORE_MEMORY_FILE, content=core_content + session_note)
                    print(f"    ✅ Moved to archived/ and noted in core memory")
                except Exception as e:
                    print(f"    ⚠️ Warning: Couldn't update core memory: {e}")
                
            except Exception as e:
                print(f"    ⚠️ Error archiving {filename}: {e}")
    
    return archived_count


def analyze_archived_folder():
    """Analyze files in archived/ folder for promotion."""
    print("\n🔍 Analyzing brain/context/archived/")
    archived_dir = os.path.join(CONTEXT_DIR, "archived")
    
    if not os.path.exists(archived_dir):
        return [], []
    
    analyzed_files = []
    total_files = len(get_files_in_directory(archived_dir))
    
    active_dir = os.path.join(CONTEXT_DIR, "active")
    
    for filename in get_files_in_directory(archived_dir):
        filepath = os.path.join(archived_dir, filename)
        
        try:
            stats = get_file_statistics(filepath)
            
            # Check if should promote back to active
            age_days = stats["age_days"]
            
            # Extract base filename without timestamp suffix
            base_name = re.sub(r'\.rotated-\d{8}\.md$', '', filename)
            link_count = (stats["link_analysis"]["inbound"] or 0) + \
                        (stats["link_analysis"]["outbound"] or 0)
            
            # Promote if: fresh (<3 days) OR highly linked (>5 total links)
            should_promote = age_days < 3 or link_count > 5
            
            stats["should_promote"] = should_promote
            
        except Exception as e:
            print(f"  ⚠️ Error analyzing {filename}: {e}")
            continue
        
        analyzed_files.append(stats)
    
    return analyzed_files, total_files


def execute_promotion(analyzed_files):
    """Promote files from archived/ back to active/."""
    active_dir = os.path.join(CONTEXT_DIR, "active")
    os.makedirs(active_dir, exist_ok=True)
    
    promoted_count = 0
    
    print("\n📤 Executing promotion...")
    for file_stats in analyzed_files:
        should_promote = file_stats.get("should_promote", False)
        
        if should_promote:
            filename = file_stats["filename"]
            source_path = os.path.join(archived_dir, filename)
            
            # Extract base filename without timestamp suffix
            base_name = re.sub(r'\.rotated-\d{8}\.md$', '', filename)
            dest_filename = base_name + ".md"
            dest_path = os.path.join(active_dir, dest_filename)
            
            age_days = file_stats["age_days"]
            reason_text = "fresh content" if age_days < 3 else "highly linked"
            print(f"  📤 Promote: {filename} (reason: {reason_text})")
            
            try:
                with open(source_path, 'r') as src:
                    content = src.read()
                with open(dest_path, 'w') as dst:
                    dst.write(content)
                
                promoted_count += 1
                
                # Update core memory
                try:
                    restored_topic = dest_filename.replace('.md', '')
                    core_content = read_file(path=CORE_MEMORY_FILE).content
                    
                    session_note = f"\n## Restored Content - {dest_filename}\n\n- Restore date: {datetime.now().strftime('%Y-%m-%d')}\n- Reason: {'fresh content' if age_days < 3 else 'highly linked'}\n"
                    
                    write_file(path=CORE_MEMORY_FILE, content=core_content + session_note)
                    print(f"    ✅ Moved to active/ and noted in core memory")
                except Exception as e:
                    print(f"    ⚠️ Warning: Couldn't update core memory: {e}")
                
            except Exception as e:
                print(f"    ⚠️ Error promoting {filename}: {e}")
    
    return promoted_count


def generate_recommendations(analyzed_files):
    """Generate human-readable recommendations."""
    recommendations = []
    
    for file_stats in analyzed_files:
        filename = file_stats["filename"]
        
        # Extract display name without timestamp suffix
        base_name = re.sub(r'\.rotated-\d{8}\.md$', '', filename)
        
        age_days = file_stats["age_days"]
        link_count = (file_stats["link_analysis"]["inbound"] or 0) + \
                    (file_stats["link_analysis"]["outbound"] or 0)
        
        if file_stats.get("should_archive", False):
            reasons = []
            
            if age_days > 7:
                reasons.append(f"age {age_days} days")
            if link_count < 2:
                reasons.append(f"low links ({link_count})")
            if (file_stats["size_kb"] or 0) < 1 and age_days > 7:
                reasons.append("small file (<1KB)")
            
            recommendations.append({
                "action": "ARCHIVE",
                "filename": base_name,
                "reasons": reasons,
                "confidence": min(1.0, (age_days * 0.1 + (2 - link_count) * 0.3))
            })
    
    return recommendations


def main():
    """Main execution with smart analysis and optional action."""
    print("=" * 60)
    print("🤖 ARCHIVAL BOT - Smart Retention & Rotation System (UPDATED 2026-06-08)")
    print("=" * 60)
    
    import sys
    
    # Parse arguments
    generate_report = "--report" in sys.argv
    execute_archive = "--archive" in sys.argv
    promote = "--promote" in sys.argv
    optimize = "--optimize" in sys.argv or not any([generate_report, execute_archive, promote])
    
    active_dir = os.path.join(CONTEXT_DIR, "active")
    archived_dir = os.path.join(CONTEXT_DIR, "archived")
    
    # Check folder health
    print("\n📊 Checking context folder health...")
    
    if not os.path.exists(CONTEXT_DIR):
        print(f"  ⚠️ Context folder doesn't exist at {CONTEXT_DIR}")
        return
    
    active_count = len(get_files_in_directory(active_dir)) if os.path.exists(active_dir) else 0
    archived_count_val = len(get_files_in_directory(archived_dir)) if os.path.exists(archived_dir) else 0
    
    print(f"  Active folder: {active_count} files")
    print(f"  Archived folder: {archived_count_val} files")
    
    # Analyze active folder
    analyzed_active, total_active = analyze_active_folder()
    
    if optimize or promote:
        analyzed_archived, total_archived = analyze_archived_folder()
        
        # Generate recommendations
        print("\n💡 Recommendations:")
        for rec in generate_recommendations(analyzed_active):
            confidence = rec.get("confidence", 0)
            action_char = "📦 " if rec["action"] == "ARCHIVE" else "✅ "
            reasons = ", ".join(rec["reasons"])
            print(f"  {action_char} ARCHIVE: {rec['filename']} ({reasons}) [confidence: {confidence:.0%}]")
    
    # Execute actions if requested
    if optimize or execute_archive:
        archived_count_result = execute_archive(analyzed_active)
        print(f"\n  Archived {archived_count_result} files to brain/context/archived/")
        
        # Update core memory with archival summary
        try:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
            summary = f"\n## Archival Summary - {timestamp}\n\n- Files archived: {archived_count_result}\n- Reasoning: Age, link count, freshness scoring\n"
            
            core_content = read_file(path=CORE_MEMORY_FILE).content
            write_file(path=CORE_MEMORY_FILE, content=core_content + summary)
        except Exception as e:
            print(f"  ⚠️ Warning: Couldn't update core memory: {e}")
    
    if promote:
        promoted_count = execute_promotion(analyzed_archived)
        print(f"\n  Promoted {promoted_count} files from archived/ back to active/")


if __name__ == "__main__":
    main()
