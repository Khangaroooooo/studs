#!/usr/bin/env python3
"""
Barricade RL Training Script with EverVault Context Integration
Trains RL agent on Barricade.gg environment with state capture and online learning
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(f'/Users/kkhangaroo/logs/barricade_rl_train_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
    ]
)
logger = logging.getLogger(__name__)


class EverVaultContext:
    """EverVault context manager for Barricade RL training"""
    
    def __init__(self):
        self.vault_path = Path.home() / "Documents" / "Evervault" / "context"
        self.state_file = self.vault_path / "barricade_rl_state.json"
        
        # Ensure context directory exists
        self.vault_path.mkdir(parents=True, exist_ok=True)
        
        # Load existing state or initialize new session
        if self.state_file.exists():
            with open(self.state_file, 'r') as f:
                self.state = json.load(f)
                logger.info(f"Loaded EverVault context from {self.state_file}")
        else:
            self.state = {
                "epoch": 0,
                "steps": 0,
                "last_state_dict": None,
                "best_reward": -float('inf'),
                "session_start": datetime.now().isoformat(),
                "env_id": None,
                "config": {}
            }
            logger.info("Initialized new EverVault session")
    
    def save_state(self):
        """Save current training state to EverVault"""
        self.state["last_state_dict"] = {k: v for k, v in self.state.items() 
                                       if isinstance(v, (int, float, str, bool))}
        with open(self.state_file, 'w') as f:
            json.dump(self.state, f, indent=2, default=str)
        logger.info("State saved to EverVault")
    
    def log_to_vault(self, message):
        """Log training events to EverVault"""
        timestamp = datetime.now().isoformat()
        with open(self.vault_path / "training_events.log", 'a') as f:
            f.write(f"[{timestamp}] {message}\n")
    
    def get_state_summary(self) -> str:
        """Get human-readable state summary"""
        return json.dumps({k: v for k, v in self.state.items() 
                         if isinstance(v, (int, float, str, bool))}, indent=2)


# Load EverVault context at script start
evervault = EverVaultContext()

def main():
    parser = argparse.ArgumentParser(description='Train Barricade RL Agent')
    parser.add_argument('--demo', action='store_true', 
                       help='Run demo mode with pre-configured simple environment')
    parser.add_argument('--env', type=str, default=None,
                       help='Environment name (e.g., "Barricade-v0", "simple-pvp-3x3")')
    parser.add_argument('--load-dir', type=str, default=None,
                       help='Directory to load trained model from')
    parser.add_argument('--save-dir', type=str, default='/Users/kkhangaroo/models/barricade_rl',
                       help='Directory to save trained models')
    parser.add_argument('--max-epochs', type=int, default=100,
                       help='Maximum number of training epochs')
    parser.add_argument('--load-best', action='store_true',
                       help='Load best model from previous training session')
    
    args = parser.parse_args()
    
    # Validate or set environment
    if args.demo:
        env_id = "simple-pvp-3x3"  # Simple 3v3 PvP environment for demo
        logger.info(f"🎮 Demo mode: using {env_id}")
    elif args.env:
        env_id = args.env
        logger.info(f"🎮 Using environment: {env_id}")
    else:
        env_id = "simple-pvp-3x3"  # Default for demo
        logger.warning("⚠️ No environment specified, defaulting to simple-pvp-3x3")
    
    # Log initialization state
    evervault.log_to_vault(f"=== Training Session Started ===\n"
                          f"Environment: {env_id}\n"
                          f"Mode: {'Demo' if args.demo else 'Full'}\n"
                          f"Load Best: {args.load_best}")
    
    logger.info("🚀 Starting Barricade RL Training with EverVault Context")
    logger.info(f"   Environment: {env_id}")
    logger.info(f"   Mode: {'Demo' if args.demo else 'Full'}")
    logger.info(f"   Save Directory: {args.save_dir}")
    
    # Check if load-best flag is set
    if args.load_best and evervault.state["last_state_dict"]:
        model_path = Path(evervault.state.get("best_model_path", args.save_dir)) / "best.pt"
        if model_path.exists():
            logger.info(f"✅ Loading best model from {model_path}")
            # In real implementation: load model here
        else:
            logger.warning(f"⚠️  Best model file not found at {model_path}")
    elif args.load_dir and Path(args.load_dir).exists():
        logger.info(f"✅ Loading models from {args.load_dir}")
    else:
        logger.info("🆕 Starting fresh training (or loading demo config)")
    
    # Training loop placeholder for demo mode
    print("\n" + "="*60)
    print("BARRICADE RL TRAINING")
    print("="*60)
    
    if args.demo:
        print("\n🎯 DEMO MODE - Simulating training progression:\n")
        
        # Simulate epoch progress
        for epoch in range(1, min(args.max_epochs + 1, 11)):  # Show first 10 epochs
            print(f"\n{'─'*50}")
            print(f"Epoch {epoch}/{min(args.max_epochs, 10)}")
            
            # Simulated metrics for demo
            total_reward = 10 * (1.2 ** epoch)  # Exponential growth
            win_rate = min(98.0, 30 + 4 * epoch)  # Win rate improvement
            
            print(f"  Total Reward:     {total_reward:8.1f}")
            print(f"  Win Rate:         {win_rate:5.1f}%")
            print(f"  Avg Steps/Epoch:  {70 + epoch * 3:.0f}")
            
            # Save state to EverVault
            evervault.state["epoch"] = epoch
            evervault.state["steps"] = epoch * (70 + epoch * 3)
            evervault.state["best_reward"] = total_reward
            evervault.save_state()
        
        print(f"\n{'─'*50}")
        print(f"🎉 Demo Training Complete!")
        print(f"   Total Epochs: {min(args.max_epochs, 10)}")
        print(f"   Final Reward: {evervault.state['best_reward']:.1f}")
        
        # Save final state
        evervault.log_to_vault(f"Demo session complete. Final reward: {evervault.state['best_reward']:.1f}")
    else:
        print("\n⚠️  In full training mode, real environment integration required.")
        print("   Demo flag (--demo) or simple environment recommended for first run.")
    
    # Display final EverVault state
    print(f"\n{'='*60}")
    print("📊 EVERVAULT STATE SUMMARY")
    print("="*60)
    print(evervault.get_state_summary())
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
