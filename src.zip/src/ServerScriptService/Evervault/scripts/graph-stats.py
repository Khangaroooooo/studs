#!/usr/bin/env python3
"""
Graph Statistics Generator - 📊 Live Metrics from Brain State

Generates statistics for brain/graph/index.md and other health dashboards.
Runs automatically or on-demand to keep metrics fresh.

Usage:
    python scripts/graph-stats.py                        # Generate all stats
    python scripts/graph-stats.py --graph                 # Graph node statistics only
    python scripts/graph-stats.py --health               # System health report
"""
import os
from datetime import datetime
from hermes_tools import read_file


VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "~/Documents/EverVault")
VAULT_PATH = os.path.expanduser(VAULT_PATH)

CONTEXT_DIR = os.path.join(VAULT_PATH, "brain/context")
GRAPH_DIR = os.path.join(CONTEXT_DIR, "graph")
ACTIVE_DIR = os.path.join(CONTEXT_DIR, "active")
ARCHIVED_DIR = os.path.join(CONTEXT_DIR, "archived")
CORE_DIR = os.path.join(CONTEXT_DIR, "core")


def get_file_age_days(filepath):
    """Get file age in days."""
    from datetime import datetime
    mtime = os.path.getmtime(filepath)
    age_seconds = (datetime.now().timestamp() - mtime)
    return age_seconds / 86400


def count_graph_nodes(directory, pattern=None):
    """Count nodes in directory matching pattern."""
    if not os.path.exists(directory):
        return 0
    
    if pattern is None:
        pattern = "*.md"
    
    count = 0
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        if os.path.isfile(filepath):
            # Skip non-*.md files or hidden files
            if not filename.endswith('.md'):
                continue
            if filename.startswith('.'):
                continue
    