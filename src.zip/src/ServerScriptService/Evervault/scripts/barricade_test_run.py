#!/usr/bin/env python3
"""
Test Run Script for Barricade.gg RL Agent
Runs online learning on live Barricade.gg game."""

import argparse
import os
import json
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent.parent  # ~/Documents/Evervault
TRAINING_DIR = PROJECT_ROOT / "brain" / "training" / "barricade-gg"
CHECKPOINT_DIR = TRAINING_DIR / "models"
SCRIPTS_DIR = PROJECT_ROOT / "scripts"


class BarricadeTestRunner:
    """
    Test run runner for Barricade.gg RL agent.
    
    Modes:
      - TEST: Explore game without updating model
      - TRAINING: Play and update model online
      - EVALUATION: Evaluate trained model without updates
    """
    
    def __init__(self, mode='TRAINING'):
        self.mode = os.environ.get('BARRICADE_MODE', mode)  # TRAINING | TEST | EVALUATION
        self.episodes = int(os.environ.get('BARRICADE_EPISODES', 3))
        
        # State capture module (placeholder - actual implementation uses Hermes browser tools)
        import numpy as np
        
        self.state = None
        self.observation_encoding = None
        self.action_probs = None
        self.replay_buffer = None
        
    def capture_state(self):
        """
        Capture current game state via browser tools.
        
        Uses:
        - browser_get_images() for screenshot analysis
        - browser_console(expression='...') for DOM parsing
        
        Returns combined state representation.
        """
        try:
            # Placeholder for actual Hermes browser tool integration
            from hermes_tools import browser_get_images, browser_console
            
            url = "https://barricade.gg"
            
            # Take screenshot
            images = browser_get_images()
            
            # Parse DOM for state info
            dom_state = browser_console(expression='document.body.innerText')
            
            print(f"[TEST RUN] State captured successfully")
            print(f"  Screenshot: {len(images) if isinstance(images, list) else 'N/A'} images available")
            print(f"  DOM length: {len(dom_state) if isinstance(dom_state, str) else 'N/A'} characters")
            
            # Combine visual and DOM state (simplified representation)
            state = {
                'screenshot': images,
                'dom_state': dom_state,
                'game_phase': 'determined',
                'risk_score': 0.5,  # Placeholder - calculated from board state
                'turn': 1,
                'my_position': 0,  # Will be updated after game tick
            }
            
            return state
            
        except Exception as e:
            print(f"[TEST RUN] State capture error: {e}")
            raise
    
    def decide_action(self, state):
        """
        Decide action based on trained policy or exploration.
        
        In TRAINING mode: Sample from policy (exploration)
        In TEST/EVALUATION mode: Use greedy best action (exploitation)
        """
        import random
        
        actions = ['MOVE_FORWARD', 'PLACE_BARRICADE', 'ATTACK_OPPOONENT', 'WAIT']
        
        if self.mode == 'TRAINING':
            # Exploration: Sample from policy (simplified - real implementation uses PPO)
            action = random.choice(actions)
            
            print(f"[DECISION] Training mode - Sampling action: {action}")
            
        else:
            # Greedy exploitation: Select best action based on learned policy
            # For demo, default to move forward
            action = 'MOVE_FORWARD'
            
            print(f"[DECISION] Test/Eval mode - Greedy action: {action}")
        
        return action
    
    def execute_action(self, action):
        """Execute the selected action via browser automation."""
        import time
        
        print(f"[EXECUTE] Executing action: {action}")
        
        try:
            from hermes_tools import browser_click, browser_press
            
            if action == 'MOVE_FORWARD':
                # Find and click next tile or press corresponding key
                print("  [ACTION] Moving forward...")
                # browser_click('@next_tile_button')  # Placeholder
                
            elif action == 'PLACE_BARRICADE':
                # Navigate to barricade placement UI
                print("  [ACTION] Placing barricade...")
                # Navigate to target location and interact with barricade placement UI
                
            elif action == 'ATTACK_OPPOONENT':
                # Use attack command if available in current UI  
                print("  [ACTION] Attacking opponent...")
                
            elif action == 'WAIT':
                print("  [ACTION] Waiting (passing turn)...")
            
            # Wait for game tick to update state
            time.sleep(10)  # Allow time for state update
            
            print(f"[EXECUTE] Action {action} completed successfully")
            
        except Exception as e:
            print(f"[EXECUTE] Action execution error: {e}")
            raise
    
    def collect_episode(self, episode_num):
        """
        Collect full episode data.
        
        For each iteration:
        1. Capture game state via browser tools
        2. Decide action using trained policy
        3. Execute action via browser automation
        4. Wait for game tick to update state
        
        Returns collected episode data.
        """
        print(f"\n{'='*60}")
        print(f"[{self.mode}] Episode {episode_num}/{self.episodes}")
        print(f"{'='*60}\n")
        
        episode_data = {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'mode': self.mode,
            'actions_taken': [],
            'episodes_completed': 1,
            'win_loss': None,
            'observations': []
        }
        
        state = None
        
        for i in range(3):  # Simulate multiple turns per episode
            print(f"\n--- Turn {i+1} ---")
            
            # Step 1: Capture state
            state = state or self.capture_state()
            
            if state is None:
                print("[ERROR] State capture failed, exiting episode")
                break
            
            episode_data['observations'].append(state)
            
            # Step 2: Decide action
            action = self.decide_action(state)
            action_type = action.lower()  # For logging
            
            episode_data['actions_taken'].append({
                'action': action,
                'action_type': action_type,
                'turn': i + 1
            })
            
            # Step 3: Execute action
            self.execute_action(action)
        
        print(f"\n[{self.mode}] Episode {episode_num} actions completed")
        return episode_data
    
    def add_to_replay_buffer(self, observation, action, reward, new_state, done):
        """Add transition to replay buffer for online learning."""
        if self.mode != 'TRAINING':
            return
            
        if self.replay_buffer is None:
            from scripts.train_offline import ReplayBuffer  # Import from offline training
            self.replay_buffer = ReplayBuffer(capacity=500)
        
        transition = {
            'obs': observation,
            'action': action,
            'reward': reward,
            'next_obs': new_state,
            'done': done
        }
        self.replay_buffer.buffer.append(transition)
        
        if len(self.replay_buffer.buffer) > self.replay_buffer.capacity:
            self.replay_buffer.buffer.pop(0)
            
    def sample_and_update_model(self):
        """Sample batch from replay buffer and update model."""
        if self.mode != 'TRAINING' or self.replay_buffer is None or len(self.replay_buffer) < 32:
            return False
            
        batch = self.replay_buffer.sample_batch(batch_size=16)
        
        # Placeholder for actual PPO model update
        print("[UPDATE] Sampling and updating policy from replay buffer...")
        
        return True


def run_test_run(mode='TRAINING', episodes=3):
    """
    Run full test run sequence.
    
    What this does:
    1. Navigate to Barricade.gg (or use existing connection)
    2. Capture initial board state via browser tools
    3. Demonstrate actions with AI decision-making
    4. Document limitations discovered during test
    
    Returns episode data collected during test run.
    """
    
    # Setup directories
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    
    # Create replay buffer for online learning
    replay_buffer = ReplayBuffer(capacity=500) if 'ReplayBuffer' in globals() else None
    
    # Initialize test runner
    runner = BarricadeTestRunner(mode=mode)
    
    # Try to load pretrained checkpoint (or start with random policy)
    checkpoint_path = CHECKPOINT_DIR / "latest.ppo"
    
    if not checkpoint_path.exists():
        print("\n⚠️  No pretrained checkpoint found.")
        print("Starting with exploration mode (no model updates yet)...")
        # For demo purposes, we'll just demonstrate state capture and action execution
    else:
        print(f"\n✅ Using pretrained checkpoint: {checkpoint_path}")
        
        # In production, load actual PPO model here
        # agent = load_policy_from_checkpoint(checkpoint_path)
    
    try:
        episode_data = runner.collect_episode(1)
        
        # Save episode data to logs
        import glob
        existing_json_files = glob.glob(str(TRAINING_DIR / "logs" / "*.json"))
        episode_file_name = f"{mode}_episode_{len(existing_json_files)+1}.json"
        
        episode_data['mode'] = mode  # Ensure mode is in output
        
        with open(TRAINING_DIR / "logs" / episode_file_name, 'w') as f:
            json.dump(episode_data, f, indent=2)
        
        print("\n" + "="*60)
        print("✅ TEST RUN COMPLETED")
        print("="*60)
        print(f"\nTest run summary:")
        print(f"  Location: {TRAINING_DIR}/logs/")
        print(f"  Mode: {mode}")
        print(f"  Episodes completed: {episode_data['episodes_completed']}")
        
        return episode_data
        
    except Exception as e:
        print(f"\n❌ Test run failed with error: {e}")
        import traceback
        traceback.print_exc()
        raise


def main():
    parser = argparse.ArgumentParser(
        description='Test Run Script for Barricade.gg RL Agent',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run test run in training mode (updates model)
  python scripts/barricade_test_run.py --mode=training --episodes 3
  
  # Run test run in test mode (no model updates)
  python scripts/barricade_test_run.py --mode=test --episodes 5

Environment variables:
  BARRICADE_MODE=TRAINING|TEST|EVALUATION
  BARRICADE_EPISODES=3
"""
    )
    
    parser.add_argument(
        '--mode',
        choices=['training', 'test', 'evaluation'],
        default=os.environ.get('BARRICADE_MODE', 'training').lower(),
        help='Training mode (default: training)'
    )
    parser.add_argument(
        '--episodes', '-e',
        type=int,
        default=int(os.environ.get('BARRICADE_EPISODES', 3)),
        help='Number of episodes to run (default: 3)'
    )
    
    args = parser.parse_args()
    
    try:
        result = run_test_run(
            mode=args.mode.upper(),
            episodes=args.episodes
        )
        
        if result:
            print(f"\n🎉 Test run complete! Results saved to:")
            print(f"   {TRAINING_DIR}/logs/")
            
    except Exception as e:
        print(f"\n❌ Test run failed with error: {e}")
        import traceback
        traceback.print_exc()
        raise


if __name__ == '__main__':
    main()
