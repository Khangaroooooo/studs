# 🧠 EVERVAULT BRAIN - Complete System Documentation

## Overview

EverVault is an **automated knowledge management system** built on top of Obsidian, designed to scale your thinking exponentially through intelligent automation.

### Core Philosophy

```
Quality + Quantity = Massive Graph
```

The system prioritizes:
1. **Quality**: Every piece of information must be valuable, linked, and contextualized
2. **Quantity**: The graph should grow organically as you use the tools more
3. **Automation**: Everything possible is automated to reduce friction and increase throughput

---

## Architecture

### File Structure

```
~/Documents/EverVault/
├── brain/                          # Knowledge storage (obsidian-readable)
│   ├── core/                       # High-level concepts, core memory
│   ├── graph/                      # Knowledge graph nodes (auto-generated)
│   ├── notes/                      # Context notes and ephemeral content
│   └── temp/                       # Temporary tool output cache
├── scripts/                        # Automation scripts
│   ├── entity-extractor.py         # Extract concepts from tool outputs
│   ├── link-suggester.py           # Find missing wikilinks
│   ├── memory-batcher.py           # Intelligent write batching
│   ├── archival-bot.py             # Smart retention & rotation system
│   └── context-sentinel.py         # Auto-archive old files
├── brain.md                        # This file's content goes here
└── README.md                       # System documentation
```

### Data Flow

1. **Tool Outputs** → `brain/context/temp/*.output`
2. **Memory Batcher** → Deduplicates & routes to:
   - `brain/core/` for system-level concepts
   - `brain/graph/research/` for web findings
   - `brain/notes/` for conversation notes
3. **Entity Extractor** → Analyzes content for graph expansion
4. **Archival Bot** → Smart retention decisions based on link topology
5. **Context Sentinel** → Age-based archival (last resort)

---

## Automation Scripts

### 📝 Entity Extractor (`scripts/entity-extractor.py`)

Extracts entities, concepts, and relationships from tool outputs to expand the knowledge graph.

**Usage:**
```bash
python scripts/entity-extractor.py                    # Process temp/*.output files
python scripts/entity-extractor.py --analyze          # Preview extraction
python scripts/entity-extractor.py --create-links     # Auto-create wikilinks
```

**What it does:**
- Extracts projects, technical terms, people, companies
- Identifies relationships (X caused Y, X enhanced Z)
- Suggests links to existing graph nodes
- Creates new graph nodes for concepts

---

### 🔗 Link Suggester (`scripts/link-suggester.py`)

Finds missing wikilinks between existing knowledge nodes.

**Usage:**
```bash
python scripts/link-suggester.py                      # Show suggestions
python scripts/link-suggester.py --create             # Auto-create links
python scripts/link-suggester.py --missing            # Find gaps only
```

**What it does:**
- Analyzes all graph nodes for unlinked entities
- Finds concepts mentioned in text but not wikilinked
- Suggests bidirectional link opportunities
- Creates links to improve graph cohesion

---

### 🧠 Memory Batcher (`scripts/memory-batcher.py`)

Intelligent write batching with deduplication and auto-linking.

**Usage:**
```bash
python scripts/memory-batcher.py                      # Batch all pending writes
python scripts/memory-batcher.py --analyze            # Preview batch plan
python scripts/memory-batcher.py --dry-run            # No execution
```

**What it does:**
- Groups writes by tool type
- Removes redundant paragraphs
- Routes to appropriate directories:
  - `core/` → System-level concepts
  - `graph/research/` → Web research findings
  - `notes/` → Conversation notes
- Creates links to existing knowledge before writing

---

### 🤖 Archival Bot (`scripts/archival-bot.py`)

Smart retention system based on link topology and freshness analysis.

**Usage:**
```bash
python scripts/archival-bot.py                        # Analyze & suggest
python scripts/archival-bot.py --archive              # Execute archival
python scripts/archival-bot.py --promote              # Promote from archived/
python scripts/archival-bot.py --optimize             # Full optimization cycle
```

**What it does:**
- Analyzes link topology (inbound/outbound)
- Calculates freshness score vs. age
- Identifies small, old, unlinked files
- Archives based on composite scoring
- Promotes fresh/highly-linked content back

**Decision Factors:**
- Age penalty (older = archive sooner)
- Link count (0-1 links = strong archival signal)
- Size (small + old = likely draft/unused)
- Freshness (not referenced in core memory)
- Session markers (actively used = protect from archival)

---

### ⏰ Context Sentinel (`scripts/context-sentinel.py`)

Age-based auto-archive system (last resort, simple fallback).

**Usage:**
```bash
python scripts/context-sentinel.py                     # Archive files >7 days old
python scripts/context-sentinel.py --days=14           # Archive >14 days old
python scripts/context-sentinel.py --execute           # Auto-execute
```

**What it does:**
- Scans `brain/context/active/` for old files
- Archives to `brain/context/archived/` with timestamp
- Preserves history through archived filenames
- Maintains context folder health

---

## System Health & Monitoring

### Recommended Cron Jobs

Add these to your automation schedule:

```bash
# Every hour - Archive files older than 30 minutes
0 * * * * python ~/Documents/EverVault/scripts/memory-batcher.py --execute

# Every session end - Smart retention review
30 * * * * python ~/Documents/EverVault/scripts/archival-bot.py --report

# Weekly optimization (Sundays at 2am)
0 2 * * 0 python ~/Documents/EverVault/scripts/archival-bot.py --optimize

# Monthly graph expansion
0 3 1 * * python ~/Documents/EverVault/scripts/entity-extractor.py --create-links
```

### Context Folder Structure

```
brain/context/
├── active/              # Current session context (hot, <7 days)
├── archived/            # Archived content (preserved, rotatable)
└── temp/                # Tool output cache (processed by batcher)
```

**Retention Policies:**
- `active/`: Content actively used this session (< 7 days old)
- `archived/`: Content no longer actively referenced (>7 days, low links)
- `temp/`: Raw tool outputs (processed immediately by memory-batcher)

---

## Knowledge Graph Scale

### Goal: Massive Graph Visualization

The graph visualization in `brain/graph/index.md` should scale to show thousands of nodes while maintaining readability.

**Principles:**
1. **Quality over vanity**: Each node must represent a meaningful concept
2. **Link density**: Every node should have at least 2-3 inbound links
3. **Hierarchical clustering**: Group related concepts (research/, notes/, system/)
4. **Auto-expansion**: New concepts emerge naturally from tool usage
5. **Smart deduplication**: Similar concepts merged by entity-extractor

### Graph Growth Strategy

1. **Natural Expansion**: Each tool output adds 0-3 new graph nodes
2. **Link Generation**: Entity extractor creates bidirectional links
3. **Cluster Formation**: Related concepts self-organize into subgraphs
4. **Pruning**: Archival bot removes dead/low-value nodes

**Expected Scale:**
- After 1 week of use: 50-200 unique concepts
- After 1 month: 500-2000 concepts  
- After 6 months: 5,000+ concepts (depending on usage intensity)

---

## Best Practices

### ✅ DO

- Use all automation scripts without hesitation
- Let the graph grow organically through natural tool use
- Review archival-bot suggestions regularly (--report mode)
- Promote archived content back when it becomes relevant again
- Keep core memory (`brain/core/memory.md`) updated via memory tool

### ❌ DON'T

- Don't manually write to `brain/context/active/` (use automation)
- Don't create isolated notes without linking them
- Don't ignore archival-bot recommendations (dead weight)
- Don't let temp/ folder grow indefinitely (process every hour)
- Don't duplicate concepts across multiple files

### 🎯 OPTIMAL FLOW

1. **Tool runs** → Output to `temp/*.output`
2. **Memory batcher** → Deduplicates, routes to appropriate location
3. **Entity extractor** → Finds/expands graph nodes
4. **Link suggester** → Connects isolated concepts
5. **Archival bot** → Prunes low-value content
6. **Context sentinel** → Handles overflow

---

## Performance Optimization

### Context Window Management

The `memory-batcher.py` script helps manage context window:
- Groups related writes into single batches
- Removes redundant paragraphs before persistence
- Routes system/execution output separately from conversation notes

### File Size Limits

Recommended limits:
- Individual graph node: 5KB - 50KB (typical)
- Active folder total: <10MB per session
- Archived folder: Unlimited (history preservation)

If you're hitting context limits:
1. Run `archival-bot.py --optimize` to smartly rotate content
2. Manually review and consolidate highly-related graph nodes
3. Increase LM Studio context size in settings

---

## Troubleshooting

### Issue: "No pending tool outputs to batch"
**Solution**: Tool output isn't going to `temp/` folder. Check your automation pipeline ensures `hermes_tools` write to the temp directory.

### Issue: Archival bot suggests archiving too aggressively
**Solution**: Content may be session-critical but hasn't been linked yet. Manually add links from core memory or wait for more sessions to build link topology.

### Issue: Graph nodes growing too fast
**Solution**: Run entity extractor in `--analyze` mode first to review what's being extracted. Consider increasing threshold by adjusting similarity scores.

---

## Future Enhancements

1. **Multi-modal ingestion**: Support audio transcription, image OCR
2. **Web scraping agent**: Auto-ingest from RSS feeds, newsletters
3. **Knowledge synthesis**: Auto-draft summaries from clustered topics
4. **AI-generated annotations**: LLM adds context to graph nodes
5. **Graph visualization**: Embed GraphDB or D3.js visualization
6. **Search optimization**: Elasticsearch integration for semantic search

---

## Commands Cheat Sheet

```bash
# Daily maintenance
python scripts/memory-batcher.py --execute  # Process temp outputs
python scripts/archival-bot.py --report     # Review archival decisions

# Session end (auto or manual)
python scripts/context-sentinel.py          # Archive files >7 days old
python scripts/archival-bot.py --optimize   # Smart rotation

# Weekly graph maintenance  
python scripts/entity-extractor.py --create-links  # Expand graph
python scripts/link-suggester.py --create          # Fix missing links

# Full optimization cycle
python scripts/archival-bot.py --optimize  # End-to-end cleanup
```

---

## Conclusion

EverVault transforms your thinking by:
- **Automating persistence** so you never lose valuable insights
- **Growing the graph** organically through natural tool use  
- **Maintaining health** automatically through smart archival
- **Scaling intelligence** as your knowledge grows

The system is designed to be **exponentially better** than manual note-taking:
- More content captured (no friction)
- Better quality (deduplication, linking, clustering)
- Infinite scalability (context management)
- Self-healing (archival optimization loop)

**Your brain, amplified by automation.** 🧠✨
