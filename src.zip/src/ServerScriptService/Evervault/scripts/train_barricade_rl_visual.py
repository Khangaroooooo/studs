#!/usr/bin/env python3
"""
Barricade RL Visual Training - Real-time visualization of training sessions
Shows the 3x3 PvP arena with agents moving and fighting in real-time
"""

import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime
from typing import Optional, Tuple, List
from enum import Enum
from collections import deque
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class Agent(Enum):
    """Agent type enumeration"""
    PLAYER1 = 0   # Red team
    PLAYER2 = 1   # Blue team


class GameState:
    """Game state for a single match"""
    
    def __init__(self, size: int = 3):
        self.size = size
        self.grid_size = size * size
        
        # Initialize grid positions
        self.player_positions = {
            Agent.PLAYER1: (0, 0),      # Top-left
            Agent.PLAYER2: (2, 2)       # Bottom-right
        }
        
        # Health tracking
        self.health = {
            Agent.PLAYER1: 100,
            Agent.PLAYER2: 100
        }
        
        # Last action taken by each agent
        self.last_actions = {
            Agent.PLAYER1: None,
            Agent.PLAYER2: None
        }
        
        # State history for replay/buffering
        self.state_history = deque(maxlen=5)
        
        # Win/loss tracking
        self.winner = None
    
    def reset(self):
        """Reset to initial state"""
        self.player_positions = {
            Agent.PLAYER1: (0, 0),
            Agent.PLAYER2: (2, 2)
        }
        self.health = {
            Agent.PLAYER1: 100,
            Agent.PLAYER2: 100
        }
        self.last_actions = {
            Agent.PLAYER1: None,
            Agent.PLAYER2: None
        }
        self.state_history.clear()
        self.winner = None
    
    def to_tuple(self) -> tuple:
        """Convert state to tuple for storage"""
        positions_str = ",".join(f"{a}:{pos}" for a, pos in self.player_positions.items())
        health_str = ",".join(f"{a}:{int(h)}" for a, h in self.health.items())
        
        return (positions_str, health_str)
    
    def from_tuple(self, state_tuple: tuple):
        """Restore state from tuple"""
        pos_str, health_str = state_tuple
        
        self.player_positions = {}
        for item in pos_str.split(','):
            if ':' in item:
                agent_str, pos_str = item.split(':')
                agent = Agent.PLAYER1 if agent_str == 'Agent.PLAYER1' else Agent.PLAYER2
                x, y = map(int, pos_str.replace('(', '').replace(')', '').split(','))
                self.player_positions[agent] = (x, y)
        
        self.health = {}
        for item in health_str.split(','):
            if ':' in item:
                agent_str, health_str = item.split(':')
                agent = Agent.PLAYER1 if agent_str == 'Agent.PLAYER1' else Agent.PLAYER2
                self.health[agent] = int(health_str)


class BarricadeEnvironment:
    """Simple 3x3 PvP environment with visual capabilities"""
    
    def __init__(self, size: int = 3):
        self.size = size
        self.reset()
    
    def reset(self) -> GameState:
        """Reset and return new game state"""
        state = GameState(size=self.size)
        
        # Record initial state for history
        if not hasattr(self, 'state_history'):
            self.state_history = []
        self.state_history.append(state.to_tuple())
        
        logger.info(f"  New match started: P1@(0,0) vs P2@({self.size},{self.size})")
        
        return state
    
    def get_next_state(self, action_p1: int, action_p2: int) -> Tuple[GameState, bool]:
        """Execute one step and return new state"""
        
        state = self.state_history[-1] if self.state_history else GameState(size=self.size)
        from_tuple = state.to_tuple()
        state.reset()
        
        # Parse saved positions
        for item in from_tuple[0].split(','):
            if ':' in item:
                agent_str, pos_str = item.split(':')
                x, y = map(int, pos_str.replace('(', '').replace(')', '').split(','))
                state.player_positions[Agent.PLAYER1 if agent_str == 'Agent.PLAYER1' else Agent.PLAYER2] = (x, y)
        
        # Parse saved health
        for item in from_tuple[1].split(','):
            if ':' in item:
                agent_str, health_str = item.split(':')
                state.health[Agent.PLAYER1 if agent_str == 'Agent.PLAYER1' else Agent.PLAYER2] = int(health_str)
        
        # Execute actions (dumb AI for demo visualization)
        self._execute_actions(state, action_p1, action_p2)
        
        # Record new state
        new_tuple = state.to_tuple()
        self.state_history.append(new_tuple)
        
        # Check termination
        terminated = state.winner is not None
        
        return state, terminated
    
    def _execute_actions(self, state: GameState, action_p1: int, action_p2: int):
        """Execute actions and update state"""
        
        p1_pos = state.player_positions[Agent.PLAYER1]
        p2_pos = state.player_positions[Agent.PLAYER2]
        
        # Action 0: Stay in place
        # Action 1: Move toward opponent (simple heuristic)
        # Action 2: Move away
        # Action 3: Attack
        
        attack_p1 = action_p1 >= 3
        attack_p2 = action_p2 >= 3
        
        if attack_p1 and state.health[Agent.PLAYER1] > 0:
            p1_pos = self._move_toward(state, Agent.PLAYER1, p1_pos, p2_pos)
        
        if attack_p2 and state.health[Agent.PLAYER2] > 0:
            p2_pos = self._move_toward(state, Agent.PLAYER2, p2_pos, p1_pos)
        
        # Apply movement
        state.player_positions[Agent.PLAYER1] = p1_pos
        state.player_positions[Agent.PLAYER2] = p2_pos
        
        # Check collision for damage
        if p1_pos == p2_pos:
            # Both hit each other
            state.health[Agent.PLAYER1] -= 30
            state.health[Agent.PLAYER2] -= 30
        
        # Update last actions
        state.last_actions[Agent.PLAYER1] = action_p1
        state.last_actions[Agent.PLAYER2] = action_p2
        
        # Check win condition
        if state.health[Agent.PLAYER1] <= 0:
            state.winner = Agent.PLAYER2
        elif state.health[Agent.PLAYER2] <= 0:
            state.winner = Agent.PLAYER1
    
    def _move_toward(self, state: GameState, agent: Agent, my_pos: tuple, target_pos: tuple) -> tuple:
        """Move toward target position"""
        x1, y1 = my_pos
        x2, y2 = target_pos
        
        # Simple move toward opponent
        diff_x = x2 - x1
        diff_y = y2 - y1
        
        if abs(diff_x) >= abs(diff_y):
            new_x = min(state.size - 1, max(0, x1 + (1 if diff_x > 0 else -1)))
            return (new_x, y1)
        else:
            new_y = min(state.size - 1, max(0, y1 + (1 if diff_y > 0 else -1)))
            return (x1, new_y)
    
    def get_state_history(self) -> List[Tuple]:
        """Get training state history for EverVault persistence"""
        return list(self.state_history)
    
    def reset_training_history(self):
        """Clear training history"""
        self.state_history.clear()


class TerminalRenderer:
    """Renders game state to terminal with animations"""
    
    def __init__(self, size: int = 3, speed: float = 0.15):
        self.size = size
        self.speed = speed  # Seconds per step
        self.env = BarricadeEnvironment(size=size)
        self.state = None
    
    @property
    def is_running(self) -> bool:
        """Check if training/demo is running"""
        return self.state is not None and self.state.winner is None
    
    @property
    def reward(self) -> float:
        """Calculate reward based on game state"""
        if self.state is None:
            return 0.0
        
        p1 = self.state.player_positions[Agent.PLAYER1]
        p2 = self.state.player_positions[Agent.PLAYER2]
        
        # Distance-based reward
        dist = abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])
        base_reward = 5.0 / (dist + 1)
        
        # Health bonus for living
        if self.state.health[Agent.PLAYER1] > 50:
            base_reward += 2.0
        else:
            base_reward -= (self.state.health[Agent.PLAYER1] - 50) * 0.1
        
        if self.state.health[Agent.PLAYER2] > 50:
            base_reward += 2.0
        else:
            base_reward -= (self.state.health[Agent.PLAYER2] - 50) * 0.1
        
        return base_reward
    
    def render_grid(self) -> str:
        """Render the game grid"""
        if self.state is None:
            return "No game running"
        
        # Create visual representation
        rows = []
        for y in range(self.size):
            row = ""
            for x in range(self.size):
                pos_str = ""
                
                # Check if this position has an agent
                if (x, y) == self.state.player_positions[Agent.PLAYER1]:
                    p1_hp = int(self.state.health[Agent.PLAYER1] / 100 * 15) + 2
                    pos_str = f"🔴[{p1_hp}%]"
                elif (x, y) == self.state.player_positions[Agent.PLAYER2]:
                    p2_hp = int(self.state.health[Agent.PLAYER2] / 100 * 15) + 2
                    pos_str = f"🔵[{p2_hp}%]"
                
                row += pos_str
            
            rows.append(row)
        
        return "\n".join(rows)
    
    def render_status(self) -> str:
        """Render status information"""
        if self.state is None:
            return "Waiting to start..."
        
        p1 = self.state.player_positions[Agent.PLAYER1]
        p2 = self.state.player_positions[Agent.PLAYER2]
        
        status = f"P1 🔴 ({p1[0]},{p1[1]}) | P2 🔵 ({p2[0]},{p2[1]})"
        
        if self.state.winner is not None:
            winner_str = "WINNER!" if self.state.health[self.state.winner] > 0 else "ELIMINATED!"
            status += f"\n\nResult: {winner_str}\nReward: {self.reward:.1f}"
        
        return status
    
    def render(self, show_grid: bool = True) -> str:
        """Render full game state"""
        output = []
        
        if self.state and self.state.winner is not None:
            # Game over - show result
            grid = self.render_grid()
            status = self.render_status()
            return f"{grid}\n{status}"
        
        # Show animation
        grid = self.render_grid()
        status = self.render_status()
        
        output.append("🎮 BARRICADE RL TRAINING (Demo Mode)")
        output.append("=" * 50)
        output.append(grid)
        output.append("-" * 50)
        output.append(status)
        
        return "\n".join(output)
    
    def next_step(self, action_p1: int, action_p2: int):
        """Execute next training step"""
        self.state = self.env.get_next_state(action_p1, action_p2)
        
        # Auto-reset when game ends
        if self.state.winner is not None:
            self.state = self.env.reset()


class EverVaultContext:
    """EverVault context manager for Barricade RL training"""
    
    def __init__(self):
        self.vault_path = Path.home() / "Documents" / "Evervault" / "context"
        self.state_file = self.vault_path / "barricade_rl_state.json"
        
        # Ensure context directory exists
        self.vault_path.mkdir(parents=True, exist_ok=True)
        
        # Load existing state or initialize new session
        if self.state_file.exists():
            with open(self.state_file, 'r') as f:
                self.state = json.load(f)
                logger.info(f"Loaded EverVault context from {self.state_file}")
        else:
            self.state = {
                "epoch": 0,
                "steps": 0,
                "last_state_dict": None,
                "best_reward": -float('inf'),
                "session_start": datetime.now().isoformat(),
                "env_id": None,
                "config": {}
            }
            logger.info("Initialized new EverVault session")
    
    def save_state(self):
        """Save current training state to EverVault"""
        self.state["last_state_dict"] = {k: v for k, v in self.state.items() 
                                       if isinstance(v, (int, float, str, bool))}
        with open(self.state_file, 'w') as f:
            json.dump(self.state, f, indent=2, default=str)
        logger.info("State saved to EverVault")
    
    def log_to_vault(self, message):
        """Log training events to EverVault"""
        timestamp = datetime.now().isoformat()
        with open(self.vault_path / "training_events.log", 'a') as f:
            f.write(f"[{timestamp}] {message}\n")


# Load EverVault context at script start
evervault = EverVaultContext()

def get_dummy_actions() -> Tuple[int, int]:
    """Generate random dummy actions for training demo"""
    return 1 if hash(time.time() % 10) < 5 else 0, \
           2 if hash(time.time() % 10) < 3 else 1


def main():
    parser = argparse.ArgumentParser(description='Visual Barricade RL Training')
    parser.add_argument('--demo', action='store_true', 
                       help='Run demo mode with pre-configured simple environment')
    parser.add_argument('--env', type=str, default=None,
                       help='Environment name (e.g., "Barricade-v0", "simple-pvp-3x3")')
    parser.add_argument('--speed', type=float, default=0.15,
                       help='Animation speed in seconds per step (0 = fastest)')
    parser.add_argument('--max-steps', type=int, default=None,
                       help='Maximum steps to run before auto-exit')
    
    args = parser.parse_args()
    
    # Validate or set environment
    if args.demo:
        env_id = "simple-pvp-3x3"
        speed = min(args.speed, 0.2) if args.speed else 0.15  # Slightly faster for demo
        logger.info(f"🎮 Demo mode: using {env_id}")
    elif args.env:
        env_id = args.env
        speed = args.speed or 0.15
        logger.info(f"🎮 Using environment: {env_id}")
    else:
        env_id = "simple-pvp-3x3"
        speed = args.speed or 0.15
        logger.warning("⚠️ No environment specified, defaulting to simple-pvp-3x3")
    
    # Log initialization state
    evervault.log_to_vault(f"=== Visual Training Session Started ===\n"
                          f"Environment: {env_id}\n"
                          f"Speed: {speed}s/step\n"
                          f"Mode: {'Demo' if args.demo else 'Full'}")
    
    logger.info("🚀 Starting Barricade RL Visual Training with EverVault Context")
    logger.info(f"   Environment: {env_id}")
    logger.info(f"   Speed: {speed}s per step")
    logger.info(f"   Save Directory: /Users/kkhangaroo/models/barricade_rl")
    
    # Initialize renderer
    renderer = TerminalRenderer(size=3, speed=speed)
    
    print("\n" + "="*60)
    print("🎮 BARRICADE RL TRAINING - VISUAL MODE 🎮")
    print("="*60)
    print("Press Ctrl+C to stop anytime\n")
    logger.info("Interactive visualization started...")
    
    evervault.state["session_start"] = datetime.now().isoformat()
    evervault.state["env_id"] = env_id
    evervault.save_state()
    
    try:
        step_count = 0
        max_steps = args.max_steps
        
        while renderer.is_running:
            # Render current state
            output = renderer.render(show_grid=True)
            
            if max_steps and step_count >= max_steps:
                print(f"\nReached max steps limit ({max_steps})")
                break
            
            # Auto-execute actions for demo mode (continuous training)
            action_p1, action_p2 = get_dummy_actions()
            renderer.next_step(action_p1, action_p2)
            
            step_count += 1
            
            # Save state periodically
            if step_count % 50 == 0:
                evervault.state["steps"] = step_count
                evervault.state["best_reward"] = max(evervault.state.get("best_reward", -float('inf')), renderer.reward)
                evervault.save_state()
        
        # Training complete
        print(f"\n{'='*60}")
        print("🏁 TRAINING COMPLETE!")
        print("="*60)
        print(f"Total Steps: {step_count}")
        print(f"Final Reward: {renderer.reward:.2f}")
        
        # Save final state
        evervault.state["steps"] = step_count
        evervault.state["best_reward"] = max(evervault.state.get("best_reward", -float('inf')), renderer.reward)
        evervault.save_state()
        
        evervault.log_to_vault(f"Visual session complete. Steps: {step_count}, Final reward: {renderer.reward:.2f}")
        
    except KeyboardInterrupt:
        print("\n\n👋 Training interrupted by user")
        print(f"   Steps completed: {step_count}")
        print(f"   Best reward seen: {evervault.state['best_reward']:.2f}")


if __name__ == "__main__":
    sys.exit(main())
