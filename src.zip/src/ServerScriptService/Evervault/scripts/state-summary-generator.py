#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""State Summary Generator - Session Continuity Context Builder 📊

Usage:
    python scripts/state-summary-generator.py                    # Generate full summary
    python scripts/state-summary-generator.py --minimal           # Generate minimal summary
"""

import os
from datetime import datetime
from hermes_tools import read_file, write_file

# Configuration
VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "~/Documents/EverVault")
VAULT_PATH = os.path.expanduser(VAULT_PATH)

CONFIG = {
    "projects_dir": "projects",
    "tasks_dir": "tasks", 
    "learning_dir": "learning/notes",
    "context_state_file": "brain/context/state-summary.md",
}


def scan_projects():
    """Scan active projects."""
    projects = []
    
    projects_path = os.path.join(VAULT_PATH, CONFIG["projects_dir"])
    if not os.path.exists(projects_path):
        return projects
    
    for filename in sorted(os.listdir(projects_path)):
        if not filename.endswith(".md"):
            continue
        
        file_path = os.path.join(projects_path, filename)
        try:
            content = read_file(path=file_path).content[:300]
            
            lines = content.split('\n')
            title = ""
            status = "active"
            
            for line in lines:
                if line.startswith("title:"):
                    title = line.split(":", 1)[1].strip()
                elif line.strip().lower().startswith("status:"):
                    status_part = line.split(":", 1)[1].strip()
                    if "active" not in status_part.lower() and status_part.lower() not in ["in progress", "ongoing"]:
                        status = "paused"
            
            projects.append({
                "name": title or filename.replace(".md", ""),
                "status": status,
                "path": os.path.relpath(file_path, VAULT_PATH)
            })
        except Exception as e:
            print("Warning: Could not scan project " + filename + ": " + str(e))

    return projects


def scan_tasks():
    """Scan pending tasks."""
    tasks = []
    
    tasks_path = os.path.join(VAULT_PATH, CONFIG["tasks_dir"])
    if not os.path.exists(tasks_path):
        return tasks
    
    for filename in sorted(os.listdir(tasks_path)):
        if not filename.endswith(".md"):
            continue
        
        file_path = os.path.join(tasks_path, filename)
        try:
            content = read_file(path=file_path).content[:300]
            
            lines = content.split('\n')
            title = ""
            
            for line in lines:
                if line.startswith("title:") or (len(line.strip()) > 0 and not line.strip().startswith("#")):
                    if "[" in line:
                        task_title = line.replace("-", "").replace("[", "").replace("]", "")
                        title = task_title.split("(")[0].strip() if "(" in task_title else task_title
                    else:
                        title = line.strip()
            
            tasks.append({
                "name": title or filename.replace(".md", ""),
                "path": os.path.relpath(file_path, VAULT_PATH)
            })
        except Exception as e:
            print("Warning: Could not scan task " + filename + ": " + str(e))

    return tasks


def scan_recent_learnings():
    """Scan recent learning notes."""
    learnings = []
    
    learning_path = os.path.join(VAULT_PATH, CONFIG["learning_dir"])
    if not os.path.exists(learning_path):
        return learnings
    
    note_files = []
    for filename in os.listdir(learning_path):
        if not filename.endswith(".md"):
            continue
        try:
            filepath = os.path.join(learning_path, filename)
            mtime = os.path.getmtime(filepath)
            note_files.append((filepath, mtime))
        except:
            pass
    
    note_files.sort(key=lambda x: x[1], reverse=True)
    recent_files = note_files[:5]
    
    for file_path, mtime in recent_files:
        try:
            content = read_file(path=file_path).content[:300]
            
            lines = content.split('\n')
            title = filename.replace(".md", "")
            topics = []
            
            for line in lines[:10]:
                if line.startswith("title:"):
                    title = line.split(":", 1)[1].strip()
                
            learnings.append({
                "name": title,
                "path": os.path.relpath(file_path, VAULT_PATH),
                "date": datetime.fromtimestamp(mtime).strftime('%Y-%m-%d')
            })
        except Exception as e:
            print("Warning: Could not scan learning note " + filename + ": " + str(e))

    return learnings


def generate_state_summary(minimal=False):
    """Generate session state summary."""
    
    projects = scan_projects()
    tasks = scan_tasks()
    learnings = scan_recent_learnings()
    
    if minimal:
        project_names = [p['name'][:30] + '...' for p in projects[:3]]
        task_names = [t['name'][:25] + '...' for t in tasks[:3]]
        learning_names = [l['name'][:25] for l in learnings[:3]]
        
        lines = [
            "# Session State Summary - " + datetime.now().strftime("%Y-%m-%d %H:%M"),
            "",
            "## Quick Status",
            "",
            "**Active Projects**: " + str(len(projects)),
            "- " + ", ".join(project_names) if project_names else "None",
            "",
            "**Pending Tasks**:  " + str(len(tasks)),
            "- " + ", ".join(task_names) if task_names else "None",
            "",
            "**Recent Learnings**: " + str(len(learnings)) + " notes",
            "- " + ", ".join(learning_names) if learning_names else "None"
        ]
        return "\n".join(lines)
    else:
        lines = [
            "---",
            "title: state-summary",
            "topics: [[core/memory]], [[system/session-notes/]]",
            "date: " + datetime.now().strftime("%Y-%m-%d"),
            "status: active",
            "created-by: state-summary-generator.py",
            "last-reviewed: " + datetime.now().strftime("%Y-%m-%d %H:%M"),
            "---",
            "",
            "# Session State Summary - Continuity Context 📊",
            "",
            "*Generated automatically for seamless session continuation.*",
            "",
            "---",
            "",
            "## 🧠 Current Memory State",
            "",
            "### Core Knowledge Hub",
            "- Main persistent memory: [[core/memory]]",
            "- Atomic facts catalog: " + str(len(projects) + len(tasks)) + " knowledge units",
            "- Personal identity facts: Persisted via memory tool",
            "",
            "---",
            "",
            "## 🚧 Active Projects (" + str(len(projects)) + ")"
        ]
        
        if projects:
            for p in projects:
                name = p['name'][:50] + '...' if len(p['name']) > 50 else p['name']
                lines.extend([
                    "",
                    "### **{0}**".format(name),
                    "`{0}`".format(p['path']),
                    "   Status: " + p['status'].capitalize()
                ])
        else:
            lines.append("")
            lines.append("No active projects found.")
        
        lines.extend([
            "",
            "---",
            "",
            "## ✅ Pending Tasks (" + str(len(tasks)) + ")"
        ])
        
        if tasks:
            for t in tasks[:5]:
                name = t['name'][:45] + '...' if len(t['name']) > 45 else t['name']
                lines.extend([
                    "",
                    "### **{0}**".format(name),
                    "`{0}`".format(t['path'])
                ])
        else:
            lines.append("")
            lines.append("No pending tasks found.")
        
        lines.extend([
            "",
            "---",
            "",
            "## 📚 Recent Learnings (" + str(len(learnings)) + ")"
        ])
        
        if learnings:
            for l in learnings[:5]:
                name = l['name'][:40] + '...' if len(l['name']) > 40 else l['name']
                lines.extend([
                    "",
                    "**{0}**".format(name),
                    "`{0}`".format(l['path']),
                    "Date: " + l['date']
                ])
        else:
            lines.append("")
            lines.append("No recent learning notes found.")
        
        lines.extend([
            "",
            "---",
            "",
            "## 🔑 Key Insights from Core Memory",
            "",
            "- Review [[core/memory]] for current knowledge state",
            "- Check fact catalog in [[brain/core/facts/index.md]]",
            "",
            "---",
            "",
            "## 🎯 Continuation Context",
            "",
            "### What Was Being Worked On:",
        ])
        
        if projects:
            for p in projects[:3]:
                lines.append("- " + p['name'][:50])
        else:
            lines.append("No active projects mentioned")
            
        lines.extend([
            "",
            "### Next Logical Steps",
            "- Review pending tasks in `[[tasks/]]` folder",
            "- Check project status in `[[projects/]]` folder",
            "- Scan recent learnings for connections to make",
            "- Load core/memory.md and memory tool facts for full context",
            "",
            "---",
            "",
            "## 🧭 Ready for Continuation ✅",
            "",
            "Load this file along with `[[core/memory]]` when starting continuation session.",
            ""
        ])
        
        return "\n".join(lines)


def main():
    """Main entry point."""
    import sys
    
    minimal = "--minimal" in sys.argv

    print("\n" + "=" * 70)
    print("📊 STATE SUMMARY GENERATOR")
    print("=" * 70)
    print("Mode: " + ("Minimal" if minimal else "Full") + " summary\n")

    summary = generate_state_summary(minimal=minimal)

    print(summary)

    try:
        write_file(path=VAULT_PATH + "/" + CONFIG["context_state_file"], content=summary + "\n")
        print("\n✅ Summary written to: " + CONFIG["context_state_file"])
    except Exception as e:
        print("\n⚠️ Could not write summary file: " + str(e))

    return summary


if __name__ == "__main__":
    main()
