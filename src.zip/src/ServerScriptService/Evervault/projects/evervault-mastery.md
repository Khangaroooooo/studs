---
name: evervault-mastery
description: Mastering the full potential of EverVault brain system - usage patterns, optimization, and advanced techniques
status: building
created: 2026-06-01
topics: 
  - [[brain/core/memory]]
  - [[projects/evervault-brain-system]]
  - [[facts/hybrid-persistence-pattern]]
  - [[brain/.getting-started]]
related-personal-info:
  - [[personal-info/occupation]]
  - [[personal-info/location]]
  - [[personal-info/tools-and-env]]
---

## What Is This Project?

**EverVault Mastery** is a meta-project focused on learning how to extract maximum value from your EverVault brain system. It's about:

1. **Understanding Usage Patterns** - Discover the best ways to interact with each layer of the brain
2. **Optimizing Workflow** - Streamline how you add, retrieve, and connect knowledge
3. **Exploring Advanced Features** - Unlock hidden capabilities and deeper integration patterns
4. **Building Stronger Connections** - Create a denser, more navigable knowledge graph

### The Three Mastery Dimensions:

```
┌─────────────────────────────────────────────────────┐
│  DIMENSION 1: FOUNDATIONAL FLUENCY                   │
│  ───────────────────────                            │
│  • Understand each folder's purpose                  │
│  • Know when to use memory tool vs. filesystem       │
│  • Master wikilink linking conventions               │
│  • Read core documentation systematically             │
└─────────────────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────────────────┐
│  DIMENSION 2: EFFICIENT WORKFLOW                      │
│  ───────────────────────                            │
│  • Rapid note creation without breaking patterns      │
│  • Fast knowledge retrieval and synthesis            │
│  • Batch operations and automation                   │
│  • Smart use of context vs. persistent memory        │
└─────────────────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────────────────┐
│  DIMENSION 3: ADVANCED OPTIMIZATION                   │
│  ───────────────────────                            │
│  • Graph density optimization                        │
│  • Pattern recognition across notes                  │
│  • Cross-session knowledge refinement                 │
│  • Identifying gaps and blind spots                  │
└─────────────────────────────────────────────────────┘
```

---

## 🎯 Mastery Goals

### Primary Objectives:

1. **Fluency** - Be able to use the brain system without second-guessing folder structures or tools
2. **Efficiency** - Add knowledge in under 5 minutes; retrieve relevant context in under 30 seconds
3. **Density** - Achieve average of 3-5 wikilinks per note for strong graph connectivity
4. **Depth** - Develop deep understanding of complex topics through atomic note decomposition
5. **Automation** - Automate repetitive tasks (persistence, logging, health checks)

### Success Metrics:

| Metric | Target | Current Status |
|--------|--------|----------------|
| New notes/week | 3-5 | 🟡 Starting from zero |
| Notes with memory persistence | 90%+ of personal info & facts | 🔴 Templates created, needs filling |
| Average note connections | 4+ wikilinks | 🟡 Template has link sections |
| Core memory updates | Every session | ✅ Ready for use |
| Context folder size | <5 files | ✅ Clean (<5 files) |

---

## 📚 Mastery Learning Path

### PHASE 1: FOUNDATIONAL FLUENCY (Week 1-2)

**Goal:** Understand and comfort with the brain system basics

#### Week 1: Structure & Navigation
- [ ] **Read all README-style docs first**:
  - `[[QUICK-START.md]]` - 3-minute setup guide
  - `[[brain/core/memory.md]]` - Core memory hub (read before every session!)
  - `[[system/memory-tool-guide.md]]` - Persistence mechanics
  - `[[brain/.getting-started]]` - Comprehensive getting started

- [ ] **Map the folder structure**:
  - Understand each folder's purpose and contents
  - Create a personal cheat sheet for quick reference
  - Practice navigating without terminal commands

- [ ] **Master the memory tool pattern**:
  ```python
  # The essential persistence pattern:
  from hermes_tools import read_file, memory
  
  content = read_file(path="brain/personal-info/name.md").content
  memory(action="add", target="user", content=content)
  ```

#### Week 2: Core Operations
- [ ] **Practice core brain operations**:
  - Adding new notes to `learning/notes/` using template
  - Creating atomic facts in `brain/core/facts/`
  - Updating personal info and persisting with memory tool
  
- [ ] **Master wikilink conventions**:
  ```markdown
  # Every brain note should link:
  1. [[core/memory.md]] ← REQUIRED! Connects to hub
  2. 1-2 related notes from different folders
  3. Status: new | refining | integrated
  
  # Example structure:
  ---
  title: What I Learned
  topics: [[related-topic-1]], [[related-topic-2]]
  related-to: [[core/memory.md]], [[existing-note]]
  status: new
  ---
  ```

- [ ] **Learn the session lifecycle**:
  - Start: Read `[[core/memory.md]]`, check tasks/projects
  - During: Add learning notes, create facts, update personal info
  - End: Update memory, create session log, clean context folder

### PHASE 2: EFFICIENT WORKFLOW (Week 3-4)

**Goal:** Speed and efficiency in knowledge management

#### Week 3: Rapid Operations
- [ ] **Develop fast note creation workflow**:
  - Memorize common templates and their purposes
  - Create keyboard shortcuts for frequent file patterns
  - Use search_files to find existing notes before creating

- [ ] **Master context vs. persistence decisions**:
  ```python
  # Decision tree:
  if content_is_critical_across_sessions:
      write_file(path="brain/core/facts/*.md", ...)
      memory(action="add", target="user", content=...)
  elif content_is_personal_identity:
      write_file(path="brain/personal-info/*.md", ...)
      memory(action="add", target="user", content=...)
  elif content_is_session_discovery:
      write_file(path="learning/notes/*.md", ...)
      # No persistence needed - can add later if important
  else:
      write_file(path="context/temporary-info.md", ...)
      # Clean up at session end!
  ```

- [ ] **Practice batch operations**:
  - Multiple notes in one learning session
  - Batch fact creation for related topics
  - Consolidated personal info updates

#### Week 4: Optimization Patterns
- [ ] **Learn pattern recognition**:
  - Identify when to split large ideas into atomic notes
  - Recognize gaps in knowledge coverage
  - Spot orphaned notes (notes with no incoming links)

- [ ] **Master graph optimization**:
  - Add cross-references between related facts
  - Create summary/overview notes for complex topics
  - Build "entry point" notes for common search queries

### PHASE 3: ADVANCED OPTIMIZATION (Month 2+)

**Goal:** Deep mastery and system refinement

#### Month 2: System Integration
- [ ] **Master automation scripts**:
  - `scripts/session-end-routine.py` - Automate session cleanup
  - Create custom scripts for frequent workflows
  - Set up cron jobs for health checks

- [ ] **Develop personal search strategies**:
  ```python
  # Pattern for finding related content:
  search_files(pattern="React.*hook", target="content", file_glob="*.md")
  search_files(query="LM Studio context window optimization", limit=5)
  ```

- [ ] **Build mental model of graph structure**:
  - Know where to find facts about specific topics
  - Understand navigation shortcuts and conventions
  - Master the folder hierarchy at a glance

#### Month 3+: Deep Integration
- [ ] **Customize for your workflow**:
  - Adapt templates to personal preferences
  - Create specialized folders if needed
  - Develop personal shorthand conventions

- [ ] **Teach others (deep mastery)**:
  - Can explain the system to new users?
  - Can troubleshoot common issues?
  - Can suggest optimizations for others' brains?

---

## 🔧 Advanced Techniques

### Technique 1: Pattern-Based Note Creation

**Instead of:** Creating notes from scratch each time

**Do:** Use pattern recognition + template variation

```python
# Before creating a note, check if similar exists:
search_files(pattern="topic-keyword", target="content", file_glob="*.md")

# If no exact match found → create using appropriate template
if content_is_new_discovery:
    path = "learning/notes/detailed-topic-name.md"
elif content_is_atomic_facts:
    path = "brain/core/facts/specific-concept.md"
elif content_is_personal_info:
    path = "brain/personal-info/new-aspect.md"
```

### Technique 2: Smart Linking Strategy

**Goal:** Dense, navigable graph without over-linking

**Rules:**
1. Every new note links to `[[core/memory.md]]` (required!)
2. Add 2-3 more related notes (mix of folders is good)
3. Use hierarchical linking:
   ```markdown
   # Entry-level link (for newcomers):
   [[QUICK-START.md]] or [[brain/.getting-started]]
   
   # Mid-level link (for experienced users):
   [[core/memory.md]] - main hub
   
   # Deep-link (for experts navigating graph):
   [[facts/hybrid-persistence-pattern]], [[connection-guide]]
   ```

### Technique 3: Graph Density Optimization

**Problem:** Notes that are "orphaned" (no incoming links) or have no connections

**Solution:** 

#### Step 1: Find orphaned notes
```python
# Check which notes exist but aren't well-linked
search_files(pattern="status.*new", target="content", file_glob="*.md")
```

#### Step 2: Add hub links to orphans
```markdown
# For every new/unknown note, add these links:
- [[core/memory.md]] ← Required!
- [[projects/evervault-brain-system]] - Project context
- [[brain/.getting-started]] - Entry point for new users
```

#### Step 3: Create summary notes for topic clusters
If you have:
- `learning/notes/hermes-agent-basic-concepts.md`
- `learning/notes/hermes-memory-tool-guide.md`
- `learning/notes/hermes-session-patterns.md`

Create:
- `brain/core/facts/hermes-agent-overview.md` - Summary linking all three

### Technique 4: Context Management Mastery

**The context folder antipattern:** Letting it grow unbounded

**The mastery pattern:**

```python
# At session end:
from hermes_tools import read_file, terminal
import os

context_dir = "brain/context"
files_in_context = len(terminal(command=f'ls -1 {context_dir}').output.split())

if files_in_context > 5:
    print("🚨 CONTEXT FOLDER BLOAT DETECTED!")
    # Review each file, decide to archive/delete/update
else:
    pass  # Still good, but review for relevance anyway
```

---

## 🎓 Mastery Assessment Checklist

### Week 1-2 (Foundational Fluency):
- [ ] Can I explain what `[[core/memory.md]]` is without reading it?
- [ ] Do I know when to use memory tool vs. not using it?
- [ ] Can I add a new learning note in under 5 minutes?
- [ ] Have I read all the "read me first" documentation?
- [ ] Do my new notes link to `[[core/memory.md]]` and at least one other note?

### Week 3-4 (Efficient Workflow):
- [ ] Can I quickly distinguish between fact, learning note, and context?
- [ ] Am I persisting personal info files with memory tool consistently?
- [ ] Do I clean context folder every session end without forgetting?
- [ ] Have I created atomic facts instead of god-files?
- [ ] Am I creating session logs regularly in `system/session-notes/`?

### Month 2+ (Advanced Optimization):
- [ ] Can I navigate the graph mentally without opening files?
- [ ] Do I recognize when to split a large idea into atomic notes?
- [ ] Have I identified and filled gaps in my knowledge coverage?
- [ ] Am I using search_files efficiently to avoid duplicate creation?
- [ ] Can I explain the system to someone new?

---

## 📖 Recommended Reading Order for Mastery

### Essential First Reads (Do These Every Session):
1. `[[brain/core/memory.md]]` - Current knowledge state
2. `[[QUICK-START.md]]` - Quick reference for operations
3. `[[system/session-notes/template.md]]` - Session logging template

### Deep Understanding (Read when needed):
4. `[[projects/evervault-brain-system]]` - Full project overview
5. `[[brain/core/connection-guide]]` - Architecture details
6. `[[system/memory-tool-guide.md]]` - Persistence mechanics

### Mastery Documentation (Reference as you advance):
7. `[[brain/core/facts/index.md]]` - All atomic facts catalog
8. `[[facts/hybrid-persistence-pattern]]` - Persistence explained
9. `[[facts/session-end-routine]]` - Session cleanup steps
10. `[[brain/.getting-started]]` - Comprehensive getting started

---

## 🔄 Integration with Existing Projects

### Connection to [[projects/evervault-brain-system]]:

This mastery project complements the main brain system project by focusing on **how you use** the system rather than **what the system is**. 

- **EverVault Brain System** = What we're building (architecture, structure, tools)
- **EverVault Mastery** = How you become fluent with it (patterns, optimization, speed)

### Suggested workflow integration:

1. When working on `[[projects/evervault-brain-system]]` → Create learning notes about discoveries here
2. After completing a brain system task → Use mastery project to document patterns learned
3. At session end → Check both projects for action items in `tasks/` folder

---

## 📝 Session Template for Mastery Work

```markdown
# EverVault Mastery Session Log - {{session-date}}

## Session Focus
- [ ] Foundation review (if Week 1-2)
- [ ] Workflow efficiency drills (if Week 3-4)
- [ ] Graph optimization exercises (if Month 2+)

## Notes Created
- [[learning/notes/session-focus-topic]] - Main learning note
- Any atomic facts added to `brain/core/facts/`

## Graph Actions
- Added wikilinks from: [...]
- Connected new notes to hub: ✅
- Cleaned context folder: ✅

## Mastery Progress
- [ ] Completed week/month milestone?
- [ ] Identified a workflow bottleneck?
- [ ] Discovered an advanced technique?

## Next Session Preview
- Key topics to bring forward: [...]
- Gaps to fill in knowledge graph: [...]
```

---

## 🎯 Ultimate Mastery Goals

### Short-term (3 months):
- Create 20+ learning notes documenting discoveries
- Build 30+ atomic facts about brain patterns and tools
- Achieve 95%+ consistency on memory tool persistence for critical info
- Maintain core memory within last 1-2 sessions

### Medium-term (6 months):
- Navigation becomes instinctual (no need to read READMEs)
- Average of 4-6 wikilinks per note (dense graph)
- Can troubleshoot common issues independently
- Graph shows healthy density and coverage

### Long-term (1 year+):
- System runs on autopilot for basic operations
- You become a mentor who can onboard new users
- Brain system has evolved to support your full thinking workflow
- You're adding knowledge faster than you forget it

---

## 🔗 Quick Reference Links

### Always Accessible:
- `[[brain/core/memory.md]]` - Start here every session
- `[[QUICK-START.md]]` - 3-minute operations guide
- `[[brain/.getting-started]]` - Comprehensive onboarding

### Mastery-Specific:
- `[[projects/evervault-brain-system]]` - Main system project
- `[[brain/core/facts/index.md]]` - All facts catalog

### Architecture Docs:
- `[[system/memory-tool-guide.md]]` - Persistence explained
- `[[brain/core/connection-guide]]` - Linking conventions

---

*Created: 2026-06-01 as part of EverVault Mastery project  
Last updated: Session 2026-06-01 initial setup  
Purpose: Track mastery progress and usage optimization  
Status: building → mastering
*
