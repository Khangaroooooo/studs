---
name: evervault-brain-system
description: Multi-layer knowledge graph implementation with persistent memory
status: building
created: 2026-06-01
topics: 
  - [[brain/core/memory]]
  - [[facts/hybrid-persistence-pattern]]
  - [[facts/session-end-routine]]
related-personal-info:
  - [[personal-info/occupation]]
  - [[personal-info/location]]
---

## What Is This Project?

**EverVault PC Brain System** is a local AI knowledge management architecture that combines:

- **Obsidian vault** for filesystem-based note storage and linking
- **Hermes Agent** with LM Studio integration for intelligent synthesis
- **Memory tool** for cross-session persistence of important facts
- **Multi-layer design** separating persistent, work-in-progress, and learning content

### Architecture Summary (Three Layers):

```
┌─────────────────────────────────────────────┐
│  LAYER 1: PERSISTENT CORE                   │
│  ───────────────────────────                │
│  • brain/core/memory.md ← Main hub          │
│  • brain/personal-info/*.md                 │
│  • brain/core/facts/*.md                    │
└─────────────────────────────────────────────┘
              ↓ Links to
┌─────────────────────────────────────────────┐
│  LAYER 2: WORK IN PROGRESS                   │
│  ────────────────────                       │
│  • brain/memories/*.md (events/experiences)  │
│  • projects/*.md                             │
│  • tasks/*.md                                │
└─────────────────────────────────────────────┘
              ↓ Feeds into  
┌─────────────────────────────────────────────┐
│  LAYER 3: LEARNING & CONTEXT                 │
│  ────────────────────                       │
│  • brain/learning/notes/*.md (new learning)  │
│  • brain/context/*.md (temporary context)    │
└─────────────────────────────────────────────┘
```

---

## Why Do It?

### Goals:

1. **Persistent Memory** - Important facts survive across Hermes sessions using the memory tool
2. **Knowledge Graph** - Dense wikilink network enables discovery and connections
3. **Session Hygiene** - Automated routines ensure brain stays healthy
4. **Local Processing** - All data stays on your device; no cloud APIs for sensitive info
5. **Grow Smarter Over Time** - Each session adds new context and refinements

### What I Hope to Learn:

- How to maintain a knowledge base that scales
- Best practices for semantic + episodic memory systems
- Patterns for reliable persistence across AI assistants
- How atomic notes connect into powerful graph structures

---

## Current Status

### Phase: building → testing

This project has been rebuilt from scratch on 2026-06-01 with the following completion state:

✅ **Complete:**
- Full folder structure (brain/, projects/, tasks/, system/)
- Core memory hub and connection guide
- Personal info templates created
- Learning notes system prepared
- Project and task management ready
- Session logging infrastructure in place
- Memory tool integration documented
- Getting started guides written

🟡 **In Progress:**
- Filling personal info with actual user data
- Adding atomic facts to core/facts/ folder
- Creating first learning notes documenting discoveries
- Verifying memory tool persistence works correctly
- Building up knowledge graph density through linking

---

## Recent Work (Last 3 Sessions)

### Session 2026-06-01: Initial Rebuild ✅

**Status**: Completed  
**Key Outcomes:**
- Rebuilt brain system from scratch with multi-layer architecture
- Created 39 files across all folders
- Documented hybrid persistence pattern (filesystem + memory tool)
- Established session hygiene routines
- Wrote comprehensive guides for new users

### Session 2026-06-01: Improvement Sprint 🔄

**Status**: In Progress (ongoing now)  
**Key Outcomes:**
- Identified and filled gaps in documentation
- Created atomic facts in core/facts/ folder
- Documented existing memories in memories.md
- Added connection quality rules and principles

---

## Notes & Resources

### Core Documentation:
- [[brain/core/memory.md]] - Main persistent memory hub (READ FIRST!)
- [[brain/.getting-started]] - Quick start guide for new users
- [[system/memory-tool-guide.md]] - How cross-session persistence works

### Architecture Documentation:
- [[connection-guide]] - How notes link together in the knowledge graph
- [[facts/hybrid-persistence-pattern]] - Persistence mechanism explanation
- [[brain/core/facts/index.md]] - Index of all atomic facts

---

## Key Challenges

### Challenge 1: Memory Tool Persistence Reliability
**Status**: Known issue, using automation script as solution  
**Current Approach**: `scripts/session-end-routine.py` automates persistence

### Challenge 2: Context Folder Bloat Prevention  
**Status**: Mitigated with maintenance pattern  
**Current Approach**: Regular review and archival from context folder

### Challenge 3: Personal Info Completion
**Status**: In progress  
**Current Approach**: Filling templates with actual user data + memory persistence

---

## Next Steps (Top 3)

- [ ] Complete filling personal info files with user's actual data
- [ ] Add first learning notes documenting this brain setup session
- [ ] Verify memory tool persistence works for all critical facts
- [ ] Create remaining atomic facts for documented patterns
- [ ] Build out fun-and-trivia and creative context sections

---

## Connections to Existing Knowledge

### Links to Learning Notes:
- [[learning/notes/everyvault-initial-setup]] - For documenting this setup session
- Future notes will document discoveries about the brain architecture

### Links to Facts:
- [[facts/hybrid-persistence-pattern]] - Core persistence mechanism
- [[facts/session-end-routine]] - Session hygiene automation pattern  
- [[facts/context-folder-maintenance]] - Bloat prevention strategy

---

## Brain Health Metrics

| Metric | Target | Current Status |
|--------|--------|----------------|
| Core memory updated | within 3 sessions | ✅ Recent (2026-06-01) |
| Personal info filled | all files exist | 🟡 Templates created, needs filling |
| Context folder size | <5 files | ✅ Clean (<5 files) |
| Learning notes added | at least 1 per week | 🔴 Empty - ready for discoveries |

---

## See Also

- `[[core/memory.md]]` - Your persistent memory hub (start here!)
- `[[brain/core/facts/index.md]]` - Browse all atomic facts
- `[[system/metrics/brain-health-report]]` - Full health metrics dashboard

---

*Project created: 2026-05-31 initial version  
Last updated: Session 2026-06-01 rebuild + improvement sprint*
