---
title: auto-session-continuation
topics: [[core/memory]], [[system/architecture]], [[scripts/session-end-routine]]
status: planned
priority: high
date: 2026-06-08
created-by: user-initiative
---

# 🔄 Auto-Session Continuation System

## What It Does

When a Hermes session ends due to context limits, this system **automatically starts a new session** and continues where you left off by loading the persisted state from the previous session.

### The Flow

```
Session 1 → [Hit context limit] → Persisted memory + core/memory.md + session logs
                                    ↓
                            Auto-trigger continuation
                                    ↓
        Session 2 (new) ← Loads all context from Layer 1 persistence
                                    ↓
                          Resume work with full memory!
```

## Why We Need This

### Problem: Context Limits Are Inevitable
- Hermes sessions have token/context limits
- Complex tasks naturally outgrow single-session capacity
- Without continuation, progress is lost when limit is hit

### Solution: Auto-Continuation Pattern
- **Persisted Layer 1** (`core/memory.md`, `personal-info/`, `facts/`) survives every session restart
- **Session logs** (`system/session-notes/`) provide continuity context
- **Memory tool contents** carry forward all critical facts and preferences
- New session inherits everything → Zero progress loss

## Components Needed

### 1. Detection Layer
Identify when session ended due to context limits:
```python
# Check for termination indicators in current session
if "context limit" in last_session_output or \
   "token limit" in last_session_output or \n   session_ended_normally == False:
    trigger_continuation()
```

### 2. Persistence Layer (Already Built!) ✅
- `brain/core/memory.md` - Core knowledge hub (persistence ready)
- `brain/personal-info/*.md` - Identity facts (persistence ready)  
- `brain/core/facts/*.md` - Atomic knowledge (persistence ready)
- `system/session-notes/` - Session history and highlights

### 3. Continuation Trigger Script ⏳
New script to auto-start next session:
```python
# scripts/session-continuator.py
"""
Auto-session continuation orchestrator.

When triggered, loads all persisted state and starts new Hermes session.
"""
```

### 4. Session State Summary (Optional Enhancement) ⏳
Generate summary of where to continue at each session end:
```python
# scripts/state-summary-generator.py
"""
Generate session state summary for continuation context.

Outputs to brain/context/state-summary.md with:
- Current projects and status
- Recent learnings and discoveries
- Pending tasks or action items
"""
```

## Architecture Integration

### Fits Into Existing System:

**Session Start Flow:**
1. User starts Hermes session
2. Load `core/memory.md` ← Already automated!
3. Load persisted facts from memory tool ← Already works!
4. Review `system/session-notes/` for continuity ← Optional enhancement

**Session End Flow (Current):**
1. `session-end-routine.py` runs ✅
2. Persists personal info ✅
3. Creates session log ✅
4. Generates health report ✅

**Session End Flow (Enhanced with Continuation):**
1. `session-end-routine.py` runs ✅
2. Persists personal info ✅  
3. Creates session log ✅
4. **Optionally triggers auto-continuation** ⏳ NEW!

## Implementation Plan

### Phase 1: Manual Trigger Mode ⭐ (Start Here)
- Create `scripts/session-continuator.py`
- Add `--continue` flag to `session-end-routine.py`
- User explicitly opts in to continuation at session end

```bash
python scripts/session-end-routine.py --continue
# OR after session ends:
python scripts/session-continuator.py --load-context
```

### Phase 2: Auto-Detect Mode 🚀 (Future Enhancement)
- Add detection logic for context limit terminations
- Automatically trigger continuation when appropriate
- Respects user preferences (some sessions don't need it)

### Phase 3: Intelligent Continuation 💡 (Advanced)
- Analyze what needs to continue vs. what was resolved
- Skip continuation if session completed successfully
- Smart decision-making about when to auto-restart

## Files to Create

```bash
# Core continuation script
scripts/session-continuator.py

# Optional: State summary generator  
scripts/state-summary-generator.py

# Update existing scripts
- scripts/session-end-routine.py (add --continue flag)
- brain/core/memory.md (document continuation support)
```

## See Also

- `[[scripts/session-end-routine]]` - Current session cleanup automation
- `[[brain/core/memory]]` - Persistent memory hub
- `[[system/session-notes/]]` - Session history and continuity context
- `[[core/facts/hybrid-persistence-pattern]]` - Foundation for auto-continuation

## Related Concepts

### Hybrid Persistence Pattern (Foundation) ✅
The key enabler: Obsidian filesystem + memory tool persistence ensures all critical facts survive across sessions. This system **leverages** that foundation.

### Session Hygiene (Complement) ✅
The `session-end-routine.py` already creates clean, persisted state for next session. Auto-continuation just makes the jump automatic when needed.

---

## 🎯 Current Status: Phase 1 - Manual Trigger Ready

Ready to implement manual trigger mode! You tell me where to start building this system in your brain. Suggestions:

- **Option A**: Create `scripts/session-continuator.py` standalone script
- **Option B**: Enhance existing `session-end-routine.py` with `--continue` flag  
- **Option C**: Both (separate script + integrated flag)

Which approach do you prefer, or shall I implement all three?
