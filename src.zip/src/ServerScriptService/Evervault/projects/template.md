# Project Template - Use This for New Projects

```markdown
---
name: [Project Name]
description: One sentence summary
status: exploring | designing | building | testing | done
created: YYYY-MM-DD
topics: [[topic-1]], [[topic-2]]
related-personal-info: 
  - [[personal-info/occupation]]
  - [[personal-info/preferences]]
---

## What Is This Project?

[Clear description]

## Why Do It?

[Motivation, goals, what you hope to learn or achieve]

## Current Status

### Phase: [exploring / designing / building / testing]

### Recent Work (Last 3 Sessions):

1. Date: Work done
2. Date: Work done  
3. Date: Work done

## Notes & Resources

- [[note-about-this-project]]
- [[another-relevant-note]]
- External links here...

## Key Challenges

- Challenge 1 → Working on solution
- Challenge 2 → Not sure yet

## Next Steps (Top 3)

[ ] Task 1
[ ] Task 2  
[ ] Task 3

## Connections to Existing Knowledge

### Links to Learning Notes:
- [[learning-note-1]] - relevant because...
- [[learning-note-2]] - connects via...

### Links to Facts:
- [[fact-about-this-topic]]
- [[related-concept-fact]]

### Links to Memories:
- [[memory-of-similar-project]]

---

*Created: {{session-date}}*  
*See also: [[brain/core/memory.md]] for main memory hub*
```
