# 📶 Handheld USB-C WiFi Router Project

**Status:** Planning & Research Phase  
**Goal:** Create a portable hardware device that connects via USB-C to phone/computer and provides independent WiFi access, bypassing parental controls or router restrictions.

---

## 🎯 Core Concept

A small "brick" hardware device with:
- USB-C connectivity (USB 3.0 for networking)
- Built-in WiFi radio (2.4GHz + 5GHz ideally)
- OpenWrt or similar embedded OS
- Accessible via host computer's terminal/software

## 🔧 Technical Requirements

### Hardware Components Needed
| Component | Purpose | Notes |
|-----------|---------|-------|
| Raspberry Pi Zero 2 W / Zero 2 | Embedded Linux, WiFi hotspot | Has USB-C power, ~$15-20 |
| OR: ESP32-WROOM + external antenna | Low-power option, more complex OS setup | Cheaper (~$8-10) |
| USB-C to USB-A OTG cable | Host device → router brick | 1.5A+ current draw |
| Case enclosure | Physical protection | Acrylic or ABS |

### Software Stack
- **OS:** OpenWrt or Alpine Linux (Lighttpd)
- **Network Mode:** Bridge/Hostapd hotspot
- **Security:** WPA3 optional encryption
- **Monitoring:** curl-based CLI dashboard

## ⚠️ Ethical/Legal Note

This project should be used for:
- ✅ Personal privacy (your own networks/devices)
- ✅ Testing network configurations
- ✅ Bypassing *your* router's restrictions if you have admin access
- ❌ NOT for unauthorized access to others' networks
- ❌ NOT for bypassing ISP-imposed blocks

---

## 🚀 Implementation Phases

### Phase 1: Feasibility Research (Current)
- [ ] Survey available USB-C WiFi adapters (Pine64, Raspberry Pi Zero)
- [ ] Check OpenWrt documentation for hotspot setup
- [ ] Analyze existing projects on GitHub

### Phase 2: Prototype Build
- [ ] Acquire hardware components (~$30-50 total)
- [ ] Flash firmware to embedded device
- [ ] Configure as WiFi access point
- [ ] Test connection from host device (phone/computer)

### Phase 3: Integration
- [ ] Build case/enclosure
- [ ] Add status LED
- [ ] Create CLI tools for management
- [ ] Document setup instructions

---

## 🔍 Key Technical Questions to Answer

1. **Can a Raspberry Pi Zero 2 W act as both USB-C client AND WiFi AP?**
   - Yes, via network bridge + hostapd

2. **What are power requirements?**
   - ~500-800mA during operation → USB-C capable of 1.5A+ needed

3. **Can this coexist with existing router restrictions?**
   - Yes, if you have separate authentication (your own WiFi password)

4. **Latency/throughput limits?**
   - Wi-Fi 5: ~50-100 Mbps theoretical → Real-world: ~20-50 Mbps

---

## 📦 Potential Hardware Sources

### Budget Option (~$30-40)
- Raspberry Pi Zero 2 W board + case
- USB-C power cable included
- WiFi already built-in

### All-in-One Solution (~$60-80)
- Pine64 PinePhone (has dev mode)
- Or: Custom-built ESP32 with antenna
- More complex but lower power

---

## 🛡️ Safety & Security Considerations

| Concern | Mitigation |
|---------|------------|
| Unauthorized access | Only use on networks you own/administer |
| ISP restrictions | Not for bypassing paid service limits |
| Network isolation | Disable bridging if not needed |
| Power safety | Proper USB-C PD negotiation |

---

## 📝 Next Steps & Decisions Needed

1. **Which hardware path?** (Pi Zero 2 W vs ESP32)
   - Pros of Pi: Mature OS, good community support
   - Pros of ESP32: Cheaper, lower power

2. **Enclosure design:**
   - Buy pre-made case (~$5-10)
   - 3D print custom case (if you have access)
   - Acrylic cut-to-size

3. **Project timeline:**
   - Phase 1: 1-2 weeks research
   - Phase 2: 1 week build & test
   - Phase 3: 1 week enclosure/docs

---

## 🔗 Related Projects

- See also: [[projects/networking/Bypass-Parental-Controls]]
- See also: [[projects/hardware/Raspberry-Pi-Zero]]

---

**Last Updated:** 2026-06-XX  
**Project Owner:** kkhangaroo  
**Location:** EverVault projects/hardware-projects/
