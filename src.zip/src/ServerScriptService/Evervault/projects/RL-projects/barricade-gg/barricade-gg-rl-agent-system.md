# 🎮 RL Barricade.gg Agent System

## Overview
Reinforcement learning agent for playing [Barricade.gg](https://barricade.gg) - a strategic board game where players race to reach the other side while blocking opponents without trapping themselves.

---

## 📐 Game Mechanics Recap
- **Objective**: Reach the opposite side of the board first
- **Actions per turn**: Move 1 tile forward OR place barricade OR attack opponent
- **Barricades**: Block movement paths, risk of self-trap
- **Risk**: Blocking yourself = immediate loss

---

## 🏗️ Agent Architecture

### State Representation (Observation)
```python
state = {
    'board': screenshot + DOM_state,      # Visual + DOM analysis
    'my_position': int,                    # Current tile index
    'opponent_positions': [int, None],     # Opponent tiles if visible
    'barricades': [(tile_idx, owner)],     # Barricade placement map
    'game_phase': 'early/mid/late',        # Board occupancy ratio
    'risk_score': float,                   # Distance from safe zones
    'turn': int                            # Current turn number
}
```

**State Capture Methods**:
1. **Screenshot analysis** (Vision model): Detect board layout, piece positions, barricades
2. **DOM inspection**: Parse game state variables if exposed in HTML
3. **Hybrid approach**: Vision + DOM for robustness

---

### Action Space
- **MOVE_FORWARD**: Move 1 tile towards goal
- **PLACE_BARRICADE**: Place barricade on target tile
- **ATTACK_OPPOONENT**: Attack opponent's piece (if visible)
- **WAIT**: Pass turn (only if advantageous - rarely optimal)

**Action constraints**:
- Can only place barricades where empty and not self-trapping
- Attack requires line-of-sight (no current enemy visibility in game?)
- Turn limit: Must advance eventually to avoid timeout penalty

---

### Reward Function Design
```python
def compute_reward(state, action, outcome):
    # Primary reward: Progress toward goal
    progress_reward = 0.3 * (-1) / state['distance_to_goal']
    
    # Risk aversion: Don't block yourself
    if action == 'PLACE_BARRICADE' and risk_self_trap > 0.7:
        return -2.0  # Heavy penalty for self-trap risk
    
    # Defensive play bonus
    if action == 'PLACE_BARRICADE' and opponent_near:
        return +0.5 * (1 / state['distance_to_opponent'])
    
    # Time pressure
    if turn > 100:
        progress_reward *= 1.2
    
    # Win/Loss terminal rewards
    if outcome == 'WIN': return +100
    elif outcome == 'LOSS': return -100
    
    return reward_sum
```

**Reward components**:
- **+100/−100**: Terminal win/loss
- **Progress**: Encourage forward movement (inversely proportional to distance)
- **Defense**: Bonus for strategic barricade placement against opponents
- **Risk penalties**: Heavy punishment for self-trap situations
- **Time pressure**: Increased progress weighting in late game

---

### RL Algorithm Options

#### Option A: PPO (Prefered initially)
```python
from stable_baselines3 import PPO

# State encoding: Pixel-based CNN or Transformer on screen crops
# Action: Discrete action space [0:move, 1:barricade, 2:attack]
agent = PPO(
    "CnnPolicy",           # Or MlpPolicy if DOM-only state available
    env=CustomBarricadeEnv(),
    verbose=1,
    n_steps=128,           # Small timesteps for responsive gameplay
    batch_size=64,
    n_epochs=10,
    learning_rate=3e-4,    # Standard PPO rate
)
```

#### Option B: Custom Actor-Critic with Vision Encoder
```python
# CNN backbone → State encoder → Actor head + Critic head
# Can leverage existing vision models for state representation
class BarricadeActorCritic(nn.Module):
    def __init__(self, img_size=(128, 128)):
        self.vision_encoder = ViT(patch_size=16, img_size=img_size)
        self.actor = nn.Linear(512, 3)      # Output action probs
        self.critic = nn.Linear(512, 1)     # Value estimation
    
    def forward(self, image):
        features = self.vision_encoder(image)
        actions = F.softmax(self.actor(features), dim=-1)
        value = torch.sigmoid(self.critic(features))
        return actions, value
```

---

## 🔄 Training Pipeline

### Offline Training Phase
1. **Environment simulation** (playground without live game):
   - Pre-recorded Barricade.gg sessions or rule-based simulator
   - Generate synthetic training data with varied game states
2. **Initial policy learning**: 10,000–50,000 timesteps
3. **Evaluate**: Test against baseline opponent

### Online Learning Phase (Test Run)
```python
def train_online(episodes=100):
    agent = load_pretrained_policy()  # From offline phase
    
    for ep in range(episodes):
        state, done = reset_game(), False
        total_reward = 0
        
        while not done:
            # Capture current state (screenshot + DOM)
            observation = capture_state()
            
            # Get action from agent (test mode or training mode)
            if MODE == 'TRAINING':
                action, _ = agent.predict(observation)  # Sample from policy
                record_transition(observation, action, reward, state)
            else:
                action = select_best_action(agent, observation)  # Greedy
            
            # Execute action via browser
            execute_action(action)
            
            # Update state after game tick
            new_state, reward, done = observe_game_update()
            
            # Experience replay (if using DQN-style) or store for PPO batch
            replay_buffer.add(observation, action, reward, new_state, done)
            
            total_reward += reward
        
        # After episode: update model if using online RL
        if MODE == 'TRAINING':
            agent.update(replay_buffer.sample_batch())
        
        # Log metrics
        log_episode(ep, total_reward)
```

**Key considerations**:
- **State reset frequency**: Barricade.gg may require manual restart
- **Tool call overhead**: ~30–60 seconds per move affects learning rate
- **Training vs. testing toggle**: Need to switch between exploration and exploitation modes
- **Risk of losing real rating**: Should train in private/custom rooms

---

## 🔬 Learning Strategies

### 1. Progressive Overfitting
```python
# Start with low state dimensionality (simple features)
# Gradually increase complexity as model improves
complexity_schedule = [
    'minimal',   # Turn + position only (first 50 episodes)
    'moderate',  # Add barricade count (episodes 50–200)
    'full'       # Complete vision + DOM state (after episode 200)
]
```

### 2. Curriculum Learning
- **Early**: Train against weak/bot opponents
- **Mid**: Increase difficulty gradually
- **Late**: Competitive play with skilled humans/advanced bots

### 3. Risk-Sensitive Training
- Weight high-risk situations differently during training
- Encourage defensive play in early phases
- Allow more aggressive tactics as evaluation improves

---

## 🛠️ Implementation Components

### 1. State Capture Module
```python
# Uses Hermes browser tools to:
# - Take screenshot (for vision model)
# - Parse DOM elements for game state
# - Extract turn counter, positions if exposed in HTML
class BarricadeStateCapturer:
    def capture(self):
        screenshot = browser_get_images()  # Or use custom screenshot tool
        dom_state = browser_console(expression='document.body.innerText')
        return combine_visual_and_dom(screenshot, dom_state)
```

### 2. Action Executor
```python
class BarricadeActionExecutor:
    def move_forward(self):
        # Find and click "next tile" or press corresponding key
        pass
    
    def place_barricade(self, target_tile):
        # Navigate to target location and interact with barricade placement UI
        pass
    
    def attack_opponent(self):
        # Use attack command if available in current UI
        pass
```

### 3. Training Logger & Metrics
```python
# Track:
# - Win/loss ratio over time
# - Average progress per episode (tiles gained)
# - Risk-taking metrics (barricades placed vs. survived)
# - Exploration rate decay
from stable_baselines3.common.monitor import Monitor
logger = Monitor('./barricade_training_logs/')
```

### 4. Integration with EverVault Brain
```python
# Document learning progress in Obsidian:
def log_to_brain(epoch, metrics):
    # Write to brain/training-log/RL-Barricade-Progress.md
    # Include screenshots of key game moments
    # Link to specific analysis of strategy evolution
    pass

# Create visualizations:
- Learning curves (win rate vs. episode)
- Strategy heatmap (what actions taken in which situations)
- Risk-vs-reward tradeoff plots
```

---

## 🎯 Evaluation Metrics

| Metric | Target (Early) | Target (Mid) | Target (Late) |
|--------|---------------|--------------|---------------|
| Win Rate | 10–30% | 40–60% | 70%+ |
| Avg. Progress/Turn | 0.8 tiles | 1.2 tiles | 1.5 tiles |
| Self-Trap Rate | < 5% | < 2% | < 0.5% |
| Barricade Placement Efficiency | 30% of actions | 60% of actions | 75%+ of actions |

---

## 🚀 Quick Start Commands

```bash
# Create training environment
mkdir -p ~/Documents/Obsidian\ Vault/brain/training/barricade-gg

# Initial state capture test (test run)
python scripts/capture_barricade_state.py --mode=test

# Train offline model first
python train_offline.py --episodes 50 --simulator=rule-based

# Online training toggle switch
export BARRICADE_MODE=TRAINING    # or TRAINING, TEST, EVALUATION

# Full test run sequence (what we're about to do now)
python scripts/barricade_test_run.py --mode=training --episodes 3
```

---

## ⚠️ Important Considerations

### Tool Call Latency
- Each move = ~30–60 seconds of tool calls + model inference
- Training will require patience and batching
- Consider parallel browser instances for speed (if feasible)

### Game Mechanics Complexity
- Barricade.gg has subtle mechanics:
  - Timing windows for barricades
  - Risk calculation based on board occupancy
  - Potential hidden opponent information
- Initial training may struggle with these nuances

### Reward Sparsity Problem
- Win/loss only at end = sparse rewards
- May need shaping rewards (intermediate objectives)
- Consider: small bonuses for surviving long boards, or reaching certain milestones

---

## 📊 Project Roadmap

### Phase 1: Basic RL Agent (Current Work)
- ✅ State capture via browser tools
- ⏳ Action execution pipeline
- ⏳ Basic PPO training loop
- ⏳ Test run on live game

### Phase 2: Advanced Features
- Vision model integration for state encoding
- Opponent modeling (learn opponent patterns)
- Defensive vs. aggressive mode switching

### Phase 3: Optimization & Scaling
- Distributed training across multiple browser instances
- Transfer learning from easier games
- Ensemble methods for action prediction

---

## 🔗 Integration Points with Hermes Agent

```python
# Current tool call chain:
barricade_navigation → state_capture (browser_snapshot/console) → 
RL_agent_action → barricade_execution (browser_click/press) → 
game_state_update (browser_snapshot again) → replay_buffer.add()

# Future enhancements:
- Custom browser automation for faster state capture
- Vision model preprocessing for state encoding
- Training metrics visualization in real-time
```

---

## 📚 Relevant EverVault Resources

- [[USING-EVERVAULT-TO-FULLEST-POTENTIAL]] - Brain system guide
- [[projects/evervault-mastery]] - Project progression path
- `brain/training/barricade-gg/logs/` - Training runs and metrics
- `brain/training/barricade-gg/models/` - Trained policy checkpoints

---

## 🧪 Current Test Run Goals

For our immediate test run:
1. **Explore game mechanics** via tool interactions
2. **Capture state examples** for model input format
3. **Define action mappings** (UI element → game action)
4. **Establish baseline performance** (how well can the agent play initially?)
5. **Identify challenges** (state capture quality, action precision, timing issues)

### Test Run Procedure
```
1. Navigate to barricade.gg (already done ✅)
2. Create room/enter existing game if possible
3. Capture initial board state via browser tools
4. Demonstrate 1–2 move actions with AI decision-making
5. Document limitations discovered during test
6. Refine architecture based on findings
```

---

## 📝 Notes & TODOs

- [ ] Check if barricade.gg has an API for easier state access
- [ ] Investigate available game rules (can you attack? move multiple tiles?)
- [ ] Test screenshot capture quality from current page
- [ ] Define exact action space from actual UI (move forward, place barricade buttons)
- [ ] Consider using LM Studio for reward modeling + policy extraction
- [ ] Set up automated logging to EverVault brain

---

*Last updated: June 2026*  
*Status: Prototype phase - test run pending*
