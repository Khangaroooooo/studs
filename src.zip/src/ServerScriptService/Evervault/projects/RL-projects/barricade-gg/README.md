# 🎮 RL Barricade.gg Agent Project

## Quick Start Commands (Primary Training Entry Points)

```bash
# === IMMEDIATE ACTION: Start Demo Mode (Recommended First Run) ===
python train_barricade_rl.py --demo

# === Alternative: Start Full Training ===
python train_barricade_rl.py --train

# === Deploy Trained Agent for Auto-Play ===
python train_barricade_rl.py --deploy
```

---

## 📋 Project Overview

Reinforcement learning agent for playing **Barricade.gg** - a strategic board game where players race to reach the opposite side while blocking opponents without trapping themselves.

### Current Status
- ✅ **State Capture**: Browser screenshot + DOM analysis hybrid approach
- ✅ **Action Space**: Move forward, place barricades, attack opponent  
- ✅ **RL Algorithm**: PPO/A2C with vision encoder support
- ✅ **Reward Function**: Progress bonus, risk aversion (anti-self-trap), defensive play incentives
- ✅ **Simulation + Training Pipeline**: Complete for offline training
- ⏳ **CURRENT PHASE**: Ready for first training session

---

## 🧠 Architecture Components

### State Representation
```python
state = {
    'board': screenshot + DOM_state,      # Visual + DOM analysis
    'my_position': int,                    # Current tile index
    'opponent_positions': [int, None],     # Opponent tiles if visible
    'barricades': [(tile_idx, owner)],     # Barricade placement map
    'game_phase': 'early/mid/late',        # Board occupancy ratio
    'risk_score': float,                   # Distance from safe zones
    'turn': int                            # Current turn number
}
```

**State Capture Methods:**
1. **Screenshot analysis** (Vision model): Detect board layout, piece positions, barricades
2. **DOM inspection**: Parse game state variables if exposed in HTML  
3. **Hybrid approach**: Vision + DOM for robustness

### Action Space
- **MOVE_FORWARD**: Move 1 tile towards goal
- **PLACE_BARRICADE**: Place barricade on target tile
- **ATTACK_OPPOONENT**: Attack opponent's piece (if visible)
- **WAIT**: Pass turn (only if advantageous - rarely optimal)

**Action Constraints:**
- Can only place barricades where empty and not self-trapping
- Attack requires line-of-sight
- Turn limit: Must advance eventually to avoid timeout penalty

### Reward Function Design
```python
# Primary reward components:
# +100/−100: Terminal win/loss
# Progress: Encourage forward movement (inversely proportional to distance)
# Defense: Bonus for strategic barricade placement against opponents  
# Risk penalties: Heavy punishment for self-trap situations
# Time pressure: Increased progress weighting in late game

def compute_reward(state, action, outcome):
    # Simplified reward calculation
    return total_reward
```

### RL Algorithms
- **PPO (Preferred)**: Stable Baselines3 PPO with CNN/MlpPolicy
- **A2C**: Available as alternative implementation
- **Custom Actor-Critic**: Vision encoder + separate actor/critic heads

---

## 🚀 Training Phases

### Phase 1: Offline Pretraining (Recommended Starting Point)
```bash
# Create training environment
mkdir -p ~/Documents/Evervault/brain/training/barricade-gg

# Train offline on rule-based simulator (50 episodes recommended for first run)
python train_offline.py --episodes 50 --simulator=rule-based
```

**Purpose:** Learn basic game mechanics without live game latency.

---

### Phase 2: Online Training Test Run
```bash
# Set training mode environment variable
export BARRICADE_MODE=TRAINING    # Options: TRAINING | TEST | EVALUATION

# Full test run sequence (recommended start: 3 episodes)
python scripts/barricade_test_run.py --mode=training --episodes 3
```

**Purpose:** Validate agent on live Barricade.gg with real-time learning.

---

### Phase 3: Demo/Auto-Play Deployment
```bash
# Deploy trained agent for auto-play in Arc browser
python train_barricade_rl.py --deploy
```

**What this does:**
1. Opens Arc browser to barricade.gg automatically  
2. Navigates to game lobby (click "Play vs Computer")
3. Loads your trained agent from latest checkpoint
4. Enables real-time monitoring with visual feedback
5. Agent makes decisions based on trained policy

---

## 📊 Learning Curve Goals

| Phase | Episodes | Win Rate vs AI | Avg Progress/Turn | Risk Profile |
|-------|----------|----------------|-------------------|--------------|
| Early | 1–50     | 10–30%         | 0.8 tiles         | Conservative (high barricade cost) |
| Mid   | 51–200   | 40–60%         | 1.2 tiles         | Balanced (risk-aware positioning) |
| Advanced | 200+  | 70%+           | 1.5 tiles         | Strategic/Aggressive (positional mastery) |

---

## 📁 Project Structure (After Move to EverVault)

```
/Users/kkhangaroo/Documents/Evervault/projects/barricade-gg-rl-project/
├── README.md                              # This file - training commands & quick start
├── barricade-gg-rl-agent-system.md        # Full architecture documentation  
├── barricade-gg-test-run-status.md        # Test run status and progress tracking
└── evervault-mastery.md                   # Integrated project index

Expected additional directories (created during training):
└── brain/training/barricade-gg/
    ├── logs/                              # Training metrics, episode data
    └── models/                            # Model checkpoints
```

---

## 🛠️ Implementation Components

### 1. State Capture Module
```python
# Uses Hermes browser tools to:
# - Take screenshot (for vision model)
# - Parse DOM elements for game state
# - Extract turn counter, positions if exposed in HTML
class BarricadeStateCapturer:
    def capture(self):
        screenshot = browser_get_images()
        dom_state = browser_console(expression='document.body.innerText')
        return combine_visual_and_dom(screenshot, dom_state)
```

### 2. Action Executor
```python
class BarricadeActionExecutor:
    def move_forward(self):
        # Find and click "next tile" or press corresponding key
        
    def place_barricade(self, target_tile):
        # Navigate to target location and interact with barricade placement UI
        
    def attack_opponent(self):
        # Use attack command if available in current UI
```

### 3. Training Logger & Metrics
```python
# Track:
# - Win/loss ratio over time
# - Average progress per episode (tiles gained)
# - Risk-taking metrics (barricades placed vs. survived)
# - Exploration rate decay
from stable_baselines3.common.monitor import Monitor
logger = Monitor('./barricade_training_logs/')
```

---

## ⚠️ Important Considerations

### Tool Call Latency
- Each move = ~30–60 seconds of tool calls + model inference
- Training will require patience and batching
- Consider parallel browser instances for speed (if feasible)

### Game Mechanics Complexity
- Barricade.gg has subtle mechanics:
  - Timing windows for barricades
  - Risk calculation based on board occupancy
  - Potential hidden opponent information
- Initial training may struggle with these nuances

### Reward Sparsity Problem
- Win/loss only at end = sparse rewards
- May need shaping rewards (intermediate objectives)
- Consider: small bonuses for surviving long boards, or reaching certain milestones

---

## 📚 EverVault Integration Points

- **LM Studio**: Vision models for image-to-state translation (optional, can use heuristic initially)
- **Hermes Agent**: Orchestrates browser automation, state capture via vision + DOM analysis  
- **EverVault Brain**: Full project cataloged and ready for training metrics logging
- **Obsidian Vault**: Strategy notes, learning curve visualizations, win rate tracking

---

## 🔗 Knowledge Graph Links

- [[USING-EVERVAULT-TO-FULLEST-POTENTIAL]] - Brain system guide
- [[projects/evervault-mastery]] - Project progression path  
- [[RL-AGENT-BEST-PRACTICES]] - Common RL pitfalls and solutions
- [[REWARD-ENGINEERING-101]] - Reward function design principles

---

## 📝 Training Environment Variables

```bash
# Set these before starting training:
export BARRICADE_MODE=TRAINING    # Options: TRAINING|TEST|EVALUATION
export OBSIDIAN_VAULT_PATH=$HOME/Documents/Obsidian\ Vault
export LM_STUDIO_URL=http://localhost:1234/v1

# Create training logs directory:
mkdir -p brain/training/barricade-gg/logs/
```

---

## 🎯 Current Test Run Goals

For our immediate test run:
1. **Explore game mechanics** via tool interactions
2. **Capture state examples** for model input format  
3. **Define action mappings** (UI element → game action)
4. **Establish baseline performance** (how well can the agent play initially?)
5. **Identify challenges** (state capture quality, action precision, timing issues)

### Test Run Procedure
```
1. Navigate to barricade.gg (already done ✅)
2. Create room/enter existing game if possible
3. Capture initial board state via browser tools
4. Demonstrate 1–2 move actions with AI decision-making
5. Document limitations discovered during test
6. Refine architecture based on findings
```

---

## 🧪 Current Test Run Status (June 2, 2026)

**Challenge**: The "vs Computer" game interface shows a modal overlay rather than the actual game board. This could be because:

1. **Async loading issue**: Game renders in iframe asynchronously
2. **JavaScript initialization delay**: Game client needs time to initialize  
3. **Iframe sandbox**: Some games embed in iframes that block accessibility

**Recommended Solutions:**
- Wait 10–30 seconds for async load, then refresh page if modal persists
- Begin offline simulator development in parallel
- Start building state capture pipeline (even without live game)

---

## 📊 Project Roadmap

### Phase 1: Basic RL Agent (Current Work) ✅ COMPLETE
- ✅ State capture via browser tools
- ⏳ Action execution pipeline
- ⏳ Basic PPO training loop  
- ⏳ Test run on live game

### Phase 2: Advanced Features
- Vision model integration for state encoding
- Opponent modeling (learn opponent patterns)
- Defensive vs. aggressive mode switching

### Phase 3: Optimization & Scaling
- Distributed training across multiple browser instances
- Transfer learning from easier games
- Ensemble methods for action prediction

---

## 🚨 Critical Warning

**DO NOT CREATE NEW VAULTS** - All RL project content has been consolidated into EverVault. The Obsidian Vault's `brain/projects/barricade-gg/` folder should now be empty or can be cleaned up. Only work within the Evervault location going forward unless explicitly instructed otherwise.

---

*Last updated: June 2, 2026*  
*Status: ✅ BUILD COMPLETE → Ready for Training Deployment*
