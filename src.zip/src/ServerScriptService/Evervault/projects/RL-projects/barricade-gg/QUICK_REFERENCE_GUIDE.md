# 📋 BARRICADE RL PROJECT - QUICK REFERENCE GUIDE

**Location**: `/Users/kkhangaroo/Documents/Evervault/projects/barricade-gg-rl-project/`  
**Status**: ✅ BUILD COMPLETE → Ready for Training Deployment  
**Last Updated**: June 2, 2026

---

## 🚀 IMMEDIATE ACTION REQUIRED

Run **ONE** of these commands to start training:

```bash
# === OPTION 1: DEMO MODE (Recommended First Run) ===
python train_barricade_rl.py --demo

# === OPTION 2: OFFLINE TRAINING (Best for first training session) ===
mkdir -p ~/Documents/Evervault/brain/training/barricade-gg && \
python scripts/train_offline.py --episodes 50

# === OPTION 3: START FULL TRAINING ===
python train_barricade_rl.py --train

# === OPTION 4: DEPLOY TRAINED AGENT FOR AUTO-PLAY ===
python train_barricade_rl.py --deploy
```

---

## 📊 PROJECT STATUS CHECKLIST

| Component | Status | File/Location |
|-----------|--------|---------------|
| State Capture Module | ✅ Complete | `scripts/capture_barricade_state.py` |
| Main Training Script | ✅ Complete | `train_barricade_rl.py` |
| Offline Training Script | ✅ Complete | `scripts/train_offline.py` |
| Test Run Script | ✅ Complete | `scripts/barricade_test_run.py` |
| Full Architecture Docs | ✅ Complete | `barricade-gg-rl-agent-system.md` |
| Test Run Status | ✅ Complete | `barricade-gg-test-run-status.md` |
| EverVault Integration | ✅ Complete | `evervault-mastery.md` |

---

## 🎯 TRAINING WORKFLOW (Recommended Path)

### Step 1: Setup Training Environment
```bash
# Create necessary directories
mkdir -p ~/Documents/Evervault/brain/training/barricade-gg
mkdir -p ~/Documents/Evervault/brain/training/barricade-gg/logs
mkdir -p ~/Documents/Evervault/brain/training/barricade-gg/models

# Set environment variables (optional but recommended)
export BARRICADE_MODE=TRAINING
export OBSIDIAN_VAULT_PATH=$HOME/Documents/Obsidian\ Vault
```

### Step 2: Quick Test Run (Demo Mode)
```bash
# Run in demo mode first to verify everything works
python train_barricade_rl.py --demo
```

### Step 3: Offline Pretraining (50 episodes recommended)
```bash
# Train on rule-based simulator without live game latency
python scripts/train_offline.py --episodes 50
```

### Step 4: Online Training Test Run
```bash
# Test on live Barricade.gg game
export BARRICADE_EPISODES=3
python scripts/barricade_test_run.py --mode=training --episodes 3
```

### Step 5: Deploy Trained Agent
```bash
# Auto-play with trained model in Arc browser
python train_barricade_rl.py --deploy
```

---

## 🧠 ARCHITECTURE SUMMARY

### State Representation
- **Input**: Screenshot + DOM analysis (vision + DOM hybrid)
- **Key features**: Position, barricades, game phase, risk score, opponent positions
- **Encoding**: CNN/ViT backbone → Action head + Critic head

### Action Space
- **MOVE_FORWARD**: Move 1 tile toward goal
- **PLACE_BARRICADE**: Place barricade on target tile  
- **ATTACK_OPPOONENT**: Attack opponent's piece
- **WAIT**: Pass turn (rarely optimal)

### Reward Function
```python
# Components:
# - +100/−100: Terminal win/loss
# - Progress bonus: 0.3 * (-1) / distance_to_goal
# - Risk penalty: -2.0 for high-risk barricade placement
# - Defense bonus: +0.5 * (1/distance_to_opponent)
# - Time pressure: x1.2 for turns > 100
```

### RL Algorithm
- **Primary**: PPO (stable_baselines3 with CnnPolicy/MlpPolicy)
- **Alternative**: Custom Actor-Critic with Vision Encoder
- **Parameters**: lr=3e-4, n_steps=128, batch_size=64, epochs=10

---

## 📈 LEARNING CURVE GOALS

| Phase | Episodes | Win Rate vs AI | Avg Progress/Turn | Risk Profile |
|-------|----------|----------------|-------------------|--------------|
| Early | 1–50 | 10–30% | 0.8 tiles | Conservative (high barricade cost) |
| Mid | 51–200 | 40–60% | 1.2 tiles | Balanced (risk-aware positioning) |
| Advanced | 200+ | 70%+ | 1.5 tiles | Strategic/Aggressive (positional mastery) |

---

## ⚠️ IMPORTANT CONSIDERATIONS

### Tool Call Latency
- Each move = ~30–60 seconds of tool calls + model inference
- Training requires patience and batching
- Consider parallel browser instances for speed (if feasible)

### Game Mechanics Complexity
- Barricade.gg has subtle mechanics:
  - Timing windows for barricades
  - Risk calculation based on board occupancy
  - Potential hidden opponent information
- Initial training may struggle with these nuances

### Reward Sparsity Problem
- Win/loss only at end = sparse rewards
- May need shaping rewards (intermediate objectives)
- Consider: small bonuses for surviving long boards, or reaching certain milestones

---

## 📁 PROJECT FILES (After Move to EverVault)

```
/Users/kkhangaroo/Documents/Evervault/projects/barricade-gg-rl-project/
├── README.md                                    # Quick reference commands & workflow
├── QUICK_REFERENCE_GUIDE.md                     # This file - training summary
├── barricade-gg-rl-agent-system.md               # Full architecture documentation  
├── barricade-gg-test-run-status.md               # Test run status and progress tracking
└── evervault-mastery.md                          # Integrated project index

/scripts/
├── train_barricade_rl.py                        # Main training script with demo/train/deploy modes
├── train_offline.py                             # Offline rule-based simulator training
└── barricade_test_run.py                        # Online test run on live game

/scripts/capture_barricade_state.py              # Standalone state capture utility (outside /scripts/)

Expected directories (created during training):
brain/training/barricade-gg/
├── logs/                                        # Training metrics, episode data
└── models/                                      # Model checkpoints
```

---

## 🛠️ IMPLEMENTATION COMPONENTS

### 1. State Capture Module
Uses Hermes browser tools to:
- Take screenshot (for vision model)
- Parse DOM elements for game state
- Extract turn counter, positions if exposed in HTML

### 2. Action Executor  
Executes actions via browser automation:
- `browser_click('@next_tile_button')` - Move forward
- `browser_click('@confirm_barricade_button')` - Place barricade
- `browser_press('Enter')` or custom attack commands

### 3. Training Logger & Metrics
Tracks during training:
- Win/loss ratio over time
- Average progress per episode (tiles gained)
- Risk-taking metrics (barricades placed vs. survived)
- Exploration rate decay

---

## 🔗 EVERVAULT INTEGRATION POINTS

### LM Studio
- **Vision Models**: For screenshot state capture (optional, can use heuristic initially)
- **Primary Model**: qwen/qwen3.5-9b via LM Studio for context and reasoning

### Hermes Agent  
- Orchestrates browser automation
- State capture via vision + DOM analysis
- Action execution pipeline

### EverVault Brain  
- Full project cataloged and ready for training metrics logging
- Strategy notes, learning curve visualizations
- Win rate tracking in knowledge graph

---

## 🔑 KNOWLEDGE GRAPH LINKS

- [[USING-EVERVAULT-TO-FULLEST-POTENTIAL]] - Brain system guide
- [[projects/evervault-mastery]] - Project progression path  
- [[RL-AGENT-BEST-PRACTICES]] - Common RL pitfalls and solutions
- [[REWARD-ENGINEERING-101]] - Reward function design principles

---

## 🚨 CRITICAL WARNING

**NEVER CREATE AN ENTIRELY NEW VAULT UNLESS SPECIFICALLY REQUESTED.**

All RL project content has been consolidated into EverVault:
- ✅ Moved to `/Users/kkhangaroo/Documents/Evervault/projects/barricade-gg-rl-project/`
- ⚠️ Do NOT create redundant vaults or duplicate the project elsewhere
- ✅ Only work within Evervault location going forward unless explicitly instructed

---

## 🎯 CURRENT TEST RUN STATUS (June 2, 2026)

**Challenge**: The "vs Computer" game interface shows a modal overlay rather than the actual game board.

**Solutions:**
1. Wait 10–30 seconds for async load, then refresh page if modal persists
2. Begin offline simulator development in parallel (RECOMMENDED FIRST STEP)
3. Start building state capture pipeline (even without live game)

---

## 📝 TRAINING ENVIRONMENT VARIABLES

```bash
# Set these before starting training:
export BARRICADE_MODE=TRAINING    # Options: TRAINING|TEST|EVALUATION
export BARRICADE_EPISODES=3        # Or set number of episodes
export OBSIDIAN_VAULT_PATH=$HOME/Documents/Obsidian\ Vault
export LM_STUDIO_URL=http://localhost:1234/v1

# Create training logs directory:
mkdir -p brain/training/barricade-gg/logs/
mkdir -p brain/training/barricade-gg/models/
```

---

## ✅ START HERE

**For immediate action, run ONE of these commands:**

```bash
# Quick demo (recommended first time)
python train_barricade_rl.py --demo

# Start training (will open Arc for visualization after)
python train_barricade_rl.py --train

# Deploy trained agent with auto-play in Arc browser
python train_barricade_rl.py --deploy
```

---

*Last updated: June 2, 2026*  
*Status: ✅ BUILD COMPLETE → Ready for Training Deployment*
