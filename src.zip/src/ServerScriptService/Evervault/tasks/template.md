# Task Template - Use This for New Tasks

```markdown
---
title: Action item with clear verb
category: research | write | learn | organize | experiment  
priority: low | medium | high
session-created: YYYY-MM-DD
status: new | in-progress | blocked | done
related-to: [[core/memory.md]]
related-project: [[project-name-if-any]]
---

## What to Do

[Clear, action-oriented description]

## Why This Matters

[Connects to... link related note]

## Related Knowledge

- [[concept-that-helps]]
- [[resource-needed]]

## Progress Notes

### Day 1 (YYYY-MM-DD)
- Started working on it
- Key insight: ...

### Day 2 (YYYY-MM-DD)  
- Made progress on...
- Blocked by...

## Next Action Items

[ ] Immediate next step
[ ] Research X more
[ ] Experiment with Y

## Related Files

- [[learning-note-needed]]
- [[project-if-relevant]]

---

*Mark complete by moving to `system/completed-tasks/` or closing in task tracker*  
*See: [[brain/core/memory.md]] for main memory hub*
```
