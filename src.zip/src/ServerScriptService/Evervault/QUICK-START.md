# 🚀 Quick Start - Your EverVault Brain is Ready!

## Welcome! Read This First (2 minutes)

Your PC brain has been rebuilt from scratch. Here's what you need to do **right now**:

---

## ⚡ 3-Minute Setup

### Step 1: Open Core Memory
Open Obsidian and go to: `brain/core/memory.md`

This is your **main hub** - it shows your persistent knowledge state. Read through it!

### Step 2: Fill Personal Info (CRITICAL!) ⚠️
These files MUST be filled in and persisted with memory tool:

1. **Name**: Open `brain/personal-info/name.md`  
   → Put your real name(s) or aliases
   → **USE MEMORY TOOL** to persist!

2. **Occupation**: Open `brain/personal-info/occupation.md`  
   → Describe your work/profession
   → **USE MEMORY TOOL** to persist!

3. **Location**: Open `brain/personal-info/location.md`  
   → City, timezone, base location
   → **USE MEMORY TOOL** to persist!

4. **Tools & Env**: Open `brain/personal-info/tools-and-env.md`  
   → List your tech stack (MacOS, Arc browser, LM Studio, etc.)
   → **USE MEMORY TOOL** to persist!

### Step 3: Learn Memory Tool
Open and read: `system/memory-tool-guide.md`

This explains the most important part - how facts survive across sessions!

---

## 🎯 Your Brain Structure (One-Liner Summary)

```
brain/core/        ← Persistent memory (USE MEMORY TOOL!)
brain/personal-info/  ← Your identity (USE MEMORY TOOL!)
brain/learning/     ← New discoveries
brain/memories/     ← Events and experiences  
brain/context/      ← Temporary context (clean often!)
projects/           ← Active work
tasks/              ← Action items
```

---

## 🧠 Key Rule: Use Memory Tool!

**For personal info and important facts, ALWAYS use the memory tool:**

```python
from hermes_tools import read_file, memory

# After filling a personal info file:
content = read_file(path="brain/personal-info/name.md").content  
memory(action="add", target="user", content=content)
```

**This makes facts survive across sessions!** Obsidian files alone don't persist.

---

## 📅 Daily Routine

### Start Session:
- [ ] Read `[[core/memory.md]]` - Your knowledge state
- [ ] Check `tasks/` - Pending action items
- [ ] Scan `projects/` - Ongoing work

### During Work:
- New learning? → Add to `learning/notes/` + link to existing knowledge
- Important facts? → Create fact file + **use memory tool**!
- Events happening? → Document in `memories/`  
- Working on project? → Track in `projects/`

### End Session:
- [ ] Update `[[core/memory.md]]` with highlights
- [ ] Create session log in `system/session-notes/`
- [ ] Clean up `brain/context/` - archive or delete temp files

---

## 🧪 First Learning Exercise (5 minutes)

Document what you learned just by setting up this brain:

1. Open Obsidian → New file: `learning/notes/everyvault-initial-setup.md`
2. Use template: Click on [[learning/note-template]] to see it  
3. Fill in:
   - What is EverVault? (AI knowledge base with persistence)
   - What did I learn about the memory tool? (Critical for facts!)
   - Key insights from this setup session

This practice connects your new learning to existing knowledge!

---

## 📖 Essential Reading (Do These First)

In order:
1. ✅ `brain/core/memory.md` - Main hub (3 min read)
2. ✅ `system/memory-tool-guide.md` - How facts persist (5 min read)  
3. ✅ `brain/.getting-started.md` - Complete guide (10 min read)
4. ✅ Fill your personal info files (15 min + memory tool usage)

---

## ⚠️ Common Mistakes to Avoid

❌ **Don't**: Rely only on Obsidian files for persistence  
✅ **Do**: Use memory tool for all personal facts and important knowledge

❌ **Don't**: Forget to link new notes to `[[core/memory.md]]`  
✅ **Do**: Every brain note links to at least 2 other notes

❌ **Don't**: Let `brain/context/` grow unbounded  
✅ **Do**: Clean up context folder every session end

---

## 🎉 You're Ready!

Your brain system is complete with:
- ✅ Full folder structure (4 main folders + subfolders)
- ✅ Persistent memory system with core hub
- ✅ Personal info templates filled and ready
- ✅ Learning notes system with templates
- ✅ Project and task management
- ✅ Session logging infrastructure  
- ✅ Memory tool integration guide
- ✅ Getting started guide
- ✅ Connection/architecture documentation
- ✅ End-of-session checklist

**Next step**: Fill in your personal info files using memory tool!

---

*Created: 2026-06-01*  
*Brain version: 1.0 (complete rebuild from scratch)*

🧠 **Your brain is ready to grow!**
