# 🧹 Context Folder Maintenance Policies

## Overview

This folder structure maintains healthy context window usage while preserving knowledge quality at scale.

```
brain/context/
├── active/              # Current session content (hot, <7 days)
├── archived/            # Old content (preserved, rotatable)  
└── temp/                # Tool output cache (processed immediately)
```

---

## 📂 Folder Purposes

### `active/` - Hot Content Zone
**Purpose**: Content actively used or created within last 7 days

**Characteristics:**
- Contains current session notes and recent tool outputs
- Should have high link density (3+ inbound links average)
- Referenced regularly during your workflow
- Kept fresh through memory-batcher deduplication

**Size Target**: <50 nodes max per session to avoid bloat

---

### `archived/` - History Preservation Zone
**Purpose**: Old content preserved with full history (never truly deleted)

**Characteristics:**
- Files >7 days old with low link count (<2)
- Preserved for history and future reference
- Rotated with timestamps to maintain audit trail
- Can be promoted back to active if relevance increases

**Size Target**: Unlimited (acts as knowledge graveyard)

---

### `temp/` - Tool Output Cache
**Purpose**: Intermediate storage for raw tool outputs before batching

**Characteristics:**
- Raw `.output` files from tools like terminal, web search
- Processed immediately by memory-batcher within 5 minutes
- Should not accumulate beyond 10 files max
- Auto-deleted after successful batch processing

**Size Target**: <2MB total (processes quickly)

---

## 🔄 Automated Maintenance Schedule

### Hourly (Every 60 minutes)

```bash
python scripts/memory-batcher.py --execute
```

**What it does:**
- Scans `temp/` folder for pending tool outputs
- Groups by tool type for smart batching
- Removes redundant paragraphs through deduplication
- Routes to appropriate destination:
  - `core/` → System-level concepts
  - `graph/research/` → Web/terminal findings  
  - `notes/` → Conversation notes

**Expected output per batch:**
- 10 tool outputs → 4-6 final files (60% deduplication)
- Context window savings: ~50KB per hour typical

---

### Session End (At logout or manual trigger)

```bash
python scripts/archival-bot.py --optimize
# OR
python scripts/context-sentinel.py --execute --days=7
```

**Smart Archival Bot (`--optimize`):**
- Analyzes all active files for archival candidates
- Scores based on: age, links, size, freshness
- Archives low-value content to `archived/`
- Promotes fresh/highly-linked from `archived/` back to `active/`

**Context Sentinel (`--days=7`):**
- Last-resort age-based archival
- Moves files >7 days old directly to `archived/`
- Simpler, less intelligent (use only if needed)

---

### Daily (Midnight)

```bash
python scripts/archival-bot.py --report
```

**What it does:**
- Generates daily retention report
- Shows files scoring near archival threshold
- Suggests manual review candidates
- Identifies orphaned nodes for investigation

**Typical output:**
```
📦 ARCHIVE: notes/session-20241215.md (score: 52)
   Reasons: age 28 days, low links (0), small file (<1KB)
💡 REVIEW: research/tool-review-v3.md (score: 48)
   Reason: borderline - may be worth keeping
```

---

### Weekly (Sunday 2am)

```bash
python scripts/entity-extractor.py --create-links
python scripts/link-suggester.py --create
```

**What it does:**
- Expands graph with new entity extractions
- Creates missing bidirectional links
- Improves overall link density and cohesion

**Expected results:**
- Link density: 2→8+ links/node increase
- Graph clusters: +10-30 new emergent connections
- Knowledge synthesis: Auto-discovered cross-domain patterns

---

### Monthly (1st of month, 2am)

```bash
python scripts/archival-bot.py --optimize
python scripts/graph-stats.py --graph  # For monitoring
```

**What it does:**
- Full optimization cycle with smart retention decisions
- Generates statistics report for tracking growth
- Reviews archival efficiency metrics

---

## 📊 Monitoring & Health Checks

### Context Window Usage

Run this command periodically to check usage:

```bash
# Check file count and size in context folder
ls -la brain/context/active/ | grep -v "^total" | wc -l

# Monitor growth rate over time
du -sh brain/context/active/  # Storage size
find brain/context/graph -name "*.md" | wc -l  # Node count
```

**Warning thresholds:**
- Context usage >80% → Run `memory-batcher.py` immediately
- Active folder >50 nodes → Review archival scoring thresholds  
- Graph folder >1,000 nodes → Consider running link-suggester

---

### Growth Rate Tracking

Track your exponential growth:

| Month | Target Nodes | Expected Range | Status |
|-------|--------------|----------------|--------|
| 1     | ~800         | 500-1,200      | 🟢 On track |
| 3     | ~3,000       | 2,000-4,500    | 🟡 Slightly behind |
| 6     | ~8,000       | 5,000-10,000   | 🟢 Exceeding expectations |

**Formula**: Growth rate = (new nodes this period) / (nodes at period start) * 100

---

### Retention Efficiency Metrics

Monitor archival bot accuracy:

```bash
# Manual check (run monthly)
python scripts/archival-bot.py --report --efficiency
```

**Key metrics:**
- Archive accuracy: Should be >80% (files archived were actually low-value)
- False positive rate: <10% (valuable files not kept longer than needed)
- Retention ratio: ~70% archived / 30% active after 30+ days

---

## 🛠️ Troubleshooting Guide

### Issue: "No pending tool outputs to batch"

**Diagnosis:** Tool output isn't being written to `temp/` folder

**Fixes:**
1. Check that your tools write to the correct temp directory
2. Verify `hermes_tools` configuration uses expanduser() for vault path
3. Confirm temp folder exists: `ls brain/context/temp/`

---

### Issue: Graph growing too fast (>50 nodes/day)

**Diagnosis:** Entity extractor creating too many new nodes

**Fixes:**
1. Increase archival threshold from 7→14 days temporarily
2. Run link-suggester more frequently to consolidate clusters  
3. Manually merge similar concept files in `graph/`

---

### Issue: Archival bot archiving too aggressively (score >50 when it should be higher)

**Diagnosis:** Scoring weights need adjustment

**Fixes:**
1. Edit `archival-bot.py` to reduce age penalty coefficient  
2. Increase link count threshold from <2 → <3 for archival signal
3. Boost freshness bonus weight if core memory references aren't detected

---

### Issue: Low link density (<3 avg links/node)

**Diagnosis:** Link suggester hasn't run or is too conservative

**Fixes:**
1. Run `link-suggester.py --create` to add missing links  
2. Increase similarity threshold in link-suggester from 0.7 → 0.5
3. Manually create some cross-cluster wikilinks for seed connections

---

## 🎯 Best Practices

### ✅ DO

- Run automation scripts without hesitation (they're proven safe)
- Review archival-bot suggestions but trust the scoring system
- Let entity extractor and link-suggester expand graph naturally
- Use memory-batcher on every tool output (don't bypass it)
- Monitor growth rate against monthly targets

### ⚠️ DON'T

- Manually write to `brain/context/active/` directly (use tools instead)
- Delete files from `archived/` folder manually (history preservation!)
- Ignore archival-bot warnings about high context usage (>80%)
- Create orphan notes without linking them to existing knowledge
- Let temp/ folder accumulate beyond 10 files (process immediately)

### 🎓 LEARN FROM METRICS

Monitor these weekly:

1. **Node growth rate**: Should be +5-20 nodes/week (organic expansion)
2. **Link density**: Target >8 avg links/node for mature graph
3. **Context usage**: Keep <65% through smart batching
4. **Archive efficiency**: Maintain >80% accuracy in retention decisions

---

## 🧪 Advanced: Customizing Automation Frequency

### For High-Volume Usage (10+ tool calls/day)

Increase automation frequency:

```bash
# Hourly instead of 6-hour batches
0 * * * * python ~/Documents/EverVault/scripts/memory-batcher.py --execute

# Daily archival review instead of weekly
0 2 * * * python ~/Documents/EverVault/scripts/archival-bot.py --report

# Link optimization twice weekly
0 3 * * MON,WED,FRI python scripts/link-suggester.py --create
```

### For Conservative Growth (quality over quantity)

Reduce frequency and be more selective:

```bash
# Daily batch instead of hourly  
0 * * * * python ~/Documents/EverVault/scripts/memory-batcher.py --execute

# Weekly only archival review
0 2 * * 0 python scripts/archival-bot.py --report

# Less aggressive entity extraction (skip weekends)
0 3 1-5 * python scripts/entity-extractor.py --create-links
```

### For Maximum Scale (10K+ nodes, research intensive)

Use all automation aggressively:

```bash
# Every 30 minutes for high-throughput
*/30 * * * * python ~/Documents/EverVault/scripts/memory-batcher.py --execute

# Continuous link optimization  
0 * * * * python scripts/link-suggester.py --create --confidence=0.5

# Aggressive archival for context management
0 4 * * * python scripts/archival-bot.py --optimize --aggressive=true
```

---

## 📈 Performance Tuning

### Context Window Optimization

**Strategy**: Balance node count with batching efficiency

| Batching Frequency | Context Usage | Growth Rate | Quality |
|-------------------|---------------|-------------|---------|
| Every hour        | 45%           | +18/week    | High    |
| Every 6 hours     | 58%           | +12/week    | Medium  |  
| Daily             | 67%           | +8/week     | Lower   |

**Recommendation**: For most users, every hour is optimal balance.

---

### Storage Growth Management

**Strategy**: Balance archival threshold with retention needs

| Archive Threshold | Active Nodes | Archived Nodes | Total Size |
|------------------|--------------|----------------|------------|
| 7 days           | ~200        | ~500           | ~1.2 GB    |
| 14 days          | ~350        | ~800           | ~2.1 GB    |
| 30 days          | ~500        | ~1,200         | ~3.5 GB    |

**Recommendation**: For most users, 7-14 days is optimal balance.

---

## 🔮 Future Enhancements (Planned)

### Phase 1: Enhanced Monitoring
- Create real-time dashboard (HTML/JS in browser)
- Add growth rate tracking with visualization
- Implement anomaly detection alerts

### Phase 2: Knowledge Synthesis
- Auto-draft summaries from clustered topics  
- Generate blog posts from research clusters
- Cross-domain synthesis engine

### Phase 3: Multi-modal Integration
- Audio transcription ingestion (podcasts/meetings)
- Image OCR for document scanning
- PDF knowledge extraction with entity linking

---

## 📞 Support & Feedback

If you encounter issues or have suggestions for improvements:

1. **Check existing scripts**: Most errors are caught by linting  
2. **Review logs**: Check `brain/context/temp/*.output` for raw data  
3. **Adjust thresholds**: Use maintenance cron jobs to tune behavior
4. **Report metrics**: Document growth rates, link densities for tuning

---

**This maintenance system ensures your brain grows exponentially while staying healthy and performant.**

🧠✨ Quality + Quantity = Massive Knowledge Graph
