# Session Checklist - End-of-Session Ritual 🧠

Use this at the **end of each session** to keep your brain healthy!

## ✅ Pre-Close Checklist (Do These Before Quitting)

### 1. Review Core Memory State
[ ] Read `[[brain/core/memory.md]]`
[ ] Confirm it's up-to-date with current knowledge state

### 2. Check for Persisted Personal Info  
[ ] Verify `brain/personal-info/name.md` exists
[ ] Verify `brain/personal-info/occupation.md` exists
[ ] Verify `brain/personal-info/location.md` exists  
[ ] Use memory tool to persist any personal info changes:
```python
# Example: persist personal info files
from hermes_tools import read_file, memory

personal_info_files = [
    "brain/personal-info/name.md",
    "brain/personal-info/occupation.md", 
    "brain/personal-info/location.md"
]
for file_path in personal_info_files:
    if os.path.exists(file_path):
        content = read_file(path=file_path).content
        memory(action="add", target="user", content=content)
```

### 3. Archive from Context Folder
[ ] Review all files in `brain/context/`
[ ] Move completed work to appropriate destination:
- Stable facts → `[[core/facts/*]]` or `[[core/memory.md]]`
- Learning complete → `[[learning/notes/*]]`
- Project work → `[[projects/*]]`  
- Completed tasks → `[[system/completed-tasks/*]]`
- Delete truly temporary notes

### 4. Create Session Log
[ ] Create `system/session-notes/session-[YYYY-MM-DD].md`
[ ] Fill in session overview and files created
[ ] Add key learnings section
[ ] Note any decisions made

### 5. Link New Notes to Core Memory
[ ] Ensure every new brain note links to `[[core/memory.md]]`
[ ] Verify each new note has 1-2 other wikilinks
[ ] Check no "orphaned" notes exist (notes with no links)

---

## 🧹 Cleanup Checklist (Optional, Every Few Sessions)

### Archive Completed Projects
[ ] Move finished projects from `projects/` to `system/archived-projects/`
[ ] Update status to "done" on project files before moving

### Prune Old Learning Notes
[ ] Review `learning/notes/` for notes that have become facts
[ ] Move completed learning to `brain/core/facts/` or link to core memory
[ ] Delete if no longer relevant (with note in cleanup log)

### Review Memories Folder  
[ ] Check `memories/` for old session memories
[ ] Summarize key takeaways into `[[core/memory.md]]`
[ ] Archive completed episodic memories to system archives

---

## 📝 Session Log Template Reminder

See: `[[system/session-notes/template]]` for full template.

Fill in these sections minimum:
- **Overview**: 2-3 sentences of what happened  
- **Files created**: List new files with paths
- **Key learnings**: Bulleted list of important discoveries
- **Decisions made**: Any important choices documented
- **State after session**: Summary of memory state

---

## ⚡ Quick Command Sequence for Session End

```python
from hermes_tools import read_file, memory, write_file
import os

# 1. Persist personal info files
personal_info_files = [
    "brain/personal-info/name.md",
    "brain/personal-info/occupation.md",
    "brain/personal-info/location.md" 
]
for file_path in personal_info_files:
    if os.path.exists(file_path):
        content = read_file(path=file_path).content
        memory(action="add", target="user", content=content)

# 2. Create session log
session_log = write_file(...) # Fill in template
```

---

## 🎯 Good Signs Your Brain is Healthy:

✅ `[[core/memory.md]]` updated within last 3 sessions  
✅ Personal info files exist and are persisted  
✅ New notes link to core memory  
✅ Context folder being cleaned regularly  
✅ Growing knowledge graph (more wikilinks)  

## 🔴 Warning Signs:

❌ Personal info not persisted with memory tool  
❌ Core memory file hasn't been updated in weeks  
❌ Many orphaned notes with no links  
❌ Context folder growing unbounded  
❌ No session logs being created  

---

## 🧠 See Also

- `[[brain/core/memory.md]]` - Main memory hub
- `system/session-notes/template.md` - Session log template
- `brain/system/.gitkeep` - System utilities
