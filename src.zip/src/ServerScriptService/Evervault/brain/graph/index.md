---
title: Knowledge Graph Visualization Index
category: graph-index
date-created: 2026-06-07
related-to: [[core/memory]], [[brain/core/facts/index]]
---

# EverVault Knowledge Graph - Visual Index

## Overview

This ASCII map shows the current state of the EverVault knowledge graph as of **session 2026-06-07**. Each number represents a cluster or key node in the knowledge base.

## High-Level Map

```
┌─────────────────────────────────────────────────────────────────┐
│                    E VERVAULT KNOWLEDGE GRAPH                    │
└─────────────────────────────────────────────────────────────────┘

          [[core/memory]]
              ╱  ╲
             ╱    ╲
            ╱      ╲
       ┌───╄───────╄───┐
       │   BRAIN REGIONS   │
       │                 │
       │  ─────────────  │
       │                  │
       │ [[brain/core]]   │
       │    ↓             │
       │ [[brain/personal-info]] │
       │ [[brain/learning/notes]] │
       │ [[brain/context]]     │
       │ [[brain/projects]]    │
       └──────────────────┘
              ╲  ╱
               ╲╱

    ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
    │ system/      │   │ projects/    │   │ tasks/       │
    │ ├── cron/     │   │ ──────────  │   │ ──────────── │
    │ ├── templates │   │ Barricade   │   │ Various      │
    │ ├── memories/ │   │ RL Agent    │   │ notes        │
    │ └── session-  │   └─────────────┘   └─────────────┘
    │     notes/    │                      ↑
    └──────────────┘          ┌─────────────┴──────────────┐
                              │ scripts/                    │
                              │ ├── entity-extractor.py     │
                              │ ├── link-suggester.py       │
                              │ ├── archival-bot.py         │
                              │ └── session-end-routine.py  │
                              └─────────────────────────────┘


      [[system/session-notes/session-log-2026-06-07]]
                   ╱
                  ╱  Session continuity anchor
                 ╱═══════════════════════════════╮
                ╱                                 ╲
        ┌──────┴──────────┐           ┌───────────┴───────┐
        │ brain/learning/ │           │ brain/core/facts/  │
        │ notes/          │           │                    │
        │ └── evervault-  │           │ ─────────────────  │
        │     system-dis- │           │                   │
        │     covery.md   │           │ Atomic facts:      │
        │                 │           │ ├── memory-tool-   │
        └─────────────────┘           │     pattern-fact    │
                                      └─────────────────────┘


        ┌────────────────────────────────────────────────────────┐
        │                PERSISTENCE LAYER                       │
        └────────────────────────────────────────────────────────┘

        ════════════════════════════════════════════════════
                      MEMORY TOOL HUB
                   ════════════════════════════════════
                          User & Brain System: KK Khangaroo...
                          Atomic fact: Memory tool usage...


        Legend:
          ┌───┐  = Cluster or major region
          ├─────┤  = Connection path / relationships
          ↓      = Links to core memory hub
```

## Cluster Descriptions

### 1. Core Brain Regions (brain/)
- **core/** - Persistent facts and atomic knowledge units
- **personal-info/** - Identity, preferences, tools (CRITICAL: always persist!)
- **learning/notes/** - Temporary learning notes (can evolve to facts)
- **context/** - Temporary context folders (active/, graph/, temp/, archived/)

### 2. System Layer (system/)
- **templates/** - Note templates for new content
- **memories/** - Additional memory storage (hybrid with tool)
- **session-notes/** - Session logs for continuity recovery
- **cron/** - Scheduled automation jobs

### 3. Projects (projects/)
- Barricade RL Agent project (separate from main brain)
- Other knowledge projects as they grow

### 4. Automation Scripts (scripts/)
- Entity extraction from tool outputs
- Link suggestion for automatic wikilinks
- Archival scoring and cleanup
- Session end routines

## Key Connection Paths

1. **[[core/memory]]** is the CENTRAL HUB - all important notes should link here
2. **[[system/session-notes/*]]** provide continuity recovery when using `/new`
3. **[[brain/personal-info/*]]** - ALWAYS persist with memory tool!
4. **[[brain/core/facts/*]]** - Atomic facts for searchable knowledge

## Graph Density Metrics (Current)

- **Total nodes**: ~20 major clusters identified
- **Average links per node**: ~2-3 (needs improvement to 8-15+)
- **Core hub connections**: Most notes point to [[core/memory]] ✅
- **Orphaned notes**: Need link suggestion system implementation

## Next Optimization Priorities

1. **Build Graph Density**: Add more wikilinks between related concepts
2. **Implement Link Suggestion**: Auto-create links between related notes
3. **Add More Atomic Facts**: Create facts in brain/core/facts/ for patterns discovered
4. **Graph Visualization**: Enhance ASCII map as graph grows

---

*Generated: 2026-06-07 optimization session. Last updated: Session 2026-06-07.*
