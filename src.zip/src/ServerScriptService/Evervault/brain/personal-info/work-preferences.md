# Work Preferences - How You Like to Work

### Learning Style

## Preferred Workflow

### Session Structure
- I prefer starting sessions by reading: `[[core/memory]]` + any blocked tasks
- New facts should be persisted immediately using `memory` tool
- End sessions with session log in `system/session-notes/`

### Note-Taking Style
- Atomic notes preferred (one idea per note)
- Wikilinks for all new brain notes (minimum 2 links)
- Regular review of core memory at start of each session

## Communication Preferences

### When Asking Hermes Questions
- Prefer direct, specific questions  
- Willing to explain context if needed
- Acceptable approaches: 
  - [ ] Direct answers requested
  - [ ] Explained reasoning requested
  - [ ] Step-by-step guidance preferred

### Browser Usage
- Use Arc browser as primary on macOS
- Hermes browser tools should be used sparingly for file-based endpoints
- Can make Arc the system default via built-in option when needed

## Learning Style

### How You Learn Best
- Hands-on experiments (build things, run commands, test scripts)
- Reading docs + examples with practical application
- Mental models + analogies connecting new concepts to existing knowledge

### Information Depth Preference
- Prefer concise responses over verbose explanations
- Willing to dig deeper when needed
- Like practical examples alongside theory

---

*Last updated: [[session-log-date]]*  
*Use memory tool to persist: see `[[system/memory-tool-guide]]` for instructions*
