# Tools and Environment - Tech Stack

**⚠️ IMPORTANT**: After updating this file, persist with memory tool!

## Operating System

- **OS**: macOS 26.5 (Ventura)
- **Architecture**: ARM64 (Apple Silicon M-series chip)
- **Cores**: 10 CPU cores available for local processing

## Default Browser

**Arc browser on macOS** - Preferred over Safari/Chrome for all web interactions

## Development Environment

- **IDE / Editor**: Not currently documented (please specify your preferred editor like VSCode, Cursor, etc.)
- **Shell / Terminal**: zsh (macOS default)
- **Package Manager**: Homebrew available

## Languages & Tools You Use

### Programming Languages

- **Python** - Primary language for AI/ML work with pandas, requests libraries
- **Not currently documented**: Additional languages if applicable

### Frameworks / Technologies

- **Hermes Agent** - Current brain system with local LLM integration
- **LM Studio** - Local LLM inference via qwen/qwen3.5-9b model (9B parameter size)
- **Obsidian** - PKMS (Personal Knowledge Management System) for vault persistence

## AI Tools & Models

- **Hermes Agent**: ✅ Active (current brain system with multi-layer architecture)
- **LM Studio**: ✅ Configured and running locally on Apple Silicon
  - Host URL: localhost (local processing only - no external calls)
  - Model: qwen/qwen3.5-9b (optimized for local reasoning)
  - Purpose: Local synthesis, knowledge extraction, context understanding
  - **Privacy**: All processing happens ON YOUR DEVICE - no data leaves your computer

### Knowledge Base Architecture

- **Filesystem**: ~/Documents/EverVault/brain/ (permanent notes)
- **Memory Tool**: Cross-session persistence for preferences/corrections
- **Session Cache**: Temporary working memory during current conversation

## Other Important Tools

- **search_files** - Find notes by pattern/content
- **read_file** - Read any note contents
- **write_file** - Create/edit notes
- **patch** - Safe find-and-replace edits
- **memory** tool - Cross-session fact persistence
- **execute_code** - Run Python scripts for automation
- **terminal** - Shell commands for system tasks

---

*Last updated: Session 2026-05-31 → 2026-06-01 rebuild  
Use memory tool to persist: see `[[system/memory-tool-guide]]` for instructions*
