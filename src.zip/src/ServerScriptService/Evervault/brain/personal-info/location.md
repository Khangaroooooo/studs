# Location - Geographic Identity

**⚠️ IMPORTANT**: After updating this file, persist with memory tool!

## City / Town

- **Based in**: Not currently documented (please specify if you want me to add location details)
- **Working from**: Home office setup on macOS

## Country / Region

- **Platform**: Running on Apple Silicon Mac (macOS 26.5 Ventura)
- **Timezone**: Not currently specified (please provide UTC offset if needed for scheduling)

## Base Location

Where you primarily work from:
- Home office on macOS (Apple Silicon M-series chip, ARM64 architecture)
- 10 CPU cores available for local AI processing

## Working Hours

- Work timezone: Flexible (not currently documented)
- Standard hours: Self-directed / async workflow preferred
- Flexible hours: Available for deep work sessions

---

*Last updated: Session 2026-05-31 → 2026-06-01 rebuild  
Use memory tool to persist: see `[[system/memory-tool-guide]]` for instructions*
