# Occupation - Professional Identity

**⚠️ IMPORTANT**: After updating this file, persist with memory tool!

## What You Do Professionally

- **Current Identity**: kkhangaroo (professional handle across platforms)
- **Professional Context**: Building a local AI brain system using Hermes Agent + LM Studio + Obsidian PC Brain

## Areas of Expertise

1. **Local AI Development** - Running LLMs locally via LM Studio on Apple Silicon Mac
2. **Knowledge Management Systems** - Designing personal knowledge bases with EverVault architecture
3. **PC Brain Setup** - Configuring Hermes integration with local models and Obsidian vault persistence

## Projects or Organization (if applicable)

- Current project: **EverVault PC Brain System** (multi-layer knowledge graph architecture)
- GitHub handle: @kkhangaroo (primary public profile)
- Technical focus: Local AI, knowledge management, persistent memory systems

## What You Build / Create

- **Local AI Applications** - Leveraging LM Studio for local LLM processing without cloud APIs
- **Knowledge Graph Systems** - Building interconnected notes with wikilinks for growing brain
- **Persistent Memory Frameworks** - Using Hermes memory tool to survive across sessions

---

*Last updated: Session 2026-05-31 → 2026-06-01 rebuild  
Use memory tool to persist: see `[[system/memory-tool-guide]]` for instructions*
