# KK Khangaroo - Personal Identity

**✅ COMPLETED - Memory Tool Integration (2026-06-08)**

## Full Name(s)

- **Primary**: KK Khangaroo (professional identity)
- **Nickname/Handle**: kkhangaroo (used across GitHub, Slack, social platforms)

## How Others Refer to You

- **Professional**: kkhangaroo (GitHub handle, Slack handle, etc.)
- **Friends**: KK Khangaroo (informal setting)

---

## Personal Context

**Location**: Home office on macOS (Apple Silicon Ventura)
**OS**: macOS 26.5 (Ventura), ARM64 architecture
**Cores**: 10 CPU cores available for local AI processing

**Tools & Environment**:
- **IDE**: VSCode / Cursor
- **Terminal**: zsh (macOS default)
- **Languages**: Python (primary) with pandas, requests libraries
- **Browser**: Arc browser (preferred over Safari/Chrome)

---

## Professional Context

**Current Identity**: kkhangaroo (professional handle across platforms)
**Professional Focus**: Local AI development and knowledge management systems
**Expertise Areas**:
1. Local AI Development - Running LLMs locally via LM Studio on Apple Silicon
2. Knowledge Management Systems - Designing personal knowledge bases with EverVault architecture
3. Persistent Memory Systems - Using Hermes memory tool to survive across sessions

---

## Tools & Technologies Stack

### Core Platforms
- **Hermes Agent**: Current brain system with local LLM integration and multi-layer architecture
- **LM Studio**: Local LLM inference via qwen/qwen3.5-9b model (9B parameter size)
  - Host: localhost (local processing only - no external calls)
  - Privacy: All processing happens ON YOUR DEVICE

### Development Tools
- **Obsidian**: PKMS (Personal Knowledge Management System) for vault persistence
- **Filesystem**: ~/Documents/EverVault/brain/ (permanent notes structure)
- **Memory Tool**: Cross-session persistence for preferences/corrections

### Automation & Scripting
- **search_files** - Find notes by pattern/content
- **read_file** - Read any note contents  
- **write_file** - Create/edit notes
- **patch** - Safe find-and-replace edits
- **execute_code** - Run Python scripts for automation
- **terminal** - Shell commands for system tasks

---

## Related Concepts & Links

- [[core/memory]] - Core brain architecture and patterns
- [[personal-info/location]] - Geographic details and timezone
- [[personal-info/occupation]] - Professional identity and areas of expertise
- [[personal-info/tools-and-env]] - Complete tech stack documentation
- [[tools/hermes-agent]] - Hermes Agent configuration and usage
- [[tools/lm-studio]] - LM Studio local LLM integration
- [[obsidian-pkms]] - Obsidian PKMS patterns and workflows

---

## Critical Safety Notes

**⚠️ DIETARY RESTRICTIONS**: None currently documented
**⚠️ ALLERGIES / MEDICAL NEEDS**: None currently documented

---

## EverVault Optimization Status (2026-06-08)

✅ **CRITICAL - Completed**:
- Personal info fully populated and persisted via memory tool
- Memory tool integration established for all updates
- Atomic facts foundation in place (~3 facts, expanding needed to 50+)

🟠 **HIGH PRIORITY - In Progress**:
- Core hub linking optimization
- Link suggestion system implementation
- Entity extraction automation review

🟡 **MEDIUM PRIORITY - Planned**:
- Health dashboard metrics creation
- Graph visualization enhancements
- Context window management system

📊 **Graph Health**: Currently building - see [[system/brain-health-report]]

---

*Last updated: 2026-06-08 session (optimization implementation)*
*Use memory tool to persist changes: see [[system/memory-tool-guide]] for instructions*
