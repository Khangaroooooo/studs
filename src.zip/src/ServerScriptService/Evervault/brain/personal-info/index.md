# Personal Info Index - Your Identity Overview

This is an **index page** for all your personal information. Every session should check this!

## Core Identity Files (Must Create These)

### 1. Basic Information
- `[[name]]` - Your full name(s), aliases  
- `[[occupation]]` - What you do professionally
- `[[location]]` - City, timezone, base location

### 2. Tech & Tools
- `[[tools-and-env]]` - Your tech stack and tools
- `[[computer-setup]]` - Hardware/software configuration

### 3. Preferences  
- `[[work-preferences]]` - How you like to work
- `[[brain-rules]]` - Rules about this brain system

---

## 📋 Session Checklist for Personal Info

At the start of each session:
1. [ ] Read all personal info files
2. [ ] Use memory tool to persist any that need persistence
3. [ ] Update [[computer-setup]] if changes made
4. [ ] Add new preferences as needed

---

## 🧠 Key Principle

**Use `memory` tool for ALL personal info!** Obsidian alone won't persist facts across sessions.

Example session-start routine:
```python
from hermes_tools import read_file, memory, write_file

# Read all personal info files
personal_info_files = [
    "brain/personal-info/name.md",
    "brain/personal-info/occupation.md",
    "brain/personal-info/location.md", 
    "brain/personal-info/tools-and-env.md",
    "brain/personal-info/work-preferences.md"
]

# Persist each to memory (cross-session persistence!)
for file_path in personal_info_files:
    content = read_file(path=file_path).content
    memory(action="add", target="user", content=content)
```

---

## 🎯 See Also

- `[[brain/core/memory.md]]` - Main memory hub
- `system/memory-tool-guide.md` - How to use memory tool
- `[[brain/.getting-started]]` - Quick start guide
