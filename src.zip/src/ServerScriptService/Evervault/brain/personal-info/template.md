# Personal Info Template - Create Your Identity Notes Here

Use this as a reference when creating your personal info notes!

## Required Files to Create:

### Core Identity (CREATE THESE NOW):

1. `personal-info/name.md` - Your full name(s), aliases
2. `personal-info/occupation.md` - What you do professionally  
3. `personal-info/location.md` - City, timezone, base location
4. `personal-info/occupation.md` - Hobbies, interests, passions
5. `personal-info/tools-and-env.md` - Your tech stack and tools

### Preferences (CREATE THESE):

6. `personal-info/work-preferences.md` - How you like to work  
7. `personal-info/computer-setup.md` - Your hardware/software setup
8. `personal-info/brain-rules.md` - Your preferences about this brain system

## Template for Personal Info Notes:

```markdown
---
title: Aspect of your identity or preferences
category: name | occupation | location | tools | preferences
related-to: [[core/memory.md]]
persistent-fact: true (use memory tool to save!)
---

## What This Is

[Clear description of who you are in this aspect]

## Details

[Flesh out the details...]

## Important Notes

- Key point 1
- Key point 2  
- Key point 3

## Related Concepts

[[concept-related-to-this]]

## Persistence Note

**⚠️ IMPORTANT**: Use `memory` tool to persist this fact!

```python
# This example persists to memory:
memory(action="add", target="user", content=f"User's full name is: {name}")
```

Example for name.md persistence:
```python
from hermes_tools import read_file
# After reading this file...
memory(action="add", target="user", content=read_file(path="personal-info/name.md").content)
```

---

## 🧠 See Also

- `[[brain/core/memory.md]]` - Persistent memory hub
- `[[personal-info/preferences.md]]` - Work preferences
- `system/templates/note-template.md` - General template
```
