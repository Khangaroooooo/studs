# Brain Rules - Guidelines for Using This System

**⚠️ IMPORTANT**: These rules are persistent and critical! Use memory tool!

## Core Principles

### 1. Memory Tool is Critical 🧠
- **ALWAYS** use `memory` tool to persist important facts across sessions
- Personal info files MUST be persisted immediately after editing
- Facts, discoveries, and key learnings should be persisted when important

### 2. One Idea Per Note ✨
- Keep notes atomic (focused on single concept)  
- Link everything with wikilinks `[[concept-name]]`
- Build knowledge graph density

### 3. Session Hygiene 🧹
- Review core memory at session start
- Create session logs at session end  
- Clean up context folder regularly
- Archive completed work to appropriate destination

## Specific Rules

### When Hermes Adds Content:
1. **Check persistence**: If adding personal fact → use memory tool immediately
2. **Link everything**: New brain notes must link to `[[core/memory.md]]` + 1-2 others  
3. **Reserve folders properly**:
   - `brain/core/` → Persistent facts (use memory tool!)
   - `brain/learning/notes/` → Temporary learning (may evolve to facts)
   - `brain/context/` → Temporary context only
   - `brain/personal-info/` → Identity facts (ALWAYS persist!)

### For Facts:
- Use `brain/core/facts/` for atomic searchable knowledge units
- Each fact file should be linkable and discoverable
- Consider persisting important facts to memory tool

### For Projects & Tasks:
- Create project files in `projects/` with clear status  
- Add tasks in `tasks/` with templates
- Move completed work to `system/archived/` or `system/completed-tasks/`

## Persistence Priority (Use Memory Tool For):

### CRITICAL Priority (ALWAYS persist):
1. `brain/personal-info/*.md` - ALL files in this folder
2. `brain/core/facts/*.md` - Important fact files  
3. New important discoveries or facts created during session

### HIGH Priority (Should persist):
4. Key learnings that affect future sessions
5. User preferences discovered or updated
6. Important tools/technologies discovered

### LOW Priority (Can reference without persistence):
- Temporary context notes
- Session-specific exploration notes  
- Single-session experiments (but link to core knowledge)

---

## Memory Tool Usage Pattern (Memorize This!)

```python
from hermes_tools import read_file, memory

# Pattern 1: Persist after editing personal info file
edit_file(path="brain/personal-info/name.md", content=...)
persist_fact(content=read_file(path="brain/personal-info/name.md").content)

# Pattern 2: Persist a fact file you just created  
write_file(path="brain/core/facts/new-fact.md", content=fact_content)
memory(action="add", target="user", content=read_file(path="brain/core/facts/new-fact.md").content)

# Pattern 3: Batch persist multiple personal info files (session start or end)
personal_info_files = [
    "brain/personal-info/name.md",
    "brain/personal-info/occupation.md",
    "brain/personal-info/location.md",
    "brain/personal-info/preferences.md"
]
for file_path in personal_info_files:
    if os.path.exists(file_path):
        content = read_file(path=file_path).content
        memory(action="add", target="user", content=content)
```

---

## 🎯 See Also

- `[[core/memory.md]]` - Main memory hub  
- `[[system/memory-tool-guide]]` - Complete memory tool documentation
- `[[brain/.getting-started]]` - Quick start guide
