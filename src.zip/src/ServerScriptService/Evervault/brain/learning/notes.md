# Learning Notes - New Knowledge Acquisition

This is where your **learning happens**. Each time you learn something new, create a note here!

## How to Use This Folder

### When to Add a Note:
- You discover a new concept/tool/idea
- You read something valuable (book, article, video)
- You complete a learning experiment
- You make an important insight/realization

### Template for New Learning Notes:

```markdown
---
title: What you learned
topics: [[related-concept1]], [[related-concept2]]
date: {{session-date}}
source: (where did this come from?)
key-insights: 
  - bullet 1
  - bullet 2
related-projects: 
  - [[project-name]]
related-memories:
  - [[memory-event]]
---

## The Big Idea

One or two sentences summarizing what you learned.

## Details

Expand on the concept here...

## Connections

How does this relate to other notes? Link them!

## Action Items

What can you do with this knowledge?
```

### Example: Learning a New Tool

After your first session with Hermes + LM Studio:
- Create `learning/notes/hermes-brain-setup.md`
- Document the setup process
- List commands that work
- Note any issues encountered
- Link to `[[brain/core/memory.md]]` and `[[brain/personal-info/preferences]]`

### Quality Tips

1. **Be specific** - What exactly did you learn?
2. **Link things** - Connect to existing knowledge graph
3. **Capture your voice** - Use your natural explanations
4. **Iterate** - Notes get refined over time
5. **Archive wisely** - Move completed experiments elsewhere

---

## 📚 See Also

- `[[brain/core/memory.md]]` - Update this with key insights
- `brain/context/` - For temporary learning context
- `system/templates/note-template.md` - Full template
