---
title: evervault-initial-setup-documentation
topics: [[brain/core/memory]], [[facts/hybrid-persistence-pattern]]
date: 2026-06-01
source: PC Brain Setup Session + Improvement Work
key-insights: 
  - Brain system uses hybrid persistence (filesystem + memory tool)
  - Three-layer architecture separates persistent, WIP, and learning content
  - Atomic notes principle enables granular knowledge graph linking
related-personal-info:
  - [[personal-info/occupation]]
  - [[personal-info/tools-and-env]]
status: new
---

## The Big Idea

EverVault is a **local AI knowledge management system** that combines Obsidian vault filesystem storage with Hermes Agent's memory tool for cross-session persistence. All processing happens locally on Apple Silicon Mac using LM Studio's qwen/qwen3.5-9b model.

---

## Details & Context

### What I Discovered About This Brain System:

1. **Hybrid Persistence Architecture**
   - Obsidian files provide searchable, linkable knowledge graph in filesystem
   - Memory tool provides cross-session survival for critical facts
   - Using both ensures data survives both Obsidian edits AND session restarts

2. **Three-Layer Design Philosophy**
   - Layer 1 (Persistent): Core memory hub, personal info, atomic facts
   - Layer 2 (Work in Progress): Projects, tasks, memories
   - Layer 3 (Learning & Context): New discoveries, temporary context

3. **Atomic Notes Principle**
   - One idea per note, not one giant file
   - Dense wikilink network between focused notes
   - Easy to search, link granularly, and maintain over time

4. **Session Hygiene Requirements**
   - Persist personal info with memory tool at session end (non-negotiable!)
   - Create session log for each session
   - Review and clean context folder regularly (<5 files)
   - Update core memory with session highlights

---

## My Take / Interpretation

### What Makes This System Different:

Most knowledge management systems fall into one of two categories:

**❌ Cloud-based**: Data leaves your device, requires internet, privacy concerns  
**❌ Obsidian alone**: Files persist but are lost when Hermes session ends  

**✅ EverVault**: Best of both worlds - local storage + cross-session persistence

### The Critical Discovery:

**Obsidian files ALONE are NOT enough for facts that need to survive across sessions.** This was a revelation! Filesystem changes in Obsidian are lost when the Hermes conversation ends. Only calls to `memory(action="add", target="user", ...)` persist facts across sessions.

---

## Connections

### How This Connects to Existing Knowledge:

#### Core Concepts:
- [[brain/core/memory.md]] - Main persistent memory hub that accumulates learnings
- [[connection-guide]] - Architecture documentation for three-layer design

#### Persistence Patterns:
- [[facts/hybrid-persistence-pattern]] - The dual mechanism explanation
- [[facts/session-end-routine]] - Automation pattern for cleanup
- [[facts/context-folder-maintenance]] - Bloat prevention strategy

#### Tool Knowledge:
- [[personal-info/tools-and-env]] - Tech stack including LM Studio and Hermes
- [[brain/.getting-started]] - User guidance for new people

### Creates New Understanding:
This setup helps me understand:
- How to design persistent local AI systems
- The importance of atomic note-taking for knowledge graphs
- Why session hygiene automation is critical (manual checks are unreliable)

---

## Action Items / Next Steps

- [ ] Add core concepts fact about three-layer architecture to `brain/core/facts/`
- [ ] Document personal info filling tasks in `learning/notes/personal-info-filling.md`
- [ ] Create memory entry for this improvement session in `memories/`
- [ ] Link new facts to existing knowledge graph
- [ ] Update core memory hub with highlights from this documentation

---

## Related Files

- [[brain/core/memory]] - Main persistent memory hub (update with learnings)
- [[projects/evervault-brain-system]] - Active project tracker
- [[system/session-notes/template]] - Session logging template for this work
- [[brain/.getting-started]] - Guide for new users

---

*Created during session: 2026-06-01  
Discovery about hybrid persistence architecture and brain system design patterns*
