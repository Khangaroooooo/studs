---
title: memory-tool-persistence-lessons
topics: [[brain/core/memory]], [[facts/hybrid-persistence-pattern]]
date: 2026-06-01
source: Session improvement work on EverVault
key-insights: 
  - Personal info files MUST be persisted with memory tool to survive sessions
  - Using both filesystem AND memory tool creates redundancy and safety
  - Obsidian alone is NOT enough for cross-session persistence
related-personal-info:
  - [[personal-info/name]]
  - [[personal-info/tools-and-env]]
status: new
---

## The Big Idea

The `memory` tool is the **ONLY mechanism** available for facts to survive across Hermes sessions. Obsidian filesystem storage alone is NOT sufficient because file changes are lost when a session ends and a new conversation begins.

---

## Details & Context

### Critical Discovery from Initial Session:

During the EverVault rebuild, I observed that **facts not persisted with memory() are completely lost** when you return with a new Hermes session. This was shocking! The filesystem files exist in your vault, but without `memory(action="add", target="user", content=...)` calls, those facts don't survive to the next conversation.

### Why Obsidian Alone Isn't Enough:

| Property | Obsidian Files Only | Memory Tool Required |
|----------|--------------------|---------------------|
| Survives filesystem edits | ✅ Yes | N/A |
| Survives session restart | ❌ NO (facts lost!) | ✅ Yes |
| Searchable via OS Finder | ✅ Yes | N/A |
| Linkable within vault | ✅ Yes | N/A |
| Cross-session survival | ❌ NO | ✅ YES |

**Conclusion**: You need BOTH for complete persistence.

---

## My Take / Interpretation

### The Pattern I Learned:

```python
# WRONG: Obsidian files alone (facts will be lost!)
write_file(path="brain/personal-info/name.md", content=...)

# RIGHT: Use both filesystem + memory tool
write_file(path="brain/personal-info/name.md", content=...)
memory(action="add", target="user", content=read_file(path="brain/personal-info/name.md").content)
```

### Why This Matters:

Without using the memory tool, your personal identity (name, occupation, location, preferences, brain rules) will be lost every time you start a new session. You'd have to re-enter everything each time - defeating the whole purpose of building a persistent AI brain!

---

## Connections

### How This Connects to Existing Knowledge:

#### Persistence Documentation:
- [[facts/hybrid-persistence-pattern]] - Complete explanation of both mechanisms
- [[brain/core/memory.md]] - Main hub where persisted facts live
- [[system/memory-tool-guide]] - Comprehensive memory tool usage guide

#### Personal Identity:
- [[personal-info/name]] - Your name needs persistence!
- [[personal-info/occupation]] - What you do needs persistence!
- [[personal-info/location]] - Your location needs persistence!
- [[personal-info/tools-and-env]] - Tech stack needs persistence!
- [[personal-info/work-preferences]] - Preferences need persistence!

### Creates New Understanding:
This lesson taught me:
- Persistence requires explicit memory() calls for critical facts
- The pattern is always: edit file → persist to memory immediately
- Session hygiene automation (session-end-routine.py) should handle this automatically

---

## Action Items / Next Steps

- [ ] Verify personal info files are persisted (check with `memory(action="list")`)
- [ ] Update session end routine script if automation not working
- [ ] Document any personal facts discovered that need persistence
- [ ] Create new learning note about this improvement work

---

## Related Files

- [[brain/core/memory]] - Main memory hub (update with learnings)
- [[facts/hybrid-persistence-pattern]] - Persistence mechanism explanation
- [[facts/session-end-routine]] - Automation pattern for cleanup
- [[projects/evervault-brain-system]] - Project tracker including persistence work

---

*Created during session: 2026-06-01  
Critical lesson about memory tool necessity for cross-session fact persistence*
