# New Note Template - Start Fresh Notes Here

Use this as a template for every new learning note you create!

```markdown
---
title: [What did I learn?]
topics: [[related-concept-1]], [[related-concept-2]]
date: {{session-date}}
source: [where from?]
key-insights: 
  - insight one
  - insight two  
related-projects: 
  - [[project-name]]
status: new | refining | integrated
---

## The Big Idea

[Briefly describe what you learned in 1-2 sentences]

## Details & Context

[Expand on the concept. What surprised you? What made it click?]

## My Take / Interpretation

[Add your own understanding. How does this connect to things you already know?]

## Connections

### Links to Existing Knowledge
- [[existing-note-1]] - connects because...
- [[existing-note-2]] - relates through...

### Creates New Understanding
This helps me understand:
- [[concept-better-now]]
- [[related-topic]]

## Action Items / Next Steps

[ ] Research more about X
[ ] Try experiment Y  
[ ] Share this with someone about Z

## Related Files

- [[brain/core/memory.md]] - Update main memory
- [[projects/any-project-name]] - if applicable
- [[tasks/relevant-task]] - if applicable

---

*Created during session: [session-date]*  
*Added by Hermes Agent*  
```

### Quick Tips

1. **Pick 2-3 related topics** from your existing notes for the `topics` field
2. **Add key insights immediately** after learning something new
3. **Link to [[brain/core/memory.md]]** to connect to persistent memory
4. **Update status** as you integrate the knowledge
