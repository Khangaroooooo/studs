# Core Memory - Persistent Knowledge Base

This is your **persistent brain**. Every session should update this file with new insights, important facts, and connections you discover.

## 🔑 Key Principles

- **Session-independent**: This memory persists via the `memory` tool across Hermes sessions
- **Cross-referenced**: Link to all other notes using wikilinks like `[[personal-info/name]]`
- **Growing smarter**: Each session adds new context and refines existing knowledge

## 📝 Session Routine

**Start of Session:**
1. Read this file to understand current knowledge state
2. Check if any new facts need adding
3. Review linked notes for gaps

**During Session:**
- Update immediately when learning something important
- Add cross-references as you discover connections
- Note user preferences and corrections

**End of Session:**
1. Write a session summary
2. Archive completed project insights
3. Prune outdated or redundant information

---

## 💾 Important Memory Facts

{{memory-tool-summary}}

*Notes: The memory tool automatically persists these facts across sessions.*

---

## 🔗 Knowledge Graph Structure

### Core Layers:
1. **[[personal-info/]]** - Who you are (identity, preferences)
2. **[[memories/]]** - What happened (events, experiences)  
3. **learning/notes/** - What you're learning (new concepts)
4. **context/** - Temporary but relevant information

### Connection Rules:
- Every new note must link to 1-2 existing notes
- Use atomic notes (one idea per file)
- Keep it simple and interconnected

---

## 📊 Memory Quality Metrics

Track your brain's health:

- **Coverage**: Do you have notes for major topics?
- **Depth**: Are complex ideas split into atomic notes?
- **Connections**: Does every note link to related concepts?
- **Recency**: Is [[core/memory.md]] updated within last session?

**Good signs:** Growing wikilink network, new learning notes daily
**Bad signs**: Orphaned notes, no recent updates, duplicated content

---

## 🎯 Session Checklist

[ ] Review current memory state
[ ] Add new important facts (use `memory` tool)
[ ] Create new learning notes if needed
[ ] Update cross-references
[ ] Prune outdated context files
[ ] Write session highlights to [[core/memory.md]]

---

## 📖 See Also

### For Mastery & Usage Guide:
- `[[USING-EVERVAULT-TO-FULLEST-POTENTIAL.md]]` ← **START HERE!** Complete usage guide
- `[[projects/evervault-mastery]]` - Detailed mastery progression path

### Session History:
- `[[system/session-notes/00-session-log.md]]` - Session history
- `[[brain/core/connection-guide]]` - Architecture details
- `[[system/templates/note-template]]` - New note template
