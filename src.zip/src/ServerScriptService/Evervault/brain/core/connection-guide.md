# Connection Guide - How Notes Link Together

This explains the **knowledge graph architecture** for your brain!

## Three-Layer Architecture

```
┌─────────────────────────────────────────────┐
│  LAYER 1: PERSISTENT CORE                    │
│  ───────────────────────────                │
│  • brain/core/memory.md ← Main hub          │
│  • brain/personal-info/*.md                 │
│  • brain/core/facts/*.md (factual knowledge)│
└─────────────────────────────────────────────┘
              ↓ Links to
┌─────────────────────────────────────────────┐
│  LAYER 2: WORK IN PROGRESS                   │
│  ────────────────────                       │
│  • brain/memories/*.md (events/experiences)  │
│  • projects/*.md                             │
│  • tasks/*.md                                │
└─────────────────────────────────────────────┘
              ↓ Feeds into
┌─────────────────────────────────────────────┐
│  LAYER 3: LEARNING & CONTEXT                 │
│  ────────────────────                       │
│  • brain/learning/notes/*.md (new learning)  │
│  • brain/context/*.md (temporary context)    │
└─────────────────────────────────────────────┘
```

## Linking Principles

### Every Brain Note Should:

1. **Link to [[core/memory.md]]** - Connects to persistent memory
2. **Link to 1-2 related notes** - Creates knowledge graph density
3. **Be atomic** - One idea per note

### Example Connections:

```markdown
[[learning/notes/hermes-first-session.md]] 
  → links to → [[core/memory.md]] (persistent)  
                 → links to → [[facts/python-f-strings]] (atomic fact)
                    → links to → [[personal-info/preferences]] (identity)
```

### Bad Linking:

❌ Single note with 20 ideas (hard to find, can't link granularly)  
✅ Multiple atomic notes, each linking to others  

## The Memory Tool Bridge

**Critical**: Use the `memory` tool to persist important facts!

```python
# This persists across sessions:
memory(action="add", target="user", content="...")
```

Obsidian files + Memory Tool = Complete persistence system!

## Growth Pattern

1. **Start**: Core memory + personal info (persistence layer)
2. **Learn**: New facts, learning notes added (growth layer)  
3. **Connect**: Events stored in memories, linked to existing knowledge
4. **Organize**: Completed work archived, new structure emerges

---

## 🧠 See Also

- `[[brain/core/memory.md]]` - Main memory hub
- `brain/learning/note-template.md` - Template for growth
- `system/templates/note-template.md` - General template
