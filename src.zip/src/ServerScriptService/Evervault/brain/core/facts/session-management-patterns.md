# Session Management Patterns (2026-06-08)

**Atomic fact** - Best practices for session hygiene and knowledge capture.

## Start of Session
1. **Read core memory**: `read_file(path="brain/core/memory.md")`
2. **Check graph index**: Review `[[graph/index]]` for clusters
3. **Review context/active/**: Scan for relevant working memory

## During Session
- **Capture entities**: New tools, projects, concepts encountered
- **Create atomic facts**: Convert learning notes → brain/core/facts/
- **Persist personal info**: Use memory tool for all fact updates
- **Link suggestions**: Identify missing wikilinks between related concepts

## End of Session
1. **Update core memory**: Record session learnings in `brain/core/memory.md`
2. **Create session log**: Write to `system/session-notes/YYYY-MM-DD.md`
3. **Run archival bot**: `python scripts/archival-bot.py --optimize`
4. **Health check**: Review graph health metrics

## Automation Opportunities
- **Session-end-routine.py**: Automates persistence + cleanup
- **Archival scoring**: Auto-archive old/low-link files
- **Pattern codification**: Identify recurring mistakes automatically

## Memory Tool Usage
```python
from hermes_tools import memory

# Add new fact
memory(action='add', target='user', content="New concept description")

# Replace existing fact  
memory(action='replace', target='user', old_text="old", new_text="new")

# Remove outdated fact
memory(action='remove', old_text="exact text to remove", target='user')
```

## Related Resources
- `[[system/memory-tool-guide]]` - Complete memory tool instructions
- [[core/memory]] - Core memory structure and usage
- [[brain/personal-info/name]] - Personal identity documentation
