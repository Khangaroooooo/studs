---
title: hybrid-persistence-pattern
category: patterns | tools | architecture
related-to: [[core/memory.md]], [[brain/.getting-started]]
status: verified
---

## What This Fact Is

The **hybrid persistence pattern** combines two mechanisms for ensuring knowledge survives across Hermes sessions:

1. **Obsidian filesystem storage** - Notes live in `~/Documents/EverVault/` for searchability, wikilinking, and long-term archival
2. **Memory tool calls** - Critical facts are persisted via `memory(action="add", target="user", ...)` to survive session restarts

### Why Use Both?

❌ **Obsidian alone is NOT enough**  
- Files in your vault persist across macOS reboots and manual editing
- BUT: When a Hermes session ends, those file changes are LOST to the next session
- The memory tool is the only cross-session persistence mechanism available

✅ **Memory tool alone is incomplete**  
- Persists facts to the session context
- Obsidian files provide searchable, linkable knowledge graph
- Files survive outside Hermes (manual edits, version control, backups)

## The Hybrid Pattern

```python
from hermes_tools import read_file, memory, write_file

# PATTERN: For ANY important personal fact or critical discovery
edit_file(path="brain/personal-info/name.md", content=...)  # Write to Obsidian
memory(action="add", target="user", content=read_file(path="brain/personal-info/name.md\").content)  # Persist to memory

# Result: 
# - File exists in filesystem (searchable, linkable)
# - Fact persists across Hermes sessions
```

### Critical Files Requiring Persistence:

| File Path | Importance | Must Persist? |
|-----------|------------|---------------|
| `brain/personal-info/name.md` | ⭐⭐⭐ Identity | YES |
| `brain/personal-info/occupation.md` | ⭐⭐⭐ Professional | YES |
| `brain/personal-info/location.md` | ⭐⭐⭐ Context | YES |
| `brain/personal-info/tools-and-env.md` | ⭐⭐⭐ Environment | YES |
| `brain/personal-info/work-preferences.md` | ⭐⭐⭐ Workflow | YES |
| `brain/personal-info/brain-rules.md` | ⭐⭐⭐ System rules | YES |
| `brain/core/facts/*.md` | ⭐ Critical knowledge | YES (important ones) |

### Non-Critical Files (May Not Need Persistence):

| File Path | Importance | Must Persist? |
|-----------|------------|---------------|
| `learning/notes/*.md` | 🟡 Temporary learning | Optional (reference as needed) |
| `memories/*.md` | 🟡 Episodic events | Session-specific mostly |
| `context/*.md` | 🔴 Temporary context | NO (archive regularly!) |
| `system/session-notes/*.md` | 🟡 Session history | Reference only |

## Pitfalls to Avoid

### ❌ DON'T do this:
```python
# WRONG: Relying on Obsidian alone for persistence
write_file(path="brain/personal-info/name.md", content="...")
# This will be lost when session ends!
```

### ✅ DO this instead:
```python
# RIGHT: Use both filesystem + memory tool
write_file(path="brain/personal-info/name.md", content=...)
memory(action="add", target="user", content=read_file(path="brain/personal-info/name.md\").content)
```

## Related Concepts

- `[[facts/session-end-routine]]` - Automation pattern for end-of-session persistence
- `[[core/memory.md]]` - Main persistent memory hub
- `[[system/memory-tool-guide]]` - Complete memory tool documentation

---

*Last updated: Session 2026-06-01 initial rebuild | Verified through experimentation*
