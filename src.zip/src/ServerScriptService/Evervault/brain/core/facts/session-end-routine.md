---
title: session-end-routine
category: patterns | workflow | hygiene
related-to: [[core/memory.md]], [[brain/checklist]]
status: verified
---

## What This Fact Is

The **session end routine** is a set of non-negotiable cleanup steps you MUST perform before ending a Hermes session. Without automation, these manual checks are frequently missed and can lead to:

- Lost personal facts (not persisted with memory tool)
- Growing context folder bloat
- Uncaptured learnings
- Incomplete session logging

### Why Automation Is Critical

The experience revealed that **manual session cleanup is unreliable**. Even when you intend to do the checklist, stress or time pressure causes you to skip steps. This led to:

1. Personal info not being persisted
2. Context folder growing unbounded  
3. Core memory not updated with session highlights
4. Session logs not created

### The Automated Solution

A Python script at `scripts/session-end-routine.py` automates these critical steps:

```python
# What the script does automatically at session end:
1. Persist personal info files using memory tool
2. Create session log in system/session-notes/
3. Review context folder for items to archive/delete
4. Update core/memory.md with session highlights
```

## The Routine Steps

### Step 1: Persist Personal Info (CRITICAL!)

```python
from hermes_tools import read_file, memory

personal_info_files = [
    "brain/personal-info/name.md",
    "brain/personal-info/occupation.md",
    "brain/personal-info/location.md",
    "brain/personal-info/tools-and-env.md",
    "brain/personal-info/work-preferences.md",
    "brain/personal-info/brain-rules.md",
]

for file_path in personal_info_files:
    if os.path.exists(file_path):
        content = read_file(path=file_path).content
        memory(action="add", target="user", content=content)
```

### Step 2: Create Session Log

```python
from hermes_tools import write_file

session_log = write_file(
    path=f"system/session-notes/session-{{today-date}}.md",
    template=read_file(path="system/session-notes/template.md").content,
    # Fill in with session overview, files created, learnings, etc.
)
```

### Step 3: Review Context Folder

Archive or delete items from `brain/context/`:

- Stable facts → Move to `brain/core/facts/` or `core/memory.md`
- Learning complete → Keep in `learning/notes/` or archive
- Project work → Move to `projects/`
- Temporary notes → Delete if still needed

### Step 4: Update Core Memory

Add session highlights to `[[core/memory.md]]`:

```markdown
## Session Highlights - {{date}}

- Learned about [concept]
- Discovered [pattern]
- Fixed [issue] or improved [process]
```

---

## 🎯 Checklist Version 1.0 (Use Until Automation Is Verified)

If automation isn't working, do these steps manually at session end:

- [ ] **Persist personal info** with memory tool for all files in `brain/personal-info/`
- [ ] **Create session log** in `system/session-notes/`
- [ ] **Review and archive** from `brain/context/` folder
- [ ] **Update core/memory.md** with session highlights

---

## ⚠️ Warning Signs You Missed the Routine

Check these if your brain feels degraded:

- Personal info files not persisted (try reading them - are you still you?)
- Context folder has >10 files (it should be <5)
- Core memory hasn't been updated in 2+ sessions
- Session logs missing for recent dates

---

## 🧠 Related Concepts

- `[[facts/hybrid-persistence-pattern]]` - The persistence mechanism explanation
- `[[brain/checklist]]` - Detailed session checklist
- `[[core/memory.md]]` - Main memory hub that needs updates

---

*Last updated: Session 2026-06-01 initial rebuild | Verified through observation that manual checks are frequently missed*
