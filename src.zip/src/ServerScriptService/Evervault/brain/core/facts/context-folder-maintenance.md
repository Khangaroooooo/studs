---
title: context-folder-maintenance
category: patterns | hygiene | workflow
related-to: [[core/memory.md]], [[brain/checklist]]
status: verified
---

## What This Fact Is

The **context folder maintenance** pattern prevents the `brain/context/` directory from growing unbounded. Context files are TEMPORARY by design - they hold information that's relevant for the current session but shouldn't accumulate over time.

### The Problem: Growing Bloat

Without regular cleanup, the context folder becomes:
- Harder to navigate (too many temporary files)
- Confusing (what should be permanent vs. temporary?)
- Inefficient (scanning 20+ files every session start)
- Risky (forgetting to clean means losing important work)

### The Rule of Thumb

> **Context folder should have <5 files at session end.**

More than that, and you're letting temporary content accumulate.

## Context vs. Permanent Storage

### What Belongs in Context (Temporary):
- Quick notes about a conversation or tool discovery
- Ideas for experiments not yet documented
- Temporary observations to verify later
- Session-specific research findings

### What Should Move Out of Context:

| Destination | When to Move |
|-------------|--------------|
| `brain/core/facts/` | Important, stable facts that should persist |
| `learning/notes/` | Learning discoveries you want to reference |
| `projects/` | Project-related work or documentation |
| `tasks/` | Action items or TODOs |
| `system/completed-tasks/` | Finished project work |

## Maintenance Routine

### At Session End (Every Time):

```python
from hermes_tools import read_file, write_file, terminal
import os

context_dir = "brain/context"

# Review all files in context folder
for filepath in sorted(os.listdir(context_dir)):
    full_path = os.path.join(context_dir, filepath)
    
    if filepath.endswith('.md') and os.path.isfile(full_path):
        content = read_file(path=full_path).content
        
        # Decide: archive or delete
        if is_permanent_fact(content):
            write_file(path=f"brain/core/facts/{filepath}", content=content)
            os.remove(full_path)  # Archive to facts
        elif is_learning_discovery(content):
            write_file(path=f"learning/notes/{filepath}", content=content)
            os.rename(full_path, f"learning/notes/{filepath}")
        elif is_temporary_and_no_longer_needed(content):
            os.remove(full_path)  # Safe to delete
        else:
            # Keep in context for now (review later)
            pass
```

### Visual Decision Process:

```
File in brain/context/
    ↓
Is this fact stable and important?
├─ YES → Move to brain/core/facts/
└─ NO
    ↓
Is this learning worth keeping?
├─ YES → Move to learning/notes/
└─ NO
    ↓
Is this project work?
├─ YES → Move to projects/
└─ NO
    ↓
Is this a completed task?
├─ YES → Move to system/completed-tasks/
└─ NO
    ↓
Delete or keep temporary?
```

---

## 📝 Context Folder Quality Check

Before ending any session, verify:

1. **No more than 5 files** in context folder
2. **Each file has a clear purpose** for this session
3. **None are outdated** (checked against recent sessions)
4. **Temporary work moved** to appropriate destination folders

### Red Flags (Immediate Action Needed):

🔴 Context folder has >10 files → Review immediately  
🟡 Context folder has files not linked to anything → Delete or link  
🟢 Context folder is clean (<5 files) → Good state  

---

## 🧠 Related Concepts

- `[[facts/session-end-routine]]` - The automation pattern for all cleanup
- `[[brain/checklist]]` - Detailed session end checklist
- `[[core/memory.md]]` - Main hub where stable context should go

---

*Last updated: Session 2026-06-01 initial rebuild | Verified through observation that context folder grows without regular maintenance*
