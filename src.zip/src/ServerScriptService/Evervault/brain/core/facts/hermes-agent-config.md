# Hermes Agent Configuration (2026-06-08)

**Atomic fact** - Local AI development environment using Hermes Agent with LM Studio.

## Setup Components
- **IDE**: VSCode or Cursor
- **Terminal**: zsh on macOS 26.5 (Ventura)
- **Memory Tool**: Cross-session persistence via `memory` tool for preferences/corrections
- **Execute Code**: Python scripts via `execute_code` tool for automation
- **Terminal**: Shell commands for system tasks

## Local LLM Integration
- **Model**: qwen/qwen3.5-9b (9B parameters)
- **Provider**: LM Studio running on localhost
- **Architecture**: Apple Silicon M-series chip, ARM64, 10 cores
- **Privacy**: All processing ON YOUR DEVICE - no external API calls

## Core Patterns
- **Atomic Notes**: Each note covers one concept with wikilinks
- **Session Hygiene**: `[[core/memory]]` at start, `[[system/session-notes/]]` at end
- **Memory Persistence**: ALWAYS use memory tool for personal info & facts updates

## Related Tools
- [[tools/lm-studio]] - Local LLM inference server
- [[tools/hermes-agent]] - Hermes Agent CLI and configuration
- [[obsidian-pkms]] - Obsidian PKMS integration patterns
