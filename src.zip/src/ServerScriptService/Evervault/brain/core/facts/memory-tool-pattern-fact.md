---
title: Memory Tool Usage Pattern - Hybrid Persistence System
category: atomic-fact
related-to: [[core/memory]], [[system/memory-tool-guide]], [[brain/core/facts/hybrid-persistence-pattern]]
persistent-fact: true
---

## Discovery

On **2026-06-07 optimization session**, discovered the critical need for **hybrid persistence**: using both filesystem storage (Obsidian vault) AND memory tool for cross-session continuity.

## The Pattern

```python
from hermes_tools import read_file, memory

# After editing any personal info or fact file:
content = read_file(path="brain/personal-info/name.md").content
memory(action="add", target="user", content=content)
```

**Why this matters:** The filesystem alone is session-local. When you use `/new` or `session_search()` to recover work, the Obsidian vault path changes or sessions reset. The memory tool persists facts across these transitions!

## Critical Facts Persisted (Session 2026-06-07)

1. ✅ **User Identity**: KK Khangaroo (kkhangaroo handle), local AI developer
2. ✅ **Environment**: macOS Apple Silicon, VSCode/Cursor, zsh, Python pandas/requests
3. ✅ **Tools Stack**: Hermes Agent + LM Studio qwen3.5-9b, Arc browser default
4. ✅ **Core Brain Rules**: atomic notes, wikilinks everywhere, session hygiene pattern
5. ✅ **Vault Path**: ~/Documents/EverVault (NEVER create new vaults - consolidate!)
6. ✅ **Session Hygiene**: Review [[core/memory]] at start, log to system/session-notes/ at end

## Best Practices

**CRITICAL Priority (ALWAYS persist):**
1. All `brain/personal-info/*.md` files after editing
2. Important `brain/core/facts/*.md` fact files
3. New discoveries that affect future sessions

**HIGH Priority (Should persist):**
4. Key learnings affecting workflow
5. User preferences discovered or updated
6. Important tools/technologies discovered

**LOW Priority (Reference without persistence):**
- Temporary context notes
- Single-session exploration notes
- Experiments (but link to core knowledge)

## See Also

- `[[core/memory]]` - Main persistent memory hub
- `[[system/memory-tool-guide]]` - Complete usage documentation
- `[[brain/core/facts/hybrid-persistence-pattern]]` - Detailed explanation
- `[[session-log-2026-06-07]]` - Session log documenting this discovery

---

*Atomic fact created during 2026-06-07 optimization session.*
