---
title: wikilink-connectivity-rules
category: patterns | architecture
related-to: [[core/memory.md]], [[connection-guide]]
status: verified
---

## What This Fact Is

The **wikilink connectivity rules** establish how notes should connect to form a dense, navigable knowledge graph. Every brain note must link to other notes - this creates the "web" that makes your brain searchable and discoverable.

### The Golden Rule:

> **Every brain note links to `[[core/memory.md]]` + 1-2 related notes minimum.**

This ensures:
1. Everything connects to the persistent memory hub
2. Notes form a graph, not isolated documents
3. Easy navigation from any note back to core knowledge

---

## Linking Requirements by Folder

| Folder | Minimum Links Required | Maximum Practical Links |
|--------|------------------------|-------------------------|
| `brain/core/*.md` | 3+ (core concepts) | 5-7 links max |
| `brain/personal-info/*.md` | 2 (name + 1 related) | 4-5 links max |
| `brain/learning/notes/*.md` | 2 (topics + memory.md) | 6 links max |
| `brain/memories/*.md` | 2 (memory hub + related fact) | 4-5 links max |

---

## Example Well-Linked Note

```markdown
---
title: hermes-first-session-discovery
category: learning
topics: [[hermes-agent]], [[lm-studio]]
related-to: [[core/memory.md]], [[brain/.getting-started]]
status: new
---

## Discovery About Hermes Integration
[Content about first session with Hermes...]

## What I Learned
- [ ] Learned how to use memory tool for persistence
- [ ] Discovered hybrid filesystem+memory pattern

## Related Notes
### To Other Facts:
- [[facts/memory-tool-persistence]] - The persistence mechanism
- [[tools-and-env/hermes-agent]] - Tool documentation

### To Core Memory:
- [[core/memory.md]] - Main hub (REQUIRED!)

## Action Items
[ ] Read core memory again to see what's already stored
```

---

## Bad Linking Examples

### ❌ No Links at All:
```markdown
# isolated-note.md
No wikilinks anywhere!
```

**Problem**: Can't be discovered via graph traversal. Orphaned note.

### ❌ Only Links to Self:
```markdown
[[isolated-note]]
[[isolated-note]]
[[isolated-note]]  # Just linking yourself
```

**Problem**: No connection to other knowledge. Pointless.

### ✅ Good Linking:
```markdown
- [[core/memory.md]] - Main memory hub (REQUIRED)
- [[facts/memory-tool-persistence]] - Related concept
- [[brain/.getting-started]] - Guide for new users
```

**Good**: Connects to core knowledge and related facts.

---

## Link Quality > Link Quantity

Don't link to just anything. Links should be meaningful:

| Good Link | Bad Link | Why |
|-----------|----------|-----|
| `[[memory-tool-persistence]]` from a note about memory tool | `[[QUICK-START.md]]` | Related concept vs. top-level guide |
| `[[core/memory.md]]` from any brain note | `[[README.md]]` - link only from entry points | Core hub is the main connection |
| `[[personal-info/name]]` in personal notes | `[[brain/checklist]]` - unrelated to this note | Semantic relevance matters |

---

## Tools for Checking Link Quality

### Using search_files:
```python
from hermes_tools import search_files

# Find notes with no links
result = search_files(pattern=r"^\#\s+.*", target="content", path="brain/", file_glob="*.md")
orphans = [f for f in result.matches if "[[" not in f.content]  # No wikilinks
```

### Finding Orphaned Notes:
Search for notes with low link density - they might need better connections to core knowledge.

---

## Related Concepts

- `[[connection-guide]]` - Architecture documentation
- `[[brain/core/memory.md]]` - Main hub that everything links to
- `[[facts/atomic-notes-principle]]` - One idea per note for granular linking

---

*Last updated: Session 2026-06-01 initial rebuild | Pattern verified through graph density observation*
