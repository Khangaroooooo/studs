# LM Studio Local Inference (2026-06-08)

**Atomic fact** - qwen3.5-9b model configuration for EverVault PC Brain.

## Model Details
- **Name**: qwen/qwen3.5-9b
- **Parameters**: 9B (9 billion parameters)
- **Provider**: LM Studio CLI or API
- **Host**: localhost:1234 (default LM Studio port)

## Configuration
```yaml
provider: lmstudio
model: qwen/qwen3.5-9b
# Or via gh CLI for GitHub integration
```

## Privacy Guarantee
- All processing happens locally on Apple Silicon Mac
- No data leaves your computer
- Ideal for sensitive knowledge work

## Usage Patterns
- Invoke via browser_navigate to LM Studio URL
- Use execute_code with local model context
- Session cache maintains working memory

## Related Resources
- [[hermes-agent]] - Hermes Agent integration guide
- [[core/memory]] - Memory tool usage instructions
- [[tools/llm-wiki]] - LLM Wiki knowledge base patterns
