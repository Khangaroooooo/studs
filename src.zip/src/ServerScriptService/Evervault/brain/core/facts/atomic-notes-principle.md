---
title: atomic-notes-principle
category: patterns | architecture
related-to: [[core/memory.md]], [[brain/checklist]]
status: verified
---

## What This Fact Is

The **atomic notes principle** means each note in your brain should focus on ONE idea or concept. Avoid creating "god files" that contain many different ideas linked together.

### Why Atomic Notes?

✅ **Easy to find** - Search for specific concepts without sifting through giant documents
✅ **Easy to link** - Link one focused idea to another related idea
✅ **Easy to update** - Change one fact without affecting unrelated knowledge
✅ **Knowledge graph friendly** - Dense wikilink network between small, focused notes
❌ Large files are hard to navigate and understand

### Bad (Non-Atomic):

```markdown
# bad-file.md ❌

## Topic A: Hermes Agent Basics
- What it is
- How to configure
- Usage patterns

## Topic B: LM Studio Models  
- Model options
- Loading settings
- Inference parameters

## Topic C: Obsidian PKMS
- Note structure
- Linking conventions
- Folder architecture

## Topic D: Session Management
- Start of session
- During session
- End of session

## Topic E: Personal Info
- Name details
- Location info  
- Occupation notes
```

**Problem**: Contains 5 different topics. Hard to search, hard to link granularly, hard to maintain.

### Good (Atomic):

```markdown
# hermes-agent.md ✅

## What is Hermes Agent
[One focused description of Hermes Agent]

## Related Tools
- [[lm-studio]] - Model inference system
- [[obsidian-pkms]] - Knowledge base storage
- [[memory-tool]] - Cross-session persistence

## Configuration Patterns
[[hermes-config-patterns]] - Detailed configuration details

## Session Usage
[[session-start-routine]] - How to start a session with Hermes
[[session-end-routine]] - How to end a session with Hermes
```

**Good**: One topic (Hermes Agent), links to related atomic notes.

---

## Folder Structure Supports Atomicity

| Folder | Purpose | Notes Should Be |
|--------|---------|------------------|
| `brain/core/` | Persistent knowledge base | Atomic facts & concepts |
| `brain/personal-info/` | Your identity | One aspect per file |
| `brain/learning/notes/` | Temporary learning | Specific discoveries |
| `brain/context/` | Temporary context | Session-specific items |
| `projects/` | Work in progress | One project per file |
| `tasks/` | Action items | One task per file |

---

## When to Split a Note

Ask: **"Could this note be useful on its own?"** If YES, split it.

### Signs Your Note Is Too Large:

1. You can't find what you're looking for in the file
2. You have 3+ unrelated headings/topics
3. You'd reference this entire file from multiple places
4. The file is >50 lines of content (hint: probably too much!)

### When to Merge Two Notes:

Ask: **"Are these really two separate concepts?"** If NO, merge them.

---

## Related Concepts

- `[[facts/session-end-routine]]` - Part of quality maintenance
- `[[brain/core/memory.md]]` - Main hub shows atomic structure
- `[[core/facts/]]` - Index of all atomic facts

---

*Last updated: Session 2026-06-01 initial rebuild | Principle verified through brain architecture design*
