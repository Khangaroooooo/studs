# Local AI Development Patterns (2026-06-08)

**Atomic fact** - Best practices for local LLM integration and knowledge work.

## Privacy-First Approach
- All processing ON YOUR DEVICE via LM Studio
- No external API calls (localhost:1234)
- Ideal for sensitive knowledge management work

## Model Selection
- **qwen/qwen3.5-9b**: 9B parameter size, optimized for local reasoning
- Provider: lmstudio or custom:lmstudio:model-name
- Architecture: Apple Silicon M-series (Apple Neural Engine)

## Integration Patterns

### Hermes Agent + LM Studio
```yaml
model:
  provider: lmstudio
  model: qwen/qwen3.5-9b
```

### Browser Tools with Local Model
- browser_navigate to local tools/documentation
- browser_snapshot for dynamic content
- execute_code with model context available

### Session Cache Strategy
- Temporary working memory during current conversation
- Persist important facts → memory tool + filesystem
- Clear cache at session end via session log

## Knowledge Base Organization
- **Filesystem**: ~/Documents/EverVault/brain/ (permanent)
- **Context folder**: Working memory layers (active/archived/temp)
- **Memory tool**: Cross-session fact persistence
- **Graph structure**: Multi-cluster knowledge organization

## Atomic Unit Design
- One concept per note (e.g., "Hermes Agent configuration")
- Wikilinks to related concepts (LM Studio, Obsidian patterns)
- Minimum 1-3 links for discoverability

## Related Tools
- [[tools/hermes-agent]] - Hermes Agent integration
- [[tools/lm-studio]] - LM Studio inference server
- [[brain/core/facts/obsidian-pkms-patterns]] - PKMS patterns
