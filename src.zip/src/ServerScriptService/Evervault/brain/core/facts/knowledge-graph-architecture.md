# EverVault Knowledge Graph Architecture (2026-06-08)

**Atomic fact** - Multi-layer knowledge graph structure and growth strategy.

## Directory Structure

```
~/Documents/EverVault/
├── brain/                    # Permanent knowledge (core)
│   ├── core/                 # Core concepts, patterns, architecture
│   │   ├── memory.md         # Core memory hub (required link target)
│   │   └── facts/            # Atomic facts for tools/patterns/preferences
│   ├── personal-info/        # Personal identity documents
│   │   ├── name.md
│   │   ├── occupation.md
│   │   ├── location.md
│   │   └── tools-and-env.md
│   ├── graph/                # Knowledge graph clusters
│   │   └── *.md              # Graph nodes with wikilink networks
│   ├── context/              # Working memory layers
│   │   ├── temp/             # Temporary tool outputs
│   │   ├── active/           # Current session working memory
│   │   ├── archived/         # Rotated/outdated content
│   │   └── graph/            # Graph expansion nodes
│   └── .getting-started.md   # Onboarding guide
├── context/                  # Active context window (duplicate of brain/context)
├── system/                   # System-level documentation
│   ├── metrics/              # Health dashboard reports
│   │   └── brain-health-report.md  # Growth, density, recency metrics
│   ├── memory-tool-guide.md  # Memory tool usage instructions
│   └── session-notes/        # Session hygiene logs
│       └── YYYY-MM-DD.md    # Per-session records
├── scripts/                  # Automation utilities
│   ├── entity-extractor.py   # Parse tool outputs for new concepts
│   ├── archival-bot.py       # Smart retention with link-based scoring
│   ├── link-suggester.py     # Find and create missing wikilinks
│   └── session-end-routine.py # Session hygiene automation (pending)
├── scripts/                  # Legacy scripts (move to context/graph)
├── COMPLETE-OPTIMIZATION-SUMMARY.md
└── USING-EVERVAULT-TO-FULLEST-POTENTIAL.md
```

## Layer System

### Foundation Layer ✅ (70% Complete)
- **Core concepts**: Tools, patterns, architecture documents
- **Atomic facts**: ~8 facts covering tools/patterns/optimization
- **Personal identity**: Profile files in personal-info/

### Growth Layer 🟡 (In Progress)
- **Emerging topics**: New concepts as they appear
- **Link density**: Target 1-3 wikilinks per note minimum
- **Cluster expansion**: Grow ASCII graph map visualization

### Context Window 🟢 (Active)
- **active/**: Current session working memory
- **archived/**: Rotated content based on scoring
- **temp/**: Tool outputs for entity extraction

## Growth Strategy

1. **Atomic Notes**: One concept per note, 1-3 wikilinks
2. **Core Hub Linking**: Every new note → `[[core/memory]]`
3. **Entity Extraction**: Parse tool outputs for new concepts
4. **Link Suggestion**: Find missing bidirectional links
5. **Pattern Codification**: Identify recurring themes

## Health Metrics (Pending Implementation)

- **Coverage**: Note count per category (tools, patterns, topics)
- **Density**: Average wikilinks per note (target: 2-3)
- **Recency**: Days since last edit of each fact
- **Sparsity**: Identify under-connected regions

## Related Resources
- [[core/memory]] - Core memory hub
- `[[USING-EVERVAULT-TO-FULLEST-POTENTIAL]]` - Usage guide  
- [[projects/evervault-mastery]] - Mastery progression path
