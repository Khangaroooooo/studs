# Tool Usage Conventions (2026-06-08)

**Atomic fact** - How to use Hermes tools effectively in EverVault workflow.

## Browse Tool Set

### browser_navigate
- Navigate to URLs or file:/// paths
- Required before other browser tools
- Use for web apps, documentation sites, GitHub

### browser_snapshot
- Get page snapshot with interactive elements
- Use full=true for complete content inspection
- ref IDs (e.g., @e1, @e2) for clicking elements

### browser_click
- Click element by ref ID (@eX)
- Requires browser_navigate first
- Used for form interactions, navigation

### browser_type
- Type text into input field by ref ID
- Clears field first, then types new text
- Use for forms, search boxes

### browser_press
- Press keyboard keys (Enter, Tab, Escape)
- Useful for form submission, shortcuts

### browser_vision
- Take screenshot with question
- Annotate=true adds numbered labels to elements
- Attach images to context for visual inspection

## File Operations Tool Set

### read_file
- Read text files with line numbers and pagination
- Use offset/limit for large files
- Prefer over terminal cat/head/tail

### write_file
- Write content to file, replaces entirely
- Creates parent directories automatically
- Auto-runs syntax checks on new files

### patch
- Targeted find-and-replace edits
- Supports fuzzy matching (9 strategies)
- auto-runs syntax checks after editing

### search_files
- Search file contents or find files by name
- target='content' for regex inside files
- target='files' for glob patterns like '*.py'

## Code Execution Tool Set

### execute_code
- Run Python scripts with Hermes tools
- Import: from hermes_tools import read_file, write_file, etc.
- Timeout: 5 min, stdout cap: 50KB
- Max tool calls: 50 per script

## Memory Tool

### memory (persistent storage)
- target='user': Who the user is (preferences, name, role)
- target='memory': Your notes (facts, conventions, lessons)
- action='add' / 'replace' / 'remove'
- Injected into future turns for cross-session recall

**PRIORITY**: Persist personal info & facts immediately after creating/editing!

## Terminal Tool

### terminal
- Execute shell commands on local system
- background=true for long-running processes
- notify_on_complete=true for bounded tasks (tests, builds)
- workdir for specific project directories

## Console Tool

### browser_console
- Get browser console output and JavaScript errors
- Detect silent JS errors, failed API calls
- expression parameter for DOM inspection

**Related Resources**:
- [[core/memory]] - Core memory architecture
- [[system/session-notes/]] - Session hygiene documentation
- [[brain/core/facts/hermes-agent-config]] - Hermes Agent setup
