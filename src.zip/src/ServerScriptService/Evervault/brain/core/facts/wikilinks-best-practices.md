# Wikilink Best Practices (2026-06-08)

**Atomic fact** - Guidelines for creating effective wikilink connections.

## Core Rules

### Required Links
1. Every new note must link to `[[core/memory]]`
2. Link to `[[brain/personal-info/name]]` if about identity
3. Link related concepts ([[occupation]], [[location]], etc.)

### Minimum Link Count
- Target 1-2 additional wikilinks from existing knowledge base
- Aim for bidirectional links when possible (A→B and B→A)

### Link Quality Guidelines
1. **Relevance**: Only link meaningfully connected concepts
2. **Specificity**: Link to atomic facts, not vague topics
3. **Recency**: Prefer linking to recently updated content

## Link Patterns

### Concept Clusters
```markdown
# Topic X
- [[core/memory]] (required)
- [[brain/personal-info/occupation]] (related context)
- [[tools/hermes-agent]] (relevant tool)
```

### Tool Documentation
```markdown
# Tool Name
- [[core/memory]] (required)
- [[tools/lm-studio]] (complementary tool)
- [[brain/core/facts/tools-usage-conventions]] (usage guide)
```

### Personal Identity
```markdown
# Name/Handle
- [[core/memory]] (required)
- [[personal-info/location]] (geographic context)
- [[personal-info/tools-and-env]] (tech stack)
```

## Avoid These Pitfalls

❌ **Link loops**: A→B→C→A without new information
❌ **Over-linking**: Too many vague links dilutes meaning
❌ **Orphaned concepts**: New notes without `[[core/memory]]` link
❌ **Duplicate content**: Create facts instead of repeating in notes

## Related Resources
- [[brain/core/facts/obsidian-pkms-patterns]] - PKMS patterns
- [[brain/core/facts/session-management-patterns]] - Session workflows
- [[brain/core/facts/optimization-patterns]] - Optimization strategies
