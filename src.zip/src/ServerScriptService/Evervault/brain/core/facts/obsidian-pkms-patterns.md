# Obsidian PKMS Patterns (2026-06-08)

**Atomic fact** - Personal Knowledge Management System with wikilinks and graph architecture.

## Core Architecture
- **Vault Path**: ~/Documents/EverVault
- **Brain Directory**: brain/ (permanent notes)
- **Context Folder**: context/ (working memory: active/, archived/)
- **Graph Index**: Track cluster connections via ASCII map

## Pattern Rules
1. **Atomic Notes**: One concept per note, 1-3 wikilinks minimum
2. **Core Links**: Every new note links to `[[core/memory]]` (required!)
3. **Session Hygiene**: Record context at start/end of sessions
4. **Memory Tool Integration**: Persist personal info immediately after edits

## Layer System
- **Foundation Layer**: Core concepts, patterns, tools (facts/)
- **Growth Layer**: Topics as they emerge, expanding graph density
- **Context Window**: Active working memory (context/active/)
- **Archives**: Historical context (context/archived/) with rotation

## Graph Health Metrics
- Monitor cluster connections: see `[[system/metrics/brain-health-report]]`
- Track link density in `[[graph/index]]`
- Identify sparse regions needing expansion

## Related Tools
- [[search_files]] - Find notes by pattern/content
- [[read_file]] - Read any note contents
- [[write_file]] - Create/edit notes
- [[patch]] - Safe find-and-replace edits
