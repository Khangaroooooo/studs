# Core Facts Index - Atomic Knowledge Units

This is your **atomic knowledge base** - individual, focused facts about your brain system, tools, environment, and patterns discovered. Each fact file contains ONE specific piece of knowledge for easy linking and searchability.

---

## 📜 How to Use This Folder

### When to Create a New Fact:
- You discover an important pattern or principle
- You find a critical tool configuration detail  
- You learn a key preference that affects future sessions
- You document a significant limitation or constraint
- You capture a reusable workflow pattern

### Creating a Fact File:
```markdown
---
title: [specific topic]
category: tools | patterns | preferences | environment | architecture
related-to: [[core/memory.md]]
status: new | verified | integrated
---

[One focused piece of knowledge here...]
```

---

## 🧠 Current Core Facts

### Hybrid Persistence Pattern
**See**: `[[facts/hybrid-persistence-pattern]]`  
**Purpose**: Document the filesystem + memory tool dual persistence system

### Session End Routine  
**See**: `[[facts/session-end-routine]]`  
**Purpose**: Non-negotiable cleanup steps for each session end

### Context Folder Maintenance
**See**: `[[facts/context-folder-maintenance]]`  
**Purpose**: Prevent bloat by reviewing every session end

---

## 📦 Fact Categories

### Tools & Technologies
Atomic facts about tools, frameworks, and platforms:
- Hermes Agent configuration and capabilities
- LM Studio model settings and constraints
- Obsidian PKMS patterns and best practices
- Python libraries in your stack
- macOS-specific system capabilities

### Personal Environment
Facts about your computing environment:
- OS version and architecture details
- Browser preferences and configurations
- Development environment setup
- Local AI processing capabilities

### Brain System Architecture
Core architectural concepts:
- Three-layer knowledge graph design
- Wikilink connection rules
- Memory tool usage patterns
- Session lifecycle management

### Work Patterns & Preferences
How you like to work:
- Note-taking style preferences
- Communication style preferences
- Learning preferences and approaches
- Browser usage patterns

### Pitfalls & Lessons Learned
Things discovered through experience:
- What breaks without automation
- Common mistakes and how to avoid them
- Session hygiene requirements
- Context folder maintenance needs

---

## 🔍 Finding Facts

### Search Patterns:
1. **By category** - Look in this index by topic (tools, patterns, etc.)
2. **By link** - Follow wikilinks from other notes
3. **By pattern** - Facts are atomic, so search for specific concepts

---

## 📋 Template for New Facts

```markdown
---
title: [concise specific title]
category: tools | patterns | preferences | environment | architecture
related-to: [[core/memory.md]]
status: new | verified | integrated
---

## What This Fact Is

[One sentence summary of this atomic fact]

## Details

[Expand on the details. Keep focused on ONE concept.]

## Why It Matters

[Explain why this is important to know]

## Connections

### Links to Other Facts:
- [[related-fact-1]] - connects because...
- [[related-fact-2]] - relates through...

### Links to Core Memory:
- [[core/memory.md]] - main hub (always link!)

### Related Personal Info:
- [[personal-info/name]] - if this is about you
- [[personal-info/tools-and-env]] - if it's a tool detail
```

---

## 🧪 Key Patterns Documented Here

### 1. Hybrid Persistence Pattern
**File**: `facts/hybrid-persistence-pattern.md`  
**What**: Using both Obsidian filesystem storage AND memory tool for complete persistence  
**Why**: Obsidian files provide searchability and linking; memory tool provides cross-session survival  

```python
# The pattern:
1. write_file(path="brain/personal-info/name.md", content=...)  # For Obsidian
2. memory(action="add", target="user", content=read_file(path="brain/personal-info/name.md\").content)  # For persistence
```

### 2. Session End Routine  
**File**: `facts/session-end-routine.md`  
**What**: Non-negotiable cleanup steps before ending a session  
**Why**: Without automation, manual checks are unreliable and often missed  

**Steps:**
1. Persist personal info files with memory tool
2. Create session log in system/session-notes/
3. Review and archive from brain/context/ folder
4. Update core/memory.md with highlights

### 3. Context Folder Maintenance
**File**: `facts/context-folder-maintenance.md`  
**What**: Review context folder every session end to prevent bloat  
**Why**: Context is temporary by design - letting it grow unbounded defeats the purpose  

**Pattern:**
```python
# At session end:
from hermes_tools import read_file
import os

context_dir = "brain/context"
if any(os.path.join(root, f) for root, dirs, files in os.walk(context_dir)):
    # Flag for review - archive or delete as appropriate
    pass
```

---

## 📚 Related Documentation

- `[[core/memory.md]]` - Main persistent memory hub
- `[[brain/.getting-started]]` - Quick start guide
- `[[system/memory-tool-guide]]` - Complete memory tool documentation
- `[[projects/evervault-brain-system]]` - Project tracker

---

*This facts index is living documentation. Add new facts as you discover important patterns!*
