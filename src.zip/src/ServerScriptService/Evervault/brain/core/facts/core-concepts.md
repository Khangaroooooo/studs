# Core Concepts Template - Brain Architecture Overview

**Title**: evervault-core-concepts  
**Category**: architecture | foundation  
**Related-to**: [[brain/core/memory]], [[personal-info/tools-and-env]]  
**Status**: new

---

## The Three Pillars of EverVault

EverVault brain rests on three pillars:

### 1. Persistent Knowledge Base
Location: `[[brain/core/memory]]` + related files in `brain/core/`  
Purpose: Survives across sessions, contains your identity and important facts  
Persistence: Obsidian filesystem + Memory Tool (critical!)

### 2. Learning System  
Location: `brain/learning/notes/` + evolving facts
Purpose: Capture new discoveries, refine knowledge over time  
Evolution: Learning notes → become facts → integrate into core memory

### 3. Work Management
Location: `projects/`, `tasks/`, `memories/`  
Purpose: Track active work, episodic experiences, experiments  
Lifecycle: Create → develop → complete → archive

---

## How They Interconnect

```
Persistent Core ←→ Learning System ←→ Work Management
     ↓                    ↓                    ↓
  Memory Tool          Observation           Progression
  (persistence)        (becomes facts)      (moves to archive)
```

### Example Flow:

1. **Learn**: You discover something new in a session  
2. **Capture**: Create learning note in `brain/learning/notes/`  
3. **Persist**: Use memory tool for important facts from this discovery  
4. **Connect**: Link learning note to existing knowledge graph  
5. **Archive**: After refinement, move to core facts or update core memory

---

## Key Directories Explained

### brain/core/
- `memory.md` - Main persistent memory hub (READ THIS FIRST!)  
- `facts/` - Atomic knowledge units (searchable, linkable)
- `connection-guide.md` - Architecture documentation

### brain/personal-info/
- Core identity files that MUST be persisted with memory tool:
  - `name.md` - Your full name(s)
  - `occupation.md` - Professional identity
  - `location.md` - Geographic location  
  - `tools-and-env.md` - Tech stack and tools
  - `work-preferences.md` - Work habits and preferences

### brain/learning/notes/
- New discoveries and learning from sessions
- See `[[learning/note-template]]` for template
- Eventually may become core facts or integrate into memory

### brain/memories/
- Episodic memories (events, experiences, significant sessions)
- Complements semantic knowledge in core memory

### brain/context/
- Temporary but relevant information
- Must be cleaned/archived regularly  
- Don't let it grow unbounded!

### system/session-notes/
- Individual session logs and history
- See `[[system/session-notes/template]]` for template

---

## Quick Reference: Where Does This Go?

### New Personal Fact → `brain/personal-info/*.md` + memory tool  
### New Learning Discovery → `brain/learning/notes/*.md`  
### New Atomic Fact → `brain/core/facts/*.md` + memory tool  
### Active Project → `projects/*.md`  
### Action Item → `tasks/*.md`  
### Event from Session → `brain/memories/*.md`  
### Temporary Context → `brain/context/*.md` (review often!)  

---

## 🧠 See Also

- `[[core/memory.md]]` - Main memory hub (read this first!)
- `[[personal-info/name]]` - Your identity
- `[[learning/note-template]]` - For new learning notes  
- `[[system/session-notes/template]]` - Session logging template
