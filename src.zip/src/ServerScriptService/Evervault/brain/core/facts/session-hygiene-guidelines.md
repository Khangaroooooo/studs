# Session Hygiene Guidelines (2026-06-08)

**Atomic fact** - Start and end of session best practices for knowledge capture.

## Start of Session Checklist

### 1. Read Core Memory
```python
from hermes_tools import read_file
read_file(path="/Users/kkhangaroo/Documents/Evervault/brain/core/memory.md")
```
- Understand current context and ongoing work
- Review any pending tasks or notes to complete

### 2. Check Graph Index
- Review `[[graph/index]]` for active clusters
- Identify sparse regions needing expansion
- Note recent additions to knowledge base

### 3. Review Active Context
- Scan `context/active/` for relevant working memory
- Identify files from previous sessions still needed
- Prepare for entity extraction opportunities

## During Session Practices

### Capture Entities
- New tools, projects, concepts encountered
- Tool outputs containing valuable information
- User corrections or preference updates

### Create Atomic Facts
- Convert learning notes → brain/core/facts/
- One concept per note with 1-3 wikilinks
- Always link to `[[core/memory]]`

### Persist Personal Info
- Use memory tool for ALL personal info updates
- Never rely on file edits alone without persistence
- Example: `memory(action='add', target='user', content=...)`

## End of Session Checklist

### 1. Update Core Memory
```python
read_file(path="brain/core/memory.md")
write_file(path="brain/core/memory.md", content=updated_content)
```
- Record session learnings and discoveries
- Note any optimization improvements made
- Document graph growth (new clusters, facts created)

### 2. Create Session Log
```
system/session-notes/YYYY-MM-DD.md
```
- Summary of work completed
- New facts/tools added
- Issues discovered or resolved

### 3. Run Archival Optimization
```bash
python scripts/archival-bot.py --optimize
```
- Archive old/low-link files automatically
- Promote fresh/highly-linked files to active
- Maintain lean context window

### 4. Health Check
```python
read_file(path="system/metrics/brain-health-report.md")
```
- Review coverage, density, recency metrics
- Identify optimization opportunities
- Update plan if needed

## Automation Opportunities (Pending)

### session-end-routine.py
Automates:
- Memory tool calls for persistence
- Session log creation
- Context review and archival scoring
- Health report generation

Run at end of every session to ensure hygiene!

## Related Resources
- [[system/memory-tool-guide]] - Memory tool usage instructions
- [[brain/core/facts/session-management-patterns]] - Session workflows
- [[brain/core/facts/optimization-patterns]] - Optimization strategies
