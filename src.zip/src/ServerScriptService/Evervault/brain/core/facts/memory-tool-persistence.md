---
title: memory-tool-persistence
category: tools | architecture
related-to: [[core/memory.md]], [[system/memory-tool-guide]]
status: verified
---

## What This Fact Is

The `memory` tool is the **ONLY mechanism for cross-session persistence** in the EverVault brain system. It saves facts to the Hermes session context so they survive when you return with a new conversation.

### Critical Distinction:

| Mechanism | Persists Across Sessions? | What It's For |
|------------|--------------------------|---------------|
| `memory` tool calls | ✅ YES | Cross-session persistence |
| Obsidian files alone | ❌ NO | Searchability, linking, archival |
| Local disk storage | ❌ NO (for facts) | Filesystem for learning notes |

---

## The Persistence Pattern

### Basic Usage:

```python
from hermes_tools import read_file, memory

# Read content from a file
content = read_file(path="brain/personal-info/name.md").content

# Persist to memory (survives next session!)
memory(action="add", target="user", content=content)
```

### For New Facts:

```python
from hermes_tools import write_file, memory

# Write new fact to filesystem first
fact = """Title: Hermes Agent Configuration
Category: tools | architecture
---
[Fact content...]"""

write_file(path="brain/core/facts/hermes-config.md", content=fact)

# Then persist to memory
memory(action="add", target="user", content=read_file(path="brain/core/facts/hermes-config.md").content)
```

### For Personal Info Files (CRITICAL):

```python
from hermes_tools import read_file, memory

personal_info_files = [
    "brain/personal-info/name.md",
    "brain/personal-info/occupation.md",
    "brain/personal-info/location.md",
    "brain/personal-info/tools-and-env.md",
    "brain/personal-info/work-preferences.md",
    "brain/personal-info/brain-rules.md",
]

for file_path in personal_info_files:
    content = read_file(path=file_path).content
    memory(action="add", target="user", content=content)
```

---

## When to Use Memory Tool

### ✅ ALWAYS Use Memory Tool For:

- **Personal identity facts** (name, occupation, location)
- **User preferences** (work style, tool preferences, communication style)
- **Important discoveries** that affect future sessions
- **Critical configurations** (model settings, environment details)
- **System rules** for how the brain should operate

### ⏸️ CAN Reference Without Persistence:

- Temporary context notes (`brain/context/`)
- Session-specific explorations (`learning/notes/`)
- Completed learning experiments
- One-off observations or ideas

---

## Common Mistakes to Avoid

### ❌ Don't rely on Obsidian alone:
```python
# WRONG - File created but lost when session ends!
write_file(path="brain/personal-info/name.md", content="...")
```

### ✅ Do use both filesystem + memory tool:
```python
# RIGHT - Persists across sessions AND survives outside Hermes
write_file(path="brain/personal-info/name.md", content=...)
memory(action="add", target="user", content=read_file(path="brain/personal-info/name.md").content)
```

### ❌ Don't forget to persist after editing:
After making changes, always call `memory()` immediately. The pattern is:

```python
# 1. Edit or create file
edit_file(...)

# 2. Persist the result
memory(action="add", target="user", content=read_file(...).content)
```

---

## Verifying Persistence Works

After persisting, test that memory survives:

```python
from hermes_tools import memory

# List all persisted facts
memory(action="list")  # Should show your personal info and important facts
```

If you don't see your personal info listed here, it hasn't been persisted!

---

## Related Concepts

- `[[facts/hybrid-persistence-pattern]]` - Complete persistence architecture
- `[[brain/checklist]]` - Session end checklist includes memory tool calls
- `[[system/memory-tool-guide]]` - Comprehensive memory tool documentation
- `[[core/memory.md]]` - Main persistent memory hub

---

*Last updated: Session 2026-06-01 initial rebuild | Verified through observation that facts not persisted with memory() are lost at session end*
